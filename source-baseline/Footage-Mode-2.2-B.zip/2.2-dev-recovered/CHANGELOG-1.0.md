# Changes in Bridge 1.0 integration

- Added the Performance-to-Coverage Bridge specification and executable adapter.
- Preserved per-character performance tracks, overlaps, director context, and safety metadata.
- Added shot-level primary/secondary character selection and optional offscreen dialogue.
- Added separate scene-time source ranges and per-clip local render clocks for parallel coverage.
- Hardened Footage-Mode QC: required fields, FOV pairing, event-track consistency, dialogue range, exact special-camera override tag, and hard delivery gate.
- Made prompt budgets language-aware for Latin and CJK text.
- Updated the legacy prose adapter to reject multi-character flattening.
- Added Dewei Hall three-camera regression fixture and automated tests.
