# Changelog — Footage-Mode Bridge 1.1

## Added

- `scripts/auto_shot_planner.py`: deterministic first-pass coverage planner.
- Automatic master, speaker, reaction, two-shot and heuristic action-detail proposals.
- Source-time-aligned independent coverage; overlapping cameras retain overlapping source ranges.
- Per-shot rationale and review metadata under `planner`.
- `--max-shots` and `--master-character` controls.
- Planner documentation and regression tests.
- Dewei Hall end-to-end automatic planning example with rendered prompt outputs.

## Preserved

- Bridge 1.0 interface and timing contract.
- Acting Skill per-character tracks and simultaneous action representation.
- Footage-Mode optics anchors, camera safety rules, prompt rendering and QC gate.
- Legacy adapter remains separate and is not used to flatten multi-character tracks.

## Limitations

- Planning rules are deterministic heuristics, not semantic cinematography intelligence.
- Exact blocking, eyelines, screen direction, prop visibility and edit decisions require human review.
- Estimated source timing remains provisional.
- No real video-model generation or visual-result validation is included.
