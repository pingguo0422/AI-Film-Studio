# Changelog — Footage-Mode 2.0

## 2.0.0 — additive intelligence foundation

### Added
- Director Intelligence: structured dramatic question, audience knowledge, subtext,
  visible performance cues, and transparent heuristic suggestions.
- Spatial Intelligence: top-down coordinate convention, axis anchors, camera-side
  calculation, blocking record validation, and explicit axis-crossing authorization.
- Continuity Engine: source-range overlap checks for character, prop, wardrobe,
  lighting, and environment state snapshots.
- Integrated `preflight_2.py` report with PASS / INCOMPLETE / FAIL semantics.
- 2.0 schema reference and backward-compatible workflow documentation.

### Preserved
- Existing 1.1 Performance Bridge, parallel coverage, prompt renderer, optics,
  asset identity, camera safety, and QC behavior.
- Existing 1.1 scene documents remain renderable without migration.

### Known limitations
- Director cue matching is intentionally heuristic and must not be treated as
  authoritative psychological interpretation.
- Spatial validation requires explicit coordinates; it does not reconstruct a
  floor plan from screenplay prose.
- Continuity validation compares declared snapshots; it does not inspect generated
  video pixels or infer unrecorded prop states.
- PASS means no conflict was found in supplied data, not that the footage is
  artistically correct or generation-ready.
