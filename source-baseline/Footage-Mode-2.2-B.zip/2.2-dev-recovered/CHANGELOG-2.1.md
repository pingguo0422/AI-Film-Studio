# Changelog — Footage-Mode 2.1

## 2.1.0 — Art Director and Visual Bible integration

### Added
- Art Director 2.1: first-pass casting/character visual briefs, first-look costume records, prop design briefs, and set/location design briefs derived from declared scene assets.
- Visual Bible schema with source provenance, reference tags, continuity anchors, and a human approval lifecycle: `draft` → `director_approved` → `production_locked`.
- Historical accuracy review fields for period/region and evidence requirements. Missing historical context is marked unverified; the system does not fabricate period facts.
- `scripts/preflight_2_1.py`: integrated Director Intelligence, Spatial Intelligence, Continuity Engine, and Art Director validation.
- `--draft-visual-bible` and `--visual-bible` CLI options for generating and validating the Visual Bible.
- 11 focused Art Director / Visual Bible regression tests; full suite now contains 32 tests.

### Preserved
- Footage-Mode 1.1 renderer, legacy Acting Adapter, Performance Bridge, parallel coverage, prompt assembly, camera/optics rules, and QC gates.
- Footage-Mode 2.0 Director Intelligence, Spatial Intelligence, and Continuity Engine unchanged.
- All prior 1.1/2.0 assets, examples, schemas, and test fixtures.

### Production boundary
- Casting, costume, props, and set records are proposals, not final decisions.
- No actor identity, historical claim, or unprovided design fact is invented as authoritative.
- A `PASS` from deterministic validation checks declared data contracts only; creative and historical approval remains human-led.
