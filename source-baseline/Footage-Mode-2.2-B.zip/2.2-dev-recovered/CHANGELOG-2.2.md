# Changelog — Footage-Mode 2.2

## 2.2.0-alpha.1 — Dramatic Event Engine

### Added
- `scripts/dramatic_event_engine.py`: traceable first-pass event extraction from ACTING TASK blocks and conservative line-oriented screenplay input.
- `references/dramatic-event-schema-2.2-A.json`: machine-readable event schema.
- `references/dramatic-event-engine-2.2-A.md`: extraction rules, limitations, and CLI usage.
- Shared-event clusters to link descriptions of one physical occurrence across character tracks without collapsing distinct performer reactions.
- Coverage candidate questions for prop changes, group shifts, authority/threat beats, and recognition/revelation beats.
- `tests/test_dramatic_event_engine.py`: focused parser, traceability, clustering, and conservative-inference tests.
- Heaven Ship 8.1 event JSON and extraction report based on the archived ACTING TASK input.

### Preserved
- All 1.1 renderer, Acting Adapter, Performance Bridge, parallel coverage, and prompt/QC behavior.
- All 2.0 Director Intelligence, Spatial Intelligence, Continuity Engine, and preflight behavior.
- All 2.1 Art Director and Visual Bible behavior.

### Limitations
- The archived Heaven Ship package contains ACTING TASK tracks, not the original screenplay file. Its event line references therefore point to the ACTING TASK source, not the screenplay.
- The screenplay parser is line-oriented and conservative; ambiguous actor attribution remains `UNASSIGNED`.
- Dramatic states, audience knowledge, and power shifts are not auto-invented. Human review remains mandatory.
- No final shot list, shot timing, camera design, or video generation is produced in 2.2-A.

## 2.2-B recovered (provisional)

- Added `director_decision_engine.py`: deterministic weighted coverage selection, explicit event-dimension coverage states, shared-cluster action coverage with separate prop inserts and character/group reactions, source-range validation, and technical master-range segmentation.
- Added ten focused regression tests; full suite now 51 passed.
- Added Heaven Ship 8.1 52-event coverage decision output and recovery report.
- This is a reconstruction because the historical 2.2-B source was not recoverable; see `2.2-TEST-REPORT.md`.
