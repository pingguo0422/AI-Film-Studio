# Footage-Mode 2.2-A Installation

1. Extract the ZIP archive. The package root contains `VERSION-2.2.json` and the `footage-mode/` skill directory.
2. Install/copy the complete `footage-mode/` directory as the Footage-Mode skill folder in your skill environment. Do not install only the new 2.2-A scripts: the package intentionally includes the complete 1.1/2.0 base.
3. Python 3.7+ is required for the bundled command-line scripts; no third-party Python packages are required.
4. Verify the installation from inside `footage-mode/`:

   ```bash
   python -m compileall -q scripts tests
   python -m unittest discover -s tests -v
   python scripts/footage_mode.py selftest
   python scripts/adapt_acting.py selftest
   ```

5. Draft the Art Director Visual Bible and run integrated preflight:

   ```bash
   python scripts/preflight_2_1.py assets/example-scene.json \
     --draft-visual-bible out/visual-bible-draft.json \
     -o out/preflight-2.1.json
   ```

A first-pass draft commonly reports `INCOMPLETE` until the director supplies period/region context and reviews each asset. This is intentional. Advance approved assets explicitly; do not mark a generated draft as production-locked without human sign-off.


## 2.2-A Dramatic Event Engine

The 2.2-A event extractor is additive. Keep the complete package directory when installing; do not copy only the new script. Run the full standard-library test suite:

```bash
python -m compileall -q scripts tests
python -m unittest discover -s tests -v
python scripts/dramatic_event_engine.py assets/heaven-ship-8.1-acting-task.txt \
  --scene-id S08 --scene-title '天堂号底舱' \
  -o out/heaven-ship-events.json --report out/heaven-ship-events.md
```

For raw screenplay input, use `--input-format screenplay` and provide an exact comma-separated `--roster`. Ambiguous action attribution remains `UNASSIGNED` and requires director review.
