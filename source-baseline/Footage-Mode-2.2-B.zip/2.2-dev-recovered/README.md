# Footage-Mode 2.2-A (backward-compatible 1.1 core)

Multi-camera raw-footage prompt generator. One scene in, one sealed prompt per shot out —
no in-clip cuts, no editing instructions, no compositing.

```
screenplay + acting pass (per-character tracks)
      │
      ▼
ACTING TASK blocks + bridge-config.json
      │ performance_bridge.py
      ▼
scene.json with independent character tracks + shot coverage
      │ footage_mode.py
      ▼
shots.json + per-shot prompts + QC report
```

## Quick start

```bash
# 1. Acting Skill 2.0 -> per-character tracks -> shot coverage
python scripts/performance_bridge.py acting.txt bridge-config.json -o out/scene.json

# 2. (Optional) generate a first-pass coverage plan automatically
python scripts/auto_shot_planner.py acting.txt bridge-config.json -o out/auto-scene.json --max-shots 14

# 3. Review the proposed coverage, then render + validate
python scripts/footage_mode.py all out/auto-scene.json -o out/rendered/

# Legacy single-character-per-shot adapter (not for multiple characters in one shot)
python scripts/adapt_acting.py adapt acting.txt scene.json -o out/legacy-filled.json

# 3. read the result
cat out/qc-report.txt
```

Run both self-checks before trusting either script:

```bash
python scripts/footage_mode.py selftest   # bundled scene, prompt and QC checks
python scripts/adapt_acting.py selftest   # legacy single-track adapter checks
python scripts/performance_bridge.py acting.txt bridge-config.json -o out/bridge-scene.json
```

## Footage-Mode 2.0 intelligence preflight

The 2.0 layer adds director-intent annotations, measured spatial-axis checks,
and explicit cross-shot state comparisons. It is additive: the 1.1 renderer and
existing input schema remain usable.

```bash
# Review a scene before rendering. INCOMPLETE means evidence is missing,
# not that continuity has passed.
python scripts/preflight_2.py assets/example-scene.json -o out/preflight-2.0.json

# Existing render pipeline remains unchanged.
python scripts/footage_mode.py all assets/example-scene.json -o out/rendered/
```

New modules:
- `scripts/director_intelligence.py` — transparent dramatic-cue suggestions and director review checklist.
- `scripts/spatial_intelligence.py` — scene-plan coordinates, axis-side calculation, crossing checks and blocking validation.
- `scripts/continuity_engine.py` — compares explicit state snapshots across overlapping source ranges.
- `scripts/preflight_2.py` — combines the three reports without silently modifying production data.
- `references/intelligence-extension-2.0.md` — schema and usage guide.

## Files

| Path | What it is |
|---|---|
| `SKILL.md` | The skill: boundary, precedence ladder, rules R1–R10, QC gate |
| `references/input-schema.md` | Every field, required or optional, and the degradation rules |
| `references/prompt-blocks.md` | The ten blocks, word budgets, rewrite table for classic failures |
| `references/examples.md` | A four-shot worked example end to end, including the adapter |
| `scripts/footage_mode.py` | Deterministic planner, renderer, validator |\n| `scripts/director_intelligence.py` | 2.0 dramatic-intent and audience-perspective review |\n| `scripts/spatial_intelligence.py` | 2.0 spatial map, axis and blocking validation |\n| `scripts/continuity_engine.py` | 2.0 cross-shot state consistency checks |\n| `scripts/preflight_2.py` | Integrated 2.0 preflight report |
| `scripts/adapt_acting.py` | Legacy single-character-per-shot adapter; rejects multi-character flattening |
| `scripts/performance_bridge.py` | Acting Skill per-character tracks → shot-local parallel coverage |
| `scripts/auto_shot_planner.py` | Deterministic first-pass master/speaker/reaction/two-shot/detail coverage proposal |
| `references/automatic-shot-planner-1.0.md` | Planner logic, assumptions, controls and limitations |
| `references/performance-to-coverage-bridge-1.0.md` | Formal Bridge interface and timing contract |
| `references/bridge-config-guide.md` | How to write the Bridge shot/timing configuration |
| `assets/example-scene.json` | Working input: 4 shots, 2 characters, 1 prop, 1 set |
| `assets/example-acting-task.txt` | The same scene as prose, in tig-acting-task format |
| `assets/dewei-acting-task.txt` / `dewei-bridge-config.json` | Three-character parallel-coverage regression fixture |

## What it refuses to do

- Put a focal length in a prompt, or a FOV that is not on the anchor table.
- Cut inside a clip, or write an edit into a prompt.
- Let a style hint override identity, optics, physics or camera safety.
- Accept `[SPECIAL CAMERA OVERRIDE]` unless the tag is exact, in the hint, per shot.
- Deliver a shot whose QC report carries an `[E]`.
- Serialize overlapping character tracks into a single sequential performance timeline.
- Serialize parallel camera coverage onto one global render cursor.

## Requirements

Python 3.7+, no third-party packages. Prompts are English by default; the validator is
language-agnostic (CJK counts per character in the word budget).

## Footage-Mode 2.1 — Art Director and Visual Bible

The 2.1 layer is additive. It keeps the 1.1 renderer/acting/bridge toolchain and the 2.0 director, spatial, and continuity checks, then adds structured art-direction drafts.

```bash
# Generate a first-pass Visual Bible and integrated preflight report
python scripts/preflight_2_1.py assets/example-scene.json \
  --draft-visual-bible out/visual-bible-draft.json \
  -o out/preflight-2.1.json

# Validate a reviewed Visual Bible against the original scene assets
python scripts/preflight_2_1.py assets/example-scene.json \
  --visual-bible out/visual-bible-reviewed.json \
  -o out/preflight-2.1-reviewed.json
```

New modules:
- `scripts/art_director.py` — casting/character visuals, costume first looks, props, sets/locations, historical evidence requests, and Visual Bible validation.
- `scripts/preflight_2_1.py` — integrates 2.0 checks with Art Director 2.1.
- `references/art-direction-visual-bible-2.1.md` — schema, lifecycle, API, and CLI usage.

All generated design records begin as `draft`. The allowed lifecycle is `draft` → `director_approved` → `production_locked`; the tool never auto-approves creative decisions. Missing period/region evidence is reported as `INCOMPLETE`, not guessed.

Run the complete regression suite with:

```bash
python -m unittest discover -s tests -v
python -m compileall -q scripts tests
```

## Footage-Mode 2.2-A — Dramatic Event Engine (alpha)

2.2-A adds a traceable event layer before shot planning. It preserves the existing 1.1 / 2.0 / 2.1 pipeline. It can extract events from existing ACTING TASK blocks or conservatively parse line-oriented screenplay text when an exact character roster is supplied.

```bash
# From ACTING TASK blocks
python scripts/dramatic_event_engine.py assets/acting-task.txt \
  --scene-id S08 --scene-title 'Scene title' \
  -o out/events.json --report out/events-report.md

# From screenplay text (exact character names required)
python scripts/dramatic_event_engine.py scene.txt --input-format screenplay \
  --roster '武寒青,武天豪,大头,蛇头,厨师,猪仔群体,猪仔甲' \
  --scene-id S08 -o out/events.json --report out/events-report.md
```

New module: `scripts/dramatic_event_engine.py`. It records exact source lines, event types, observable action, candidate dramatic function, linked cross-character descriptions of shared actions, and candidate coverage questions. Unknown state changes and information remain empty; every event requires human review. It does **not** create camera choices, shot timings, or one-shot-per-event output. See `references/dramatic-event-engine-2.2-A.md`.

### 2.2-A Heaven Ship 8.1 trial

The archived test package contains seven ACTING TASK tracks but not the original screenplay. The bundled trial therefore produces event records anchored to the ACTING TASK file; it must not be treated as a direct screenplay parse. The source JSON and report are in `assets/heaven-ship-8.1-events.json` and `assets/heaven-ship-8.1-events-report.md`.

Run the complete regression suite with `python -m unittest discover -s tests -v` and `python -m compileall -q scripts tests`.


## 2.2-B Director Decision / Coverage Optimizer (recovered provisional)

Run the event coverage optimizer against a 2.2-A event JSON file:

```bash
python scripts/director_decision_engine.py assets/heaven-ship-8.1-events.json --max-shots 18 -o out/heaven-ship-8.1-coverage-decisions.json
```

The output distinguishes `covered`, `partially_covered`, and `not_selected` by explicit required coverage dimensions. It does not invent timing or camera design. See `references/director-decision-engine-2.2-B.md` and `2.2-TEST-REPORT.md`.
