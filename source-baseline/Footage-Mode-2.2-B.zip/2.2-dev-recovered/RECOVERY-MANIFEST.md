# Footage-Mode 2.2-B Recovery Manifest

- Build: `2.2.0-recovered-b.1`
- Working tree: this directory, reconstructed in the ChatGPT execution workspace.
- Baseline: extracted from `Footage-Mode-2.2-A-alpha1(1).zip`.
- Historical 2.2-B source: not found in the available ChatGPT Library or recovered archive.
- New reconstructed source: `scripts/director_decision_engine.py`.
- New reconstructed tests: `tests/test_director_decision_engine.py`.
- Full report: `2.2-TEST-REPORT.md`.
- 52-event pressure-test result: `out/heaven-ship-8.1-coverage-decisions.json`.
- Budget sensitivity: `out/coverage-budget-sensitivity.json`.

The original 2.2-A package is preserved separately. This recovered directory is the working baseline for further 2.2-B development; do not treat it as a byte-identical restoration of the missing historical 2.2-B folder.
