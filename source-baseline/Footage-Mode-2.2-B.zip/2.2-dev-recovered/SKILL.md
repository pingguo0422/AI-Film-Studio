---
name: footage-mode
description: >
  Multi-camera raw-footage prompt generator for video models — the technical layer
  downstream of an acting / performance pass. Use when the user has a scene, beat list
  or screenplay plus character performance data and wants post-production-ready camera
  prompts: diagonal FOV in degrees, computed pre/post padding, one LUT per scene,
  visible physics, and a whitelist for safe camera moves. Triggers on "footage mode",
  "raw footage prompts", "multi-camera prompts", "shot list to prompts",
  "turn this performance into camera prompts", "per-camera prompt". Output is one
  sealed prompt per shot — never an edited sequence, never in-clip cuts.
  In 2.2, a source-traceable dramatic-event pass may precede director coverage
  decisions; event extraction never implies one shot per event.
---

# Footage-Mode

Turns one scene plus performance data into independent camera prompts. Every prompt is a
sealed, self-contained document for a single generation: one camera, one continuous take,
one asset set. Editing, dissolves, overlays and compositing happen in post and must never
appear as instructions to the model.

**Output contract:** per shot — a typed `shot_record`, a rendered `prompt`, and a filename. The negative policy is declared at scene level and emitted as a separate negative sidecar when configured. Plus a scene-level QC report. Nothing else.

---

## 0. Hard boundary

1. **One prompt = one camera, one continuous take.** No cut, dissolve, wipe, time-skip or
   scene change inside a prompt.
2. **Raw footage only.** Write what the camera sees. Do not instruct the model to
   composite, overlay, add titles, subtitles, watermarks or VFX layers.
3. **Post-production is assumed.** Padding exists so an editor can cut; it is not a cut.
4. If a request would violate 1–3, produce the closest legal shot and log the deviation.

---

## 1. Precedence — read this before resolving any conflict

Rules resolve top-down. A lower level never overrides a higher one.

| Level | Layer | Examples |
|---|---|---|
| 1 | **Technical locks** | duration budget, FOV, asset identity, camera safety, physics |
| 2 | **Scene light & grade** | one LUT, one white balance, main light source |
| 3 | **Global style hint** | inherited look, palette, texture |
| 4 | **Shot style override** | per-shot texture / contrast tweak |

- Style (3, 4) never moves, recolours or restructures anything at level 1.
- A shot override (4) may sharpen texture or shift contrast **inside the scene's LUT
  family**. It may not change the hue family or the white balance (see R9).
- If two rules at the same level collide, the one that protects identity wins.

---

## 2. Inputs

Full field reference: `references/input-schema.md`. Machine-readable example:
`assets/example-scene.json`.

| Input | Required | Notes |
|---|---|---|
| scene block | yes | seq, location, interior, time of day, LUT, light, WB |
| asset cards | yes | id, kind, `@tag`, state, anchor (≤ 25 words) |
| coverage / shot list | yes | shot no., camera, shot size, assets in frame |
| performance timeline | recommended | duration + key events (KE) + acting block |
| performance as prose | alternative | ACTING TASK blocks from the acting pass — run the adapter first |
| shot hints `【 shot hint: … 】` | optional | intent only, never technical params |
| global style hint | optional | ≤ 40 words |

**Degradation** — when an input is missing, do not stall and do not invent silently:

| Missing | Behaviour |
|---|---|
| performance timeline | derive KE from the script beat, mark `performance.source = "inferred"`, warn |
| shot hints | choose shot size from the beat, static camera |
| global style hint | omit the STYLE block, warn |
| dialogue | keep ambience / sfx in AUDIO, drop speaker lines |
| duration over budget | split the shot (R4.3), never truncate the performance |

---

## 2.5 Footage-Mode 2.2-A — Dramatic Event Pass

When the user asks for drama-aware direction, automatic shot planning, or coverage
optimization, do not jump directly from dialogue turns to a shot list. First build a
source-traceable event map:

1. Parse the screenplay or existing ACTING TASK blocks.
2. Preserve exact source text and original line numbers.
3. Separate observable action from interpretation. Unknown before/after states,
   audience knowledge, and power shifts stay unknown until supported by the source
   or approved by the director.
4. Link different performers' descriptions of the same explicit action, but retain
   their distinct reactions and points of view.
5. Mark candidate coverage needs for prop changes, group shifts, coercion/authority,
   and recognition/revelation. A high-priority event is a review flag, not an
   instruction to create a separate shot.
6. Stop for director review before final shot planning when the source or dramatic
   interpretation is ambiguous.

CLI:

```bash
python scripts/dramatic_event_engine.py scene.txt --input-format screenplay \
  --roster 'Character A,Character B' -o out/events.json --report out/events.md
python scripts/dramatic_event_engine.py acting-task.txt -o out/events.json
```

The screenplay parser is conservative and line-oriented. Ambiguous agency must remain
`UNASSIGNED`; merely mentioning a character does not prove they perform the action.
All first-pass events require human review. 2.2-A does not select lenses, shot sizes,
camera movement, timings, or final coverage count.

## 3. Workflow

1. **Read the scene as a director.** Locate the beats; one beat is usually one shot.
2. **Build asset cards.** One card per state (costume change, prop state, room state).
   Assign `@tag`s in load order if the user gave none: `@image1`, `@image2` …
3. **Write the shot list.** For each shot: size, camera, moves, assets in frame, rigid and
   soft elements, duration.
4. **Compute timing** with R4 — padding, ranges, budget. This is arithmetic, not taste.
5. **Render the prompt** with the R10 block order and `references/prompt-blocks.md`.
6. **Run the QC gate** (§7). Any `[E]` blocks delivery.

`scripts/footage_mode.py` performs steps 4–6 deterministically:

```
python scripts/footage_mode.py plan   scene.json -o out/    # -> out/shots.json
python scripts/footage_mode.py render out/shots.json        # -> prompts
python scripts/footage_mode.py check  out/shots.json        # -> QC report, exit 1 on error
python scripts/footage_mode.py all    scene.json -o out/    # plan + check + prompt files
python scripts/footage_mode.py selftest                     # proves the toolchain works
```

The script is an accelerator, not a requirement; the rules below are complete on their own.

If the performance pass arrives as **prose** (ACTING TASK blocks, no seconds), run the
adapter before step 4. It parses the blocks, allocates the shot duration across the beats
by speech weight with a 0.4s floor, and marks the result `timing_source = "estimated"`:

```
python scripts/adapt_acting.py adapt acting.txt scene.json -o filled.json
python scripts/adapt_acting.py selftest
```

It never invents camera, size or assets — those stay editorial. It only decides where the
beats land in time, and says so.

---

## 4. Rules

### R1 — Boundary
See §0. Also: never write "auto cut", "split screen", "montage" or "multi-shot" into a prompt.

### R2 — Asset identity
1. Every element in frame has a card: `id`, `kind`, `@tag`, `state`, `anchor`.
2. `anchor` is short: age / role / build / current state / one or two unique visible
   features. **Never re-describe the whole appearance in text** — long text fights the
   reference image and degrades identity.
3. State the anchor once, then close with `100% matches the reference.`
4. A `@tag` appears only in shots where that asset is physically present.
5. Splitting assets by state is mandatory: two costume states = two cards.
6. The identity lock is restated **once**, at the end, in `POSITIVE LOCKS` (R10).

### R3 — Optics
1. FOV is **diagonal, in degrees, from the anchor list only**. No millimetres, ever.

   | Shot size | FOV | Use |
   |---|---|---|
   | `DETAIL` | 8° | hands, objects, detail-on-wide |
   | `ECU` | 12° | eye, button, single element |
   | `CU` | 18° | full face, identity-preserving |
   | `MCU` | 29° | head and shoulders, dialogue |
   | `MS` | 47° | waist up, neutral human perspective |
   | `WS` | 63° | full figure plus surroundings |
   | `EWS` | 84° | scale, location, group blocking |
   | `ARCH` | 107° | architectural ultra-wide establish |

   Anything between anchors is an error (`40°`, `60°`, `23°` are not valid).
2. State camera height with every FOV (eye level / low / high / shoulder).
3. Shot size is chosen from the beat, not inherited from a hint's technical wording (R8).
4. `ARCH` and `DETAIL` are establishing / insert tools; do not use them for dialogue.

### R4 — Timing and padding
1. **Padding is computed, not fixed.** Per side:
   `pad = clamp(0.15 × performance_duration, 0.5s, 2.0s)`, rounded to 0.1s.
   A 2.0s / 2.0s pair is only for shots where the editor needs long handles
   (`padding.mode = "fixed"`), never as a default.
2. **Budget:** `pad_pre + duration + pad_post ≤ max_clip_seconds` (default 10s).
3. If over budget: drop both pads to 0.4s and warn. If still over: **split the shot**
   into two records. Never shorten the performance to fit.
4. Ranges are explicit and non-overlapping:
   `performance_range = [render_start + pad_pre, + duration]`,
   `render_range = [render_start, render_start + render_duration]`.
5. Show the **render range** in the prompt, with timecodes measured from the render start.
6. Padding wording — never "static" or "freeze":
   - pre: `holds the ready pose, breathing only, no new action.`
   - post: `holds the final pose, breathing only, no new action.`
7. KE must tile the performance: first `t_in = 0`, contiguous, last `t_out = duration`.

### R5 — Physics, written as something visible
1. List the rigid elements and soft elements **in frame** for that shot. Do not describe
   physics for objects that are not visible.
2. Never write engine language — no "viewport", "collision", "mesh", "simulation",
   "only runs inside the frame". Describe the behaviour a viewer would see.
3. Rigid: weight, contact, shadow, nothing bends or passes through.
4. Soft: cloth and hair follow the body, folds settle naturally, silhouette stays readable.

### R6 — Air
1. Enum only: `none` (default) · `soft_breeze` · `short_gust`.
2. Only when explicitly set at scene or shot level. Never inferred from mood.
3. Strength is always mild. Violent wind is prohibited — it twists cloth and collapses
   geometry.
4. Air is uniform across the frame; no local turbulence unless a hint states a source.
5. Rigid objects are unaffected. Say nothing about them in the air sentence.
6. When `none`, the prompt contains **no airflow sentence at all**.
7. If air is active, fabric motion has two visible causes: the body moving, and the air.
   Write both as behaviour, not as a physics note.

### R7 — Camera
1. Default: `static`, locked off.
2. Safe whitelist — **one move per shot**:
   `static` · `slow_push_in` · `slow_pull_out` · `slow_pan` · `slow_tilt` · `slow_tracking`.
   Speed is always slow and steady. Every move needs a motivation in the beat.
3. Unsafe moves: `whip_pan` · `fast_zoom` · `handheld_shake` · `compound`.
4. **Exception gate.** Unsafe moves are legal only when the shot's hint carries the exact,
   case-sensitive tag `[SPECIAL CAMERA OVERRIDE]` inside a `【 … 】` hint.
5. Without the tag, unsafe requests are **deterministically downgraded and logged** —
   never silently obeyed, never silently dropped:

   | Requested | Downgraded to |
   |---|---|
   | `whip_pan` | `slow_pan` |
   | `fast_zoom` | `slow_push_in` |
   | `handheld_shake` | `static` |
   | `compound` | `slow_push_in` |

6. Under exception mode: compound and fast motion are permitted for that shot only; other
   shots keep safe mode; a **risk warning goes in the QC report, never in the prompt**; a
   reinforced identity lock is added to `POSITIVE LOCKS`.
7. Asset identity stays locked during movement — faces, props and geometry must not drift
   as the camera moves.

### R8 — Shot hints
1. Hint syntax in the screenplay: `【 shot hint: content 】`.
2. Hints express **intent** — subject, mood, emphasis, "close on his hands", "she turns".
3. Hints never set technical parameters: FOV, duration, padding, render mode, timecodes,
   LUT. Those are computed here (R3, R4, R9).
4. If a hint's literal reading would raise drift risk, adjust it and log
   `deviation = { from_hint: true, reason: "…" }`.
5. Hints are suggestions; the QC report must still pass.

### R9 — Colour and grade
1. **One LUT and one white balance per scene**, applied to every shot.
2. Local overrides may change texture, contrast or saturation **within that LUT family**.
   They may not introduce a second look, a second hue family or a different WB.
3. Flash, lightning, muzzle flare: an overlay on the base grade, never a replacement.
4. Name one main light source and its direction and tone. Do not stack conflicting sources.

### R10 — Prompt assembly
Ten blocks, in this order. Six are required, four are conditional: PERFORMANCE, PHYSICS,
AUDIO and STYLE appear only when the shot has something for them.

| # | Block | Required | Content |
|---|---|---|---|
| 1 | `SCENE CONTEXT` | yes | location, interior/exterior, time, one line of action |
| 2 | `ACTIVE REFERENCES` | yes | one line per `@tag`: kind, state, anchor, `100% matches the reference.` |
| 3 | `CAMERA` | yes | shot size, FOV°, height, move, `one continuous shot` |
| 4 | `ACTION & TIMING` | yes | timecoded beats from the render start, padding included |
| 5 | `PERFORMANCE` | conditional | acting block imported from the performance pass |
| 6 | `PHYSICS` | conditional | rigid, soft, air (air only when active) |
| 7 | `LIGHT & GRADE` | yes | LUT, main light, white balance |
| 8 | `AUDIO` | conditional | ambience, sfx, spoken lines with speaker |
| 9 | `STYLE` | conditional | global style hint, shot override, format tail |
| 10 | `POSITIVE LOCKS` | yes | identity restated once, hold to the last frame |

`CAMERA` sits third on purpose: earlier and it fights identity, later and FOV gets ignored.

---

## 5. Prompt style

- **Positive phrasing only.** Say what happens, not what must not happen.
  `"boots stay planted"` — not `"she doesn't fall"`.
- **Write the visible.** No mood labels, no abstractions. `"knuckles whiten on the case"`
  beats `"she is tense"`.
- **Measure.** Speed in km/h or `m/s`, haze in %, distance in metres, scale against a
  human body — never "fast", "big", "heavy" alone.
- **No equipment, no director names, no film stock brands** as authority arguments.
  Describe the look instead: `"fine 16mm grain, halation on highlights"`.
- **Budget:** Latin-script text targets 150–280 words (hard ceiling 320); CJK text targets approximately 300–560 characters (hard ceiling 700). Mixed prompts are checked against both limits independently. See `references/prompt-blocks.md`.
- **Language:** English prompts, unless the user asks otherwise.

---

## 6. Output contract

Per shot, emit all four artifacts. Details and examples: `references/prompt-blocks.md`
and `references/examples.md`.

1. `shot_record` — typed JSON: ids, ranges, size/FOV, move, assets, KE, audio, deviation.
2. `prompt` — the ten blocks as text.
3. `negative` — scene-level negative configuration, rendered as a separate negative sidecar or folded according to `negative.mode` (see `references/prompt-blocks.md`).
4. `filename` — `<S##>_<SH###>_<CAM>_v<##>.mp4`, e.g. `S03_SH012_A_v01.mp4`; prompt
   sidecar `.txt`; record `.json`.

Scene level: a timing table plus the QC report. Records are the source of truth; the
prompt is rendered from them, never the other way round.

---

## 7. QC gate

Run before delivering. `[E]` blocks delivery; `[W]` is reported and accepted.
`scripts/footage_mode.py check` automates the asterisked items.

| # | Check | |
|---|---|---|
| 1 | Schema and enums valid; every `@tag` has a card | * |
| 2 | FOV is an anchor value; no focal length in millimetres (film gauge is fine) | * |
| 3 | `pad` follows R4.1, total within budget | * |
| 4 | Ranges contiguous, non-overlapping, derive correctly | * |
| 5 | KE tile `[0, duration]` exactly | * |
| 6 | Every asset in frame appears in `ACTIVE REFERENCES`, tags only where present | * |
| 7 | One LUT per scene; no second grade sneaks in | * |
| 8 | Airflow sentence present only when air ≠ `none` | * |
| 9 | Unsafe move without the tag → downgrade logged | * |
| 10 | Exception shot: risk warning in report, reinforced lock in prompt | * |
| 11 | Filename matches pattern and is unique | * |
| 12 | Speech fits the performance duration | * |
| 13 | Screen direction consistent within a coverage group | * |
| 14 | No in-clip cut, no compositing, no titles or overlays | * |
| 15 | Prompt within the word budget; blocks in fixed order | * |
| 16 | No engine or post language (viewport, mesh, simulation, watermark) | * |
| 17 | Positive phrasing throughout | judged |
| 18 | Performance covers every KE with something visible | judged |
| 19 | Camera move is motivated by the beat | judged |
| 20 | Anchor quality: short, distinguishing, not a full description | judged |
| 21 | Estimated beat timing (`timing_source`) is flagged in the report | * |

---

## 8. Never

- Put a focal length in the prompt, or any non-anchor FOV.
- Cut inside a clip, or write an edit into a prompt.
- Treat a hint as a hard technical command, or invent `[SPECIAL CAMERA OVERRIDE]`.
- Let style override identity, FOV, physics or camera safety.
- Write `freeze`, `static hold`, `viewport`, `mesh`, `collider`, `simulation`.
- Describe physics for objects outside the frame.
- Re-describe a character's whole appearance when a reference tag exists.
- Deliver a shot whose QC report contains an `[E]`.


## Integration contract — Performance-to-Coverage Bridge 1.0

Acting Skill 2.0 scene-level per-character tracks must pass through `scripts/performance_bridge.py` before Footage-Mode when a shot contains multiple characters or when coverage is parallel. Do not use the legacy `adapt_acting.py` to merge multiple characters into one KE track; it now refuses that case.

The Bridge preserves each character's motive, goal, obstacle, tactic, safety constraints, and timed events. Coverage mapping selects the primary and secondary characters visible in each shot. `source_range` records scene time; each generated clip has its own local render range. Parallel coverage shots may share the same source range and must not be serialized by a global cursor. See `references/performance-to-coverage-bridge-1.0.md` for the complete contract.

QC uses separate language-aware prompt budgets: 150–280 Latin-script words (hard limit 320) and approximately 300–560 CJK characters (hard limit 700). Any `[E]` blocks delivery; `all` and `plan` do not write deliverable prompt files or `shots.json` when QC fails.


## Optional automatic coverage planning (1.1)

When the user asks for automatic shot planning, run `scripts/auto_shot_planner.py`
with the ACTING TASK text and bridge configuration. The planner proposes a continuous
master, dialogue speaker coverage, overlapping listener reactions, relational two-shots,
and heuristic action-detail inserts. Every proposal must retain its source range and
parallel character-track mapping.

Treat all planner output as a **director-review draft**. Do not present shot size,
camera choice, prop visibility, blocking, eyelines, or emotional interpretation as
screenplay facts. Review the generated `planner.reason` and `planner.review_required`
fields before rendering. Use `--master-character` when the director specifies a master
subject. Use `--max-shots` to cap coverage volume.

The planner does not produce a final edit list and must not silently remove or retime
performance events. Run the normal Footage-Mode QC after planning; estimated timing
warnings remain visible and must be resolved against the edit before production.


---

# Footage-Mode 2.0 — Intelligence Layer (additive)

Version 2.0 adds an advisory intelligence preflight. It does not replace the
1.1 renderer, bridge, timing contract, asset rules, or existing QC gate.

## 2.0 workflow

1. Preserve the 1.1 scene JSON as the production source of truth.
2. Add scene-level dramatic question / audience premise and optional dramatic beats.
3. Add shot-level director annotations: dramatic purpose, audience knowledge,
   subtext, and observable visible cues.
4. Add a top-down spatial map, axis anchors, blocking records, and camera positions.
5. Add source-time state snapshots for continuity-critical characters, props,
   wardrobe, lighting, and environment.
6. Run `python scripts/preflight_2.py scene.json -o out/preflight-2.0.json`.
7. Resolve every spatial / continuity error and review all director suggestions.
8. Only then run the existing `footage_mode.py all` production pipeline.

## 2.0 decision boundaries

- Director Intelligence emits transparent cue-based suggestions; it does not claim
  to know a character's true inner state.
- Subtext and internal state must be paired with observable cues before they become
  shot instructions.
- Spatial Intelligence computes camera side from declared axis anchors and camera
  coordinates. It cannot infer a room map from prose.
- A deliberate axis crossing requires `crossing: true` and a written
  `crossing_reason`.
- Continuity Engine compares explicit snapshots only where source ranges overlap.
  Missing data is INCOMPLETE, never an automatic PASS.
- The preflight is advisory. A human director / cinematographer remains responsible
  for final composition, performance, edit points, and production approval.

## 2.0 acceptance policy

A 2.0 preflight result has three states:
- `PASS`: supplied spatial and continuity data produced no detected conflict.
- `INCOMPLETE`: required evidence is missing; this is not a continuity approval.
- `FAIL`: a spatial or overlapping-state contradiction was detected.

Director review is always required. A `PASS` is not a claim of artistic quality,
successful video generation, or final edit readiness.

See `references/intelligence-extension-2.0.md` for the additive data schema.

---

# Footage-Mode 2.1 — Art Direction Extension

The Art Director layer is additive to the existing 1.1/2.0 pipeline. It drafts a Visual Bible from declared scene assets and context; it does not replace the director, casting director, costume designer, production designer, props master, or historical researcher.

## Art-direction workflow
1. Read the scene's declared period, region, locations, and `assets[]` cards.
2. Draft character visual/casting briefs, first-look wardrobe records, prop briefs, and set/location briefs.
3. Preserve source asset IDs, reference tags, source anchors, and continuity anchors.
4. Mark every generated record `draft`; never infer director approval.
5. Request evidence for historical period and regional authenticity. Missing context is `INCOMPLETE`, not an invitation to invent.
6. Advance records only through human review: `draft` → `director_approved` → `production_locked`.
7. Validate the Visual Bible against the source scene before handing it to production.

## 2.1 preflight

Use `scripts/preflight_2_1.py` to combine the existing Director Intelligence, Spatial Intelligence, Continuity Engine, and Art Director validation. A preflight `PASS` validates declared data contracts only; it does not certify artistic quality, historical authenticity, casting suitability, or generated-video fidelity.
