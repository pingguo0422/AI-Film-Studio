# Test Report — Footage-Mode Bridge 1.1

## Environment

- Python standard library only; no third-party runtime dependency added.
- Test fixture: `assets/dewei-acting-task.txt` + `assets/dewei-bridge-config.json`.

## Automated tests

- Python compilation: PASS.
- Unit test discovery: **14 passed** (5 automatic-planner tests + 9 existing Bridge tests).
- `footage_mode.py selftest`: PASS (4 bundled example shots).
- `adapt_acting.py selftest`: PASS (4 legacy single-character shots).
- Automatic planner on Dewei Hall: PASS; generated 12 proposed shots.
- Footage-Mode render/QC on the generated plan: **QC PASS**, 12 prompt files emitted.

## Planner fixture result

The 12 proposed coverage items comprise:
- 1 continuous master
- 4 dialogue speaker shots
- 3 listener reaction shots
- 3 relational two-shots
- 1 action-detail insert

The exact counts are fixture-specific, not universal planner guarantees.

## Important warnings

All Dewei Hall event times in this fixture are marked `estimated`. The QC report correctly emits timing warnings for every shot. These timings must be checked against the actual edit or a measured performance timeline before production.

The generated action-detail shot is a heuristic proposal based on object/contact wording. Confirm the actual prop, hand blocking and visibility before generation.

## Not tested

- Actual video generation in any third-party video model.
- Whether a video model obeys the generated prompts.
- Visual continuity across generated clips.
- Human editorial quality or final cut effectiveness.

A QC PASS means the structured prompts satisfy the current Footage-Mode validator; it is not a guarantee of successful generated footage.
