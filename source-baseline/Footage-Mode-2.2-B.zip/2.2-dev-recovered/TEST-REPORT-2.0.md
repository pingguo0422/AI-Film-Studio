# Footage-Mode 2.0 Test Report

Date: 2026-11-07

## Results

- Automated unit tests: 21 passed, 0 failed.
- Python compileall: PASS.
- Footage-Mode 1.1 selftest: PASS (4-shot bundled fixture).
- Legacy Acting Adapter selftest: PASS (4 blocks / 4 shots).
- Performance Bridge regression: PASS (3 parallel coverage shots; 3, 1, and 2 character tracks).
- Automatic Shot Planner regression: PASS (12 proposed shots under a 14-shot cap).
- 2.0 annotated example: overall PASS; spatial PASS; continuity PASS.

## Interpretation

The tests verify data contracts, deterministic checks, backward compatibility, and
the new preflight modules. They do not prove artistic quality, visual accuracy,
successful AI video generation, or final edit readiness. Director Intelligence
remains advisory; human review is mandatory.

The Python environment emitted a spreadsheet-runtime warmup diagnostic during
startup of the user-visible execution environment. It did not affect the test
commands or their exit codes.
