# Footage-Mode 2.1 — Verification Report

Date: 2026-11-08

## Automated checks

- Unit tests: **32 passed, 0 failed** (21 existing 2.0 tests + 11 Art Director 2.1 tests).
- `python -m compileall -q scripts tests`: PASS.
- Footage-Mode renderer selftest: PASS (4-shot bundled fixture).
- Legacy Acting Adapter selftest: PASS (4 ACTING TASK blocks / 4 shots).
- Performance Bridge regression: PASS (3 parallel coverage shots; 3, 1, and 2 character tracks).
- Dewei Bridge → renderer end-to-end QC: PASS; 3 prompts generated.
- 2.0 integrated preflight regression: PASS on the bundled annotated 2.0 example.
- 2.1 Art Director draft/validate: draft correctly reports `INCOMPLETE`; after adding declared period/region and explicitly advancing records to `director_approved`, Art Director validation reports `PASS`.
- 2.1 integrated CLI preflight: PASS on a complete fixture with declared spatial anchors, camera position, source range, state snapshot, and reviewed Visual Bible.
- Function signatures inspected for `art_director.draft`, `art_director.validate`, `preflight_2_1.run`, `director_intelligence.analyze_scene`, `spatial_intelligence.validate_spatial`, and `continuity_engine.validate_continuity`.

## Compatibility check

All 52 original files from the 2.0 package remain byte-identical except the two intentionally extended documentation files (`README.md`, `SKILL.md`). No pre-existing Python script, test, asset, or reference file was modified. The 1.1 renderer, Acting Adapter, Performance Bridge, and shot planner remain in the package.

## Important interpretation

- The first-pass Visual Bible is a proposal and remains in `draft` state.
- `INCOMPLETE` is expected when period/region evidence or review decisions are absent; missing data is not guessed.
- A deterministic `PASS` validates the declared data contracts only. It does not certify artistic quality, casting suitability, historical accuracy, or generated-video fidelity.
