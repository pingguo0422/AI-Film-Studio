# Footage-Mode Bridge 1.0 — implementation and regression report

## Scope

This release adds a formal Performance-to-Coverage Bridge between Acting Skill 2.0 and Footage-Mode, then updates the adapter and renderer/QC path to preserve parallel character tracks and parallel camera coverage.

## Implemented

- `references/performance-to-coverage-bridge-1.0.md`: formal interface, timing model, parsing contract, and QC requirements.
- `scripts/performance_bridge.py`: parses ACTING TASK blocks, retains director context and safety constraints, maps character names to asset IDs, clips events to shot source ranges, and emits concurrent shot-local tracks plus derived atomic KE intervals.
- `scripts/adapt_acting.py`: full-width punctuation and Safety parsing fixes; preserves director context; rejects multi-character flattening in the legacy single-track path.
- `scripts/footage_mode.py`: `parallel_coverage` mode, independent local render clocks, source-range validation, character-track and KE consistency checks, FOV-to-shot-size pairing, exact special-camera tag enforcement, language-aware prompt budgets, required-field checks, and hard delivery gating.
- Updated README, SKILL, input schema, and prompt-block documentation.

## Dewei Hall regression fixture

Input scene: the three-character discussion about rescuing Ouyang Huatang.

Timing: 24.0 seconds is a provisional director estimate for this fixture. Individual beat times in `assets/dewei-bridge-config.json` are explicitly marked `estimated`; they are not measured or final edit timings.

Coverage:

| Shot | Camera | Source range | Visible performance tracks | Shot size / FOV |
|---|---|---:|---:|---|
| 1 | A | 0.0–24.0s | Huang + Da Shu + Zhang | WS / 63° |
| 2 | B | 0.0–24.0s | Huang | MCU / 29° |
| 3 | C | 0.0–24.0s | Da Shu + Zhang | MS / 47° |

All three generated clips have independent local render ranges of 0.0–28.0s, with performance at 2.0–26.0s. Their shared scene source range remains 0.0–24.0s. The 2.0s pre/post padding follows the current Footage-Mode formula for a 24-second performance.

## Test results

- Python syntax compilation: passed.
- Bridge unit tests: 9 passed.
- Bundled `footage_mode.py selftest`: passed (4 example shots).
- Bundled `adapt_acting.py selftest`: passed (4 blocks / 4 legacy single-character shots).
- Dewei Bridge → Footage-Mode end-to-end run: QC PASS, 3 prompts generated.
- Parallel overlap assertion: first interval contains all three characters simultaneously.
- Camera filtering: B contains Huang's visible track only; C contains Da Shu and Zhang; explicitly enabled offscreen dialogue is retained in audio.
- FOV mismatch test: correctly rejected.
- Missing exact `[SPECIAL CAMERA OVERRIDE]` tag test: correctly rejected.
- Overlong prompt test: correctly rejected; `all` wrote only `qc-report.txt`, not `shots.json` or prompt sidecars.

## Remaining limitations / production cautions

1. This validates structured prompt generation and QC, not actual video-model output. No generated video was rendered in this test.
2. The 24-second scene duration and beat timings are estimates. They must be reviewed against the screenplay, dialogue delivery, and intended edit.
3. The Bridge config currently requires explicit character-to-asset mapping and coverage planning. It does not invent shot sizes, camera movement, lighting, or LUTs.
4. If explicit event timing is omitted, the Bridge distributes beats across the scene per character and labels them estimated. This fallback is provisional and should not be used as final editorial timing.
5. Prompt length uses separate Latin-word and CJK-character budgets; this is a pragmatic cross-language policy and should be recalibrated if a target video model has different prompt limits.
