# Footage-Mode 2.2-A Event Extraction Report — 天堂号底舱

- Engine: `2.2.0-alpha.1`
- Source type: `acting_task`
- Event atoms extracted: **52**
- Character tracks: **7**
- High-priority candidate events: **30**
- Shared event clusters: **4**
- Validation issues: **0**

## Event-type counts

- `authority_claim`: 14
- `dialogue_turn`: 8
- `group_shift`: 12
- `information_reveal`: 7
- `performance_action`: 4
- `physical_action`: 11
- `prop_state_change`: 6
- `question_or_challenge`: 6
- `reaction`: 8
- `reveal_or_recognition`: 8
- `threat_or_coercion`: 9

## High-priority events

- **S08-008 · 武寒青** — 口罩被大头扯下后，察觉对方身份不对，目光转向武天豪没有十字标记的白大褂 [prop_state_change, reveal_or_recognition]
- **S08-010 · 武寒青** — 眼看木桶被踢翻，向武天豪大喊：“你到底是谁？要干什么？” [prop_state_change, dialogue_turn]
- **S08-011 · 武寒青** — 看到猪仔们开始下跪，急切制止：“喂！不要跪！” [group_shift, reveal_or_recognition, authority_claim]
- **S08-012 · 武寒青** — 被大头喝令下跪，挺住并反问：“官再大，也跟我一样都是人！凭什么要我给你下跪！” [authority_claim, threat_or_coercion, question_or_challenge]
- **S08-013 · 武寒青** — 被大头按倒在地，挣扎着喊：“我要告你们！一会儿警察就会把你们全抓起来！我要让你们这帮混蛋永远记住，这是美利坚，不是大清国！” [physical_action, authority_claim, threat_or_coercion]
- **S08-015 · 武寒青** — 看着武天豪训斥猪仔，忍不住反驳：“大清国如果给人活路的话，他们会冒这么大的风险漂洋过海来这里吗？” [authority_claim]
- **S08-016 · 武寒青** — 听到武天豪以家人威胁猪仔，难以置信地摇头 [threat_or_coercion, reaction]
- **S08-017 · 武寒青** — 直视武天豪，指出他的行为本质：“你一个大清国的官员，怎么能这么威胁自己国家的公民，这跟绑架勒索有什么区别？” [authority_claim, threat_or_coercion]
- **S08-018 · 武寒青** — 看见猪仔们疲惫而茫然，强调他们的身体状况：“他们坐了这么久的船，还有很多都是病人，他们现在最需要的是休息！” [group_shift, reveal_or_recognition, dialogue_turn]
- **S08-019 · 武寒青** — 发现猪仔开始附和武天豪，望向人群，深感意外，最终闭嘴 [group_shift, reveal_or_recognition, reaction]
- **S08-021 · 武天豪** — 一脚踢翻厨师面前的木桶，让白扁豆滚落一地 [prop_state_change]
- **S08-022 · 武天豪** — 面对武寒青的追问，报出官职：“大清国御前蓝翎侍卫，正六品朝廷命官。” [authority_claim, question_or_challenge]
- **S08-023 · 武天豪** — 观察猪仔们因官职而跪下，不急于制止 [physical_action, group_shift, authority_claim]
- **S08-024 · 武天豪** — 冷笑着回应武寒青的警察威胁：“这是大清国的船！美利坚警察不会上这艘船！你可死心了吧！” [authority_claim, threat_or_coercion]
- **S08-025 · 武天豪** — 转向猪仔们巡视，带着轻蔑训斥：“好好的大清国子民不做，倒愿意被当作‘猪仔’卖到洋人的地方。不成器的奴才！” [group_shift, authority_claim]
- **S08-026 · 武天豪** — 强调国家与个人责任：“哪一朝哪一代没有穷人？大清国不是完美的，也可能会有一些暂时的小困难。但遇到困难，要跟国家一起扛，而不是做卖国贼，一走了之！再说了，你们走得了吗？就算你们走了，你们的家人走得了吗？” [authority_claim, threat_or_coercion]
- **S08-027 · 武天豪** — 抚鼻强忍恶臭，以克制而自信的口吻宣讲新政：“自推行新政以来，大清国日新月异，国力蒸蒸日上。但就是有些人不愿意看到国家富强，不愿意看到百姓尽享天人之乐。” [reveal_or_recognition, authority_claim]
- **S08-029 · 武天豪** — 停顿，观察猪仔们是否听进去，再抛出关键信息：“此刻，这个朝廷钦犯孙逸仙就藏在这条船上！抓捕乱党……就是你们立功的机会！” [group_shift, threat_or_coercion, information_reveal]
- **S08-030 · 武天豪** — 转向猪仔们，压低姿态诱导他们表态：“你们需要休息吗？你们要放弃这个升官发财的机会吗？你们需要一个女人告诉你们该怎么做吗？” [group_shift, information_reveal]
- **S08-033 · 大头** — 一把扯下武寒青的口罩，发现她是女人，短暂意外 [prop_state_change, reveal_or_recognition]
- **S08-035 · 大头** — 朝武寒青喝令：“跪下！” [physical_action, threat_or_coercion]
- **S08-036 · 大头** — 一用力将武寒青按倒在地，持续压制她的挣扎 [physical_action, threat_or_coercion]
- **S08-037 · 蛇头** — 见猪仔有人跪下，立刻狐假虎威地呵斥：“见了大人，还不下跪！” [physical_action, group_shift, authority_claim]
- **S08-041 · 厨师** — 木桶被踢翻后受惊，停在原地，不敢再动 [prop_state_change, reaction]
- **S08-043 · 猪仔群体** — 木桶被踢翻，受到惊吓，纷纷向后退 [prop_state_change, group_shift]
- **S08-044 · 猪仔群体** — 听到武天豪自称朝廷命官，部分人不自觉地跪下 [physical_action, authority_claim]
- **S08-045 · 猪仔群体** — 受到蛇头呵斥后，尚未跪下的人陆续跪下 [physical_action, group_shift]
- **S08-046 · 猪仔群体** — 武寒青阻止他们下跪时，几个人抬头看她，仍不确定该听谁的 [authority_claim, reaction]
- **S08-047 · 猪仔群体** — 武天豪训话时面面相觑，交头接耳，窃窃私语 [group_shift]
- **S08-050 · 猪仔群体** — 猪仔甲先开口后，其他人受到鼓励，赞同声逐渐此起彼伏 [group_shift]

## Validation

- PASS: all extracted events retain source-line traceability and review flags.

## Interpretation boundary

This report measures extraction structure only. It does not certify dramatic importance, directorial quality, historical accuracy, or shot sufficiency. All event records remain review-required; timings and camera choices are intentionally absent.
