# Art Direction and Visual Bible — Footage-Mode 2.1

## Purpose

Add an art-direction layer without changing the 1.1 rendering pipeline or 2.0 intelligence checks. The module converts existing scene metadata and `assets[]` cards into a structured, editable first-pass Visual Bible.

## Asset mapping

| Scene asset kind | Visual Bible section |
|---|---|
| `character` | `casting_and_character_visuals` and an initial `costume_and_wardrobe` look |
| `prop` | `props` |
| `set`, `location` | `sets_and_locations` |
| `wardrobe`, `costume` | `costume_and_wardrobe` |

The source asset `id`, `tag`, `state`, and `anchor` are retained. Existing anchors are treated as source material, not silently expanded into unsupported facts.

## Lifecycle

Every generated record starts at `draft`. Human review may advance it to `director_approved`; production may lock it as `production_locked`. A production-locked record must include `director_approved_by`. The tool never auto-approves an asset.

## Historical accuracy

`scene.period` (or `scene.historical_period`) and `scene.region` (or `scene.country`) provide the initial period/region context. If either is absent, validation reports `INCOMPLETE`. The Visual Bible records evidence requests for period, regional, wardrobe, prop, and architecture references. It does not claim historical accuracy without evidence.

## API

```python
from art_director import draft, validate

visual_bible = draft(scene_document)
report = validate(visual_bible, source_doc=scene_document)
```

- `draft(doc) -> dict`: returns a schema-versioned Visual Bible.
- `validate(visual_bible, source_doc=None) -> dict`: returns `PASS`, `INCOMPLETE`, or `FAIL` with errors and warnings.
- Aliases: `draft_visual_bible` and `validate_visual_bible`.

## Integrated CLI

```bash
# Draft the Visual Bible and run all preflight modules
python scripts/preflight_2_1.py assets/example-scene.json \
  --draft-visual-bible out/visual-bible-draft.json \
  -o out/preflight-2.1.json

# After human review, validate the edited Visual Bible against the source scene
python scripts/preflight_2_1.py assets/example-scene.json \
  --visual-bible out/visual-bible-approved.json \
  -o out/preflight-2.1-approved.json
```

The draft is expected to remain `INCOMPLETE` until required context is supplied and records are reviewed. `PASS` means the declared structure and references are consistent; it is not a substitute for artistic, casting, costume, production-design, or historical sign-off.
