# Automatic Shot Planner 1.0

## Purpose

`auto_shot_planner.py` creates a deterministic, reviewable first-pass coverage proposal
from the same ACTING TASK text and bridge configuration used by `performance_bridge.py`.
It does not replace a director, storyboard artist, cinematographer or editor.

## Quick start

```bash
python scripts/auto_shot_planner.py assets/dewei-acting-task.txt assets/dewei-bridge-config.json -o out/auto-scene.json --max-shots 14
python scripts/footage_mode.py all out/auto-scene.json -o out/rendered/
```

Optional controls:

- `--max-shots 14`: hard cap for proposed coverage, including the master.
- `--master-character "黄德威"`: explicitly choose the master-shot primary. If omitted,
  the planner selects the character with the greatest total track duration; screenplay
  order breaks ties.

## Shot proposal logic

1. **Master** — one continuous WS covering the complete scene and all mapped characters.
2. **Speaker coverage** — one MCU for ordinary dialogue, CU when text contains a small
   set of explicit high-intensity cues. Camera remains static by default.
3. **Reaction coverage** — a separate CU when another character has an overlapping
   track in the dialogue interval.
4. **Two-shot** — an MS when two characters overlap during a dialogue interval of at
   least 1.5 seconds.
5. **Action detail** — optional DETAIL insert when a non-dialogue action contains
   explicit object/contact terms (for example, pick up, pour, cup, phone).

Proposals are time-aligned to the source performance events. Different characters'
overlapping actions remain parallel. The planner never compresses authored timing.
If timing is estimated upstream, the generated QC report retains the warning.

## What is inferred, and what is not

The planner's shot types, shot sizes and static camera defaults are heuristics.
Each proposed shot carries `planner.kind`, `planner.purpose`, `planner.reason`,
`planner.confidence` and `planner.review_required=true`.

The planner does **not** determine exact blocking, eyelines, screen direction, lens
placement, actor marks, prop hand, emotional subtext, edit points or final sequence
order. It cannot confirm a prop is actually visible from prose alone. Review these
items before rendering or generation.

## Design boundary

The planner creates coverage options, not an edit decision list. A 12-shot plan means
12 independent raw-footage prompts, not a 12-shot final cut. Final selection,
synchronization, pacing, sound mix and assembly remain post-production tasks.
