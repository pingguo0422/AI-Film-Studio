# Bridge configuration guide

`performance_bridge.py` takes two inputs: an ACTING TASK text file and a JSON configuration file.

```bash
python scripts/performance_bridge.py acting.txt bridge-config.json -o out/scene.json
python scripts/footage_mode.py all out/scene.json -o out/
```

## Required configuration fields

- `scene_duration`: total scene time in seconds.
- `scene`: the Footage-Mode scene settings (location, interior/exterior, time of day, LUT, light, white balance, style, format, clip budget, padding, and negative policy).
- `assets`: the normal Footage-Mode asset cards.
- `character_assets`: exact ACTING TASK character heading name → `assets[].id` mapping.
- `coverage`: shot plan. Every shot has `shot`, `camera`, `source_range`, `primary_character`, optional `secondary_characters`, `beat`, `shot_size`, and `assets_in_frame`.

## Per-character event timing

`tracks` is keyed by the exact character name. `events[]` maps zero-based `beat_index` values to scene-time `t_in` and `t_out` values. Set `timing_source` to `authored` only when the time was explicitly supplied or measured; otherwise use `estimated`.

```json
{
  "tracks": {
    "黄德威": {
      "events": [
        {"beat_index": 0, "t_in": 0.0, "t_out": 8.6, "timing_source": "estimated"},
        {"beat_index": 1, "t_in": 8.6, "t_out": 15.8, "timing_source": "estimated"}
      ]
    }
  }
}
```

Different characters' events may overlap. Events within one character's track must not overlap. All event ranges must fit inside `scene_duration`.

If `tracks` timing is omitted for a character, the Bridge divides that character's beats evenly across the entire scene and marks them `estimated`. This is only a provisional fallback; supply explicit event timing for production.

## Coverage mapping

- `source_range: [start, end]` declares which part of the scene this shot records.
- `primary_character` must be one of the parsed ACTING TASK character names.
- `secondary_characters` selects visible supporting performers.
- `assets_in_frame` must include the asset cards for all selected visible characters.
- `include_offscreen_dialogue: true` retains dialogue from characters not visible in the shot as offscreen audio. It does not add their visual performance track.

The Bridge does not select camera size, camera movement, lighting, LUT, or editorial order. Those remain explicit coverage/scene decisions.
