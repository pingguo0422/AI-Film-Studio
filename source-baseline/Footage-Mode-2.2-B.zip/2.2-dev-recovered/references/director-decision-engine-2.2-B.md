# Director Decision / Coverage Optimizer — 2.2-B recovered specification

Status: reconstructed provisional implementation (`2.2.0-recovered-b.1`). The historical 2.2-B source files were not recoverable from the available archive/library. This specification records the recovered implementation, not an assertion that it is byte-identical to the lost work.

## Inputs

Consumes the 2.2-A event document. Every event must retain a unique `event_id`, a valid 1-based source line range, and non-empty exact source text. `linked_event_ids` must resolve. Event priorities are `high`, `medium`, or `review`.

## Coverage dimensions

Unless a director supplies `required_coverage_dimensions`, requirements are derived conservatively from `event_types`: dialogue turn → `speaker_delivery`; physical action → `action` + `consequence`; prop state change → `action` + `object_state` + `consequence` (the object-state dimension is proposed as a separate insert); group shift → `group_overview` + `staggered_response` + `group_result` (staggered response is proposed separately); threat/coercion → `pressure_source` + `target_response`; reveal/recognition → `reveal_target` + `recognizer_response`; information reveal → `information_delivery`; authority claim → `authority_delivery`; reaction → `reaction`; challenge → `challenge_delivery`; performance action → `performance_action`. Unknown event types are reported as unmapped and are not silently assigned invented evidence.

## Status contract

- `covered`: all required dimensions have explicit coverage claims in selected shots.
- `partially_covered`: at least one required dimension is claimed, but one or more required dimensions remain missing.
- `not_selected`: no required dimension is claimed by any selected shot.

An event ID merely appearing in metadata does not count. Candidate shots that are not selected do not count. A master/context shot receives no event-coverage credit unless dimensions are explicitly mapped to it.

## Optimization

A deterministic weighted greedy set-cover selector maximizes marginal event-dimension coverage under a hard shot budget. High-priority events and dramatic event types receive higher weights. Duplicate claims have zero marginal value after the dimension is covered. Shared event clusters can be represented by one common physical-action candidate, while actor-specific reaction dimensions remain on their own event IDs. Ties are deterministic.

## Master and timing policy

The engine recommends a master/context take as editorial fallback but does not let it inflate event coverage. `segment_master_range` splits only an explicitly supplied finite time range into contiguous technical segments; it does not estimate scene or performance timing. No timecodes, shot sizes, lenses, camera moves, blocking, or screen direction are invented.

## Output

The JSON report includes selected candidate shots, per-event required/covered/missing dimensions, status, source line range, selected shot IDs, weighted coverage ratio, budget statistics, and human-review flags. Coverage status describes planned evidence only; it does not certify captured footage or artistic sufficiency.
