# Dramatic Event Engine 2.2-A

## Purpose

2.2-A introduces a source-traceable event layer between screenplay/performance input and director/shot planning. It is additive: it does not replace Acting Task, Performance Bridge, Automatic Shot Planner, the 1.1 renderer, 2.0 intelligence, or 2.1 Visual Bible.

## Inputs

Two conservative first-pass input modes are supported:

1. `acting_task`: parses existing `ACTING TASK — Character` blocks and their `Moment to moment` bullets. This mode preserves the beat text and source line numbers in the supplied ACTING TASK file.
2. `screenplay`: line-oriented extraction from a screenplay text file, with an explicit comma-separated character roster. Character cues and inline `Name: dialogue` are recognized. An action line is assigned to a character only when the character name begins the line or the line explicitly names a group; mere mention of a character does not prove that character performed the action. Ambiguous agency is `UNASSIGNED`.

The screenplay parser is intentionally conservative. Complex formatting, multiline dialogue, parenthetical delivery, dual-column scripts, and ambiguous action attribution require human correction or a future parser enhancement.

## Event record

Each event carries:

- stable `event_id` and `scene_id`;
- exact source text and original 1-based source line range;
- actor and participants (only where explicit or safely attributable);
- one or more transparent `event_types`;
- observable action and verbatim dialogue;
- dramatic function as a candidate interpretation;
- before/after dramatic state, information delta, and power relation fields;
- visual evidence and candidate coverage questions;
- confidence, human-review flag, and inference boundary.

Unknown state, knowledge, motive, or power changes remain `null`/empty. This release does not invent a state transition simply because one seems dramatically likely.

## Event clusters

`event_cluster_id` and `linked_event_ids` connect separate character-track descriptions of one explicit physical occurrence (for example, a bucket being kicked over as described by the initiator, witness, cook, and crowd). Individual records remain separate because each performer has a different reaction and point of view. Staggered group responses are assigned separate phase keys where the text supports it; commands, resistance, and group compliance must not be flattened into one generic “kneeling” beat.

Clusters are rule-based candidate links, not proof that two lines refer to the same continuous take. Review them before shot planning.

## Coverage candidate logic

The engine does not output camera sizes, lenses, moves, timings, or final shot counts. It only raises candidate coverage questions for:

- prop/action state changes: action, contact, result, affected reaction;
- group shifts: group overview, early/late responders, changed group state;
- threats/authority: source of power, target response, visible power consequence;
- recognition/revelation: what is seen and who recognizes it.

A high priority is a review flag, not an instruction to create one shot per event.

## CLI

```bash
# Existing ACTING TASK input
python scripts/dramatic_event_engine.py assets/acting-task.txt \
  --scene-id S08 --scene-title '天堂号底舱' \
  -o out/events.json --report out/events-report.md

# Raw screenplay input (provide exact character names)
python scripts/dramatic_event_engine.py scene.txt --input-format screenplay \
  --roster '武寒青,武天豪,大头,蛇头,厨师,猪仔群体,猪仔甲' \
  --scene-id S08 -o out/events.json --report out/events-report.md
```

## Validation

A first-pass event must have a unique ID, exact source line and text, observable action, and `human_review_required=true`. A structural `PASS` validates traceability and schema shape only; it does not certify dramatic interpretation, artistic merit, historical accuracy, or shot sufficiency.
