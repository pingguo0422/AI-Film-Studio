# Worked example

Scene 3, "Suitcase" — one interior, four shots, two characters, one prop, one set.
Source: `assets/example-scene.json`. Reproduce with:

```
python scripts/footage_mode.py all assets/example-scene.json -o out/
```

---

## 1. The shot plan (computed, not typed by hand)

| shot | camera | size | FOV | move | perf | pad | render range | file |
|---|---|---|---|---|---|---|---|---|
| 12 | A | WS | 63° | static | 3.0s | 0.5 / 0.5 | 0.0 – 4.0 | `S03_SH012_A_v01.mp4` |
| 13 | A | MS | 47° | slow_push_in | 4.0s | 0.6 / 0.6 | 4.0 – 9.2 | `S03_SH013_A_v01.mp4` |
| 14 | B | CU | 18° | static | 3.5s | 0.5 / 0.5 | 9.2 – 13.7 | `S03_SH014_B_v01.mp4` |
| 15 | B | MCU | 29° | compound (exception) | 2.5s | 0.5 / 0.5 | 13.7 – 17.2 | `S03_SH015_B_v01.mp4` |

Padding is `clamp(0.15 × duration, 0.5, 2.0)`, so 3.0s → 0.5, 4.0s → 0.6. The 2.0s / 2.0s
pair never appears — it would eat 40–80% of a short clip.

Shot 15 is the only dynamic shot: the hint carries the exact tag, so `compound` survives.
Shot 14's hint asked for a `DETAIL` insert on the hands; the skill shot it as a `CU` on
the face and logged the deviation instead of silently obeying.

---

## 2. Shot 12 — establishing wide

```text
SCENE CONTEXT
small bedroom, second floor, interior, early morning. The mother packs a suitcase at the foot of the bed.

ACTIVE REFERENCES
@image1 - character, home: woman, late 40s, dark bob, grey cardigan, gold ring. 100% matches the reference.
@image2 - character, leaving: man, early 20s, olive jacket, army duffel. 100% matches the reference.
@image3 - prop, half packed: brown leather case, brass latches, airline sticker. 100% matches the reference.
@image4 - set, morning: brass bed frame, net curtains, floral wallpaper. 100% matches the reference.

CAMERA
Wide shot, 63 degrees diagonal FOV, eye level, locked-off static camera. One continuous shot; the camera does not cut on its own.

ACTION & TIMING
0.0s-0.5s - holds the ready pose, breathing only, no new action.
0.5s-1.9s - she lays the folded socks flat and squares the corners
1.9s-3.5s - her eyes lift to her son at the door and drop back to the case
3.5s-4.0s - holds the final pose, breathing only, no new action.

PERFORMANCE
Mother stays invested in keeping the parting ordinary. Tactic: her hands work while her eyes measure the room, checking whether her son is watching, and return to the socks the moment he looks up.

PHYSICS
Rigid - suitcase, brass bed frame: solid mass and contact, weight settles into the support, nothing bends or passes through another object.
Soft - net curtains, cardigan: follows the body, folds settle naturally, the silhouette stays readable.

LIGHT & GRADE
LUT-teal-amber-A across every shot of this scene. Main light: window left, cool daylight, soft overcast, low contrast morning. White balance 5600K.

AUDIO
Room tone, birds outside. Zip, cloth.

STYLE
1990s 16mm home-movie texture, muted earth palette, soft halation. 16:9, 24 fps, fine grain.

POSITIVE LOCKS
@image1, @image2, @image3, @image4 stay identical to their references in every frame: faces, costume, props and light direction hold from the first frame to the last.
```

`NEGATIVE (separate field): text, watermark, subtitles, logo, extra fingers, deformed
hands, duplicated limbs, face morphing, identity change, rubbery cloth, intersecting
geometry, clipped fabric, duplicate characters, stutter, frozen frame, blown highlights`

What to notice:

- Padding is inside the timecode track, before beat 1 and after the last beat — the editor
  gets handles without a second generation.
- `16:9` and `16mm` coexist: the FOV rule bans **lens** millimetres, not film gauge.
- Airflow is `none`, so there is no air sentence at all — not "no wind", nothing.
- Identity is stated once, at the end, as a reference match — not re-described in the body.

---

## 3. Shot 15 — exception mode

```text
SCENE CONTEXT
small bedroom, second floor, interior, early morning. He steps in and she looks up.

ACTIVE REFERENCES
@image1 - character, home: woman, late 40s, dark bob, grey cardigan, gold ring. 100% matches the reference.
@image2 - character, leaving: man, early 20s, olive jacket, army duffel. 100% matches the reference.
@image4 - set, morning: brass bed frame, net curtains, floral wallpaper. 100% matches the reference.

CAMERA
Medium close-up, 29 degrees diagonal FOV, chest level, compound move, push and pan together. One continuous shot; the camera does not cut on its own.

ACTION & TIMING
0.0s-0.5s - holds the ready pose, breathing only, no new action.
0.5s-1.6s - he steps into the doorway, bag on his shoulder
1.6s-3.0s - he answers her look and she holds it
3.0s-3.5s - holds the final pose, breathing only, no new action.

PERFORMANCE
He plays it light so she can keep the morning ordinary. She lets him, and holds the look one beat too long.

PHYSICS
Rigid - bed frame: solid mass and contact, weight settles into the support, nothing bends or passes through another object.
Soft - net curtains: follows the body, folds settle naturally, the silhouette stays readable.

LIGHT & GRADE
LUT-teal-amber-A across every shot of this scene. Main light: window left, cool daylight, soft overcast, low contrast morning. White balance 5600K.

AUDIO
Room tone. Door hinge. SON at 1.9s: "I'll write."

STYLE
1990s 16mm home-movie texture, muted earth palette, soft halation. 16:9, 24 fps, fine grain.

POSITIVE LOCKS
Reinforced lock for this shot: @image1 keeps the same face, costume and silhouette on the last frame as on the first, through the whole move. @image1, @image2, @image4 stay identical to their references in every frame: faces, costume, props and light direction hold from the first frame to the last.
```

The risk warning is **not** in this text. It lives in the QC report, because telling a model
"this may drift" invites drift.

---

## 4. QC report

```text
QC REPORT - scene 3 (Suitcase) - 4 shots - PASS

shot | render range      | performance range | size/FOV  | move
  12 |   0.0s -   4.0s |   0.5s -   3.5s | WS      63 | static
  13 |   4.0s -   9.2s |   4.6s -   8.6s | MS      47 | slow_push_in
  14 |   9.2s -  13.7s |   9.7s -  13.2s | CU      18 | static
  15 |  13.7s -  17.2s |  14.2s -  16.7s | MCU     29 | compound

EXCEPTION MODE - risk warning, report only, never in the prompt
  shot 15: high risk of asset drift, facial distortion and geometry clipping; reinforced identity lock injected.

HINT DEVIATIONS
  shot 14: the hint asked for a detail insert on the hands; a CU on the face keeps identity locked and still carries the latch beat
```

No warnings: every padding value matches the formula, the timeline is contiguous, every
tag appears in its prompt, and every prompt is inside the word budget.

---

## 5. What a failure looks like

The gate is not decorative. Three common inputs and what the validator does with them:

| Input | Result |
|---|---|
| `camera_move: "whip_pan"` with no `[SPECIAL CAMERA OVERRIDE]` | downgraded to `slow_pan`, `[W]` logged, `CAMERA DOWNGRADES` section in the report — never silent |
| `performance.duration: 9.0` with 2.0s pads (13.0s total) | pads cut to 0.4s, `[W]` logged; at 9.8s the shot is rejected with `[E] … split the shot` |
| `shot_size: "MS"` but prompt written from a 40° habit | `[E] FOV 40 is not an anchor value`; re-render at 47° |

Any `[E]` means the shot is not delivered. `[W]` is reported and accepted, on the record.

---

## 6. From prose to beats — the adapter

The acting pass writes prose. `assets/example-acting-task.txt` holds four blocks; shot 13's
is:

```text
ACTING TASK — MOTHER [shot 13] (the work happens in her eyes):
SCENE DIRECTION: keep it ordinary, ask nothing directly.
MOTIVE: superstition — a calm send-off protects him.
GOAL: leave him calm, learn whether he is lying about writing.
OBSTACLE: the question she is not allowed to ask.
TACTIC: she asks about the socks without turning her head, watching his reflection,
measuring whether the answer is true.
Moment to moment:
— folds the shirt, presses it flat, does not look up
— "Don't forget the socks." — does not turn her head, watches his reflection in the window
— waits, hands still on the lid, lets the silence do the asking
(Safety: gaze always engaged in the task; natural blink cadence.)
```

```
python scripts/adapt_acting.py adapt assets/example-acting-task.txt \
       assets/example-scene.json -o out/filled.json --overwrite
```

Shot 13 has three beats and 4.0s. The middle beat carries a four-word line, so it weighs
more; the allocation is 0.84 / 2.32 / 0.84, rounded to a tiling track:

| KE | range | action | dialogue |
|---|---|---|---|
| KE01 | 0.0 – 0.8 | folds the shirt, presses it flat, does not look up | |
| KE02 | 0.8 – 3.2 | does not turn her head, watches his reflection in the window | "Don't forget the socks." at 0.8s |
| KE03 | 3.2 – 4.0 | waits, hands still on the lid, lets the silence do the asking | |

The composition also produces the `PERFORMANCE` block: the shared scene direction, then
the tactic under the character's name, then the standing eye clause. The motive, goal and
obstacle are parsed and kept in the record — they explain the tactic to a human, they are
not prompt text.

**The honest part:** those seconds are inferred. `timing_source` is `estimated`, and the
QC report says so on every adapted shot:

```text
  [W] shot 13: beat timing estimated from prose; check it against the edit before cutting
```

That warning is not noise. It is the difference between "the performance runs 4.0s and
here is where the beats fall" and "here is where I guessed the beats fall".
