# Input schema

Reference for step 2–3 of the workflow. Working example: `assets/example-scene.json`.
Every field the scripts read is listed here; unknown fields are ignored, never guessed.

---

## Top level

```jsonc
{
  "schema_version": "1.1",
  "scene": { … },        // required
  "assets": [ … ],       // required
  "coverage": [ … ]      // required
}
```

---

## `scene`

| Field | Type | Req | Default | Notes |
|---|---|---|---|---|
| `seq` | int | yes | — | sequence number, drives filenames and ids |
| `title` | str | no | `""` | used in the QC header only |
| `location` | str | yes | — | plain place description, no camera language |
| `interior` | bool | yes | — | drives `interior` / `exterior` in block 1 |
| `time_of_day` | str | yes | — | `"early morning"`, `"night"` |
| `lut` | str | yes | — | **one** LUT id for the whole scene |
| `light` | obj | yes | — | `{ "main": "window left, cool", "tone": "soft overcast" }` |
| `white_balance_k` | int | yes | — | one value for the scene, e.g. `5600` |
| `global_style` | str | no | `null` | ≤ 40 words, inherited look |
| `airflow` | enum | no | `"none"` | `none` · `soft_breeze` · `short_gust` |
| `format` | obj | no | `{}` | `{ "aspect": "16:9", "resolution": "1080p", "fps": 24, "grain": "fine" }` |
| `max_clip_seconds` | num | no | `10.0` | budget for padding + performance |
| `padding` | obj | no | `{"mode":"auto"}` | `mode`: `auto` \| `fixed`; `fixed` adds `pre`, `post` |
| `negative` | obj | no | `{"mode":"separate"}` | `mode`: `separate` \| `fold`; optional `items` |

`padding.mode = "fixed"` is for shots that need long editorial handles. It still obeys the
clip budget — if it does not fit, the budget wins and the script warns.

---

## `assets[]`

| Field | Type | Req | Notes |
|---|---|---|---|
| `id` | str | yes | stable, lowercase, used by `assets_in_frame` |
| `kind` | str | yes | `character` · `prop` · `set` · `wardrobe` |
| `tag` | str | yes | `@image1` … in load order, or the user's own tags |
| `state` | str | no | the state this card describes: `"home state"`, `"rain-soaked"` |
| `anchor` | str | yes | ≤ 25 words; distinguishing, not a full description |
| `lock` | bool | no | `true` = identity-critical, restated in `POSITIVE LOCKS` |

One card per **state**. A costume change is a second card, not an edited anchor.

---

## `coverage[]`

| Field | Type | Req | Notes |
|---|---|---|---|
| `shot` | int | yes | shot number inside the scene |
| `camera` | str | no | `"A"`, `"B"` … defaults to `A` |
| `beat` | str | yes | what this shot is for; one sentence |
| `shot_size` | enum | yes | `DETAIL` `ECU` `CU` `MCU` `MS` `WS` `EWS` `ARCH` |
| `render_mode` | enum | no | `AutoTrim` (default) · `FullTimeline` |
| `assets_in_frame` | [str] | yes | asset ids; order = tag order in the prompt |
| `elements_in_frame` | obj | no | `{ "rigid": ["suitcase"], "soft": ["cardigan"] }` |
| `camera_move` | enum | no | `static` default; see R7 for the whitelist |
| `camera_height` | str | no | `"eye level"` default |
| `axis_side` | str | no | `"left"` \| `"right"` — screen direction |
| `coverage_group` | str | no | shots sharing an axis share a group |
| `crossing` | bool | no | `true` = deliberately crosses the line |
| `dialogue` | [obj] | no | `{ "speaker", "line", "at" }`, `at` in performance seconds |
| `audio` | obj | no | `{ "ambience", "sfx": [ ], "music": null }` |
| `performance` | obj | no | see below |
| `hint` | obj | no | see below |
| `deviation` | obj | no | `{ "from_hint": bool, "reason": str }` |

### `render_mode`

- `AutoTrim` — the platform decides clip length; padding is expressed in the prompt as
  pose-holding lines. Default.
- `FullTimeline` — duration is pinned; timecodes in the prompt are authoritative and the
  editor cuts on them.

Both render identical prompt text in this skill; the flag tells downstream tooling whether
the timecodes are contractual.

### `performance`

| Field | Type | Notes |
|---|---|---|
| `duration` | num | seconds of performance, padding excluded |
| `source` | str | `"provided"` \| `"inferred"` — set `inferred` when derived from the script |
| `timing_source` | str | `"authored"` (default) \| `"estimated"` — `estimated` means the beat seconds were allocated from prose by the adapter |
| `acting` | str | the performance pass block, condensed to ≤ 70 words |
| `ke` | [obj] | key events: `{ "id", "t_in", "t_out", "action" }` |

`ke` rules: first `t_in = 0`, contiguous with no gaps or overlaps, last `t_out = duration`.
Actions are observable behaviour, not emotion labels.

`timing_source: "estimated"` is a promise, not a decoration: the seconds were derived, not
measured. The QC report raises `[W]` for those shots, because a cut point that is 0.4s off
is invisible in the report and expensive in the edit.

### `hint`

```jsonc
{
  "raw": "close on her hands, she hesitates",   // the 【 】 content, verbatim
  "shot_size": "CU",                            // intent only, validated against R3
  "camera_move": "slow_push_in",                // gated by R7
  "airflow": null,                              // null = inherit scene
  "special_camera_override": false,             // exact tag present?
  "style_override": null                        // ≤ 15 words, must stay in the LUT family
}
```

A hint **never** carries `duration`, `fov`, `padding`, `lut` or timecodes. If the raw text
contains them, they are ignored and the QC report notes the ignored claim.

---

## Output artifact (`out/shots.json`)

Produced by `plan`, consumed by `render` and `check`.

```jsonc
{
  "schema_version": "1.1",
  "scene": { "seq": 3, "lut": "…", "global_style": "…", "format": { … },
             "negative": { "mode": "separate", "items": [ … ] } },
  "shots": [
    {
      "seq": 3, "shot": 12, "camera": "A", "take": 1,
      "filename": "S03_SH012_A_v01.mp4",
      "render_mode": "AutoTrim",
      "location": "…", "interior": true, "time_of_day": "…", "beat": "…",
      "shot_size": "MS", "fov_deg": 47, "camera_height": "eye level",
      "camera_move": "slow_push_in", "exception_mode": false,
      "axis_side": "left", "coverage_group": "…",
      "duration": 4.0, "pad_pre": 0.6, "pad_post": 0.6,
      "render_duration": 5.2,
      "performance_range": [0.6, 4.6],
      "render_range": [0.0, 5.2],
      "airflow": "none",
      "lut": "…", "light": { … }, "white_balance_k": 5600,
      "assets": [ { "id", "kind", "tag", "state", "anchor" } ],
      "rigid": [ "…" ], "soft": [ "…" ],
      "ke": [ … ], "acting": "…",
      "dialogue": [ … ], "audio": { … },
      "downgrade": null,          // or { "from", "to", "reason" }
      "source_range": [0.0, 4.0], // scene-time range in parallel_coverage mode
      "timeline_mode": "parallel_coverage",
      "performance_tracks": [ … ],
      "prompt": "…"               // filled by render, optional on disk
    }
  ],
  "prompt": "…"                    // convenience copy of the concatenated prompts
}
```


## Version 1.1 — parallel coverage extension

When `scene.timeline_mode` is `parallel_coverage`, each `coverage[]` item must include `source_range: [start, end]` in scene seconds. Its `performance.duration` must equal `end - start`. Each output clip has an independent local render timeline beginning at zero; source ranges may overlap across cameras.

`performance.tracks[]` preserves the selected character tracks. Each track includes `character_id`, `character_name`, `role`, optional `motive`, `goal`, `obstacle`, `tactic`, `safety`, and `events[]`. Each event includes `id`, `beat_index`, local `t_in`, local `t_out`, observable `action`, optional `dialogue`, and `timing_source`. Events may overlap across different characters, but may not overlap within one character track.

`performance.ke[]` is a derived atomic tiling of the shot-local duration. Each KE retains `t_in`, `t_out`, `action`, and `actors[]`; each actor entry identifies the character and event IDs active in that interval. This projection exists for renderer compatibility. The character tracks remain the authoritative performance data.

The Bridge input configuration supplies `scene_duration`, `character_assets`, optional per-character event timing, and `coverage[]` mappings. Each coverage item names `primary_character`, optional `secondary_characters`, and camera/asset fields. Characters not selected for a shot are excluded from its visible performance tracks. Their dialogue is included only when `include_offscreen_dialogue=true`.
