# Footage-Mode 2.0 — Intelligence Extension Schema

This is an additive extension to the 1.1 scene format. Existing 1.1 fields and
rendering behavior remain valid. The new preflight is advisory and does not alter
shot prompts or silently rewrite the scene.

## Scene-level director fields

```json
{
  "scene": {
    "dramatic_question": "Will Huang protect the hall or expose its weakness?",
    "audience_premise": "The audience knows the rescue is politically dangerous.",
    "dramatic_beats": [
      {
        "id": "DB01",
        "source_range": [0.0, 8.6],
        "purpose": "Zhang proposes a substitution plan",
        "audience_knows": "The plan may protect the hall but endanger the captive",
        "conceal_from_audience": "Whether Huang has already decided",
        "subtext": "Zhang is testing Huang's appetite for risk",
        "visible_cues": ["Zhang watches Huang before finishing the proposal"]
      }
    ]
  }
}
```

## Spatial geography

Coordinates are arbitrary consistent scene-plan units, not metres. Use a fixed
top-down coordinate system for the whole scene.

```json
{
  "scene": {
    "geography": {
      "origin": "north-west corner of the room",
      "axis": {"characters": ["char-huang", "char-da"]},
      "character_anchors": {
        "char-huang": [2.0, 4.0],
        "char-da": [6.0, 4.0]
      },
      "blocking": [
        {"character_id": "char-huang", "t_in": 0.0, "t_out": 12.0,
         "position": [2.0, 4.0], "facing": "east", "status": "seated"}
      ]
    }
  },
  "coverage": [
    {"shot": 1, "coverage_group": "hall-dialogue",
     "camera_position": [4.0, 1.0], "camera_look_at": [4.0, 4.0]},
    {"shot": 2, "coverage_group": "hall-dialogue",
     "camera_position": [4.0, 2.0], "camera_look_at": [2.0, 4.0]}
  ]
}
```

The axis is the line between the two named character anchors. A camera's side is
computed from the signed 2D cross product. Cameras in one coverage group should
remain on the same side unless the shot explicitly sets `crossing: true`. An
intentional crossing should include `crossing_reason`.

## Shot-level director fields

```json
{
  "director": {
    "dramatic_purpose": "Observe Huang's response without revealing his decision",
    "audience_knowledge": "The audience knows the proposal is dangerous",
    "subtext": "Huang is evaluating whether Zhang is expendable",
    "visible_cues": ["eyes stay on the cup", "thumb stops rotating the rim"]
  }
}
```

Do not put unobservable mental states in `visible_cues`. Internal state and
subtext are editorial interpretation, not literal visual instructions.

## Continuity snapshots

Use `state_snapshot` to record only facts that must agree across simultaneous
coverage of the same source time. Missing fields are not guessed.

```json
{
  "state_snapshot": {
    "characters": {"char-huang": {"position": "seated", "facing": "east"}},
    "props": {"tea-cup": {"owner": "char-huang", "hand": "right", "fill": "half"}},
    "wardrobe": {"char-huang": "dark suit, jacket buttoned"},
    "lighting": {"key_direction": "frame-left"},
    "environment": {"door": "closed"}
  }
}
```

The preflight compares snapshots only where source ranges overlap. If no valid
`source_range` or no snapshots are provided, the report is INCOMPLETE rather than
claiming continuity has passed.

## Preflight

```bash
python scripts/preflight_2.py scene.json -o out/preflight-2.0.json
```

Exit codes: `0` = no detected errors (may still be INCOMPLETE); `1` = detected
spatial or continuity errors. Director suggestions always require human review.


## Complete working example

Run the fully annotated example:

```bash
python scripts/preflight_2.py assets/example-scene-2.0.json -o out/example-preflight-2.0.json
```

The example supplies axis anchors, camera positions, blocking, overlapping source ranges, director annotations, and matching continuity snapshots. It is designed to produce `PASS` for the spatial and continuity checks.
