# Performance-to-Coverage Bridge 1.0

Status: implementation baseline. This specification defines the contract between Acting Skill 2.0 and Footage-Mode. It does not change the creative authority of either layer.

## 1. Responsibilities

- **Acting Skill 2.0** owns dramatic interpretation, character objectives, tactics, safety constraints, and scene-level per-character performance tracks.
- **Bridge** owns parsing/normalization, explicit character-to-asset mapping, source-time mapping, shot coverage selection, local-time clipping, and conversion into Footage-Mode input.
- **Footage-Mode** owns shot optics, camera safety, padding, prompt rendering, physical continuity language, and technical QC.
- **Post-production** owns editorial selection, synchronization, assembly, sound mix, and final grade.

The Bridge must not invent dramatic intent, rewrite dialogue, or silently change authored timing.

## 2. Two independent clocks

Every scene has a `scene_duration` and a source timeline `[0, scene_duration]`. Every shot has:

- `source_range: [start, end]`: the scene-time interval represented by this shot.
- `performance.duration = end - start`: the local performance interval sent to the video model.
- `render_range: [0, render_duration]`: local generated-clip time, including padding.

Coverage shots may share or overlap source ranges. Their generated clips are independent and therefore may each start at local render time zero. A global cursor must never serialize parallel coverage.

## 3. Character tracks

A performance track is keyed by stable `character_id` and retains `character_name`, `motive`, `goal`, `obstacle`, `tactic`, `scene_direction`, `safety`, and an ordered `events[]` list. Each event has a stable event id, authored beat index, source `t_in`/`t_out`, observable action, optional dialogue, and timing provenance.

Different characters' events may overlap. Events belonging to the same character may not overlap unless an explicit future schema extension declares a compound action. The Bridge must preserve overlap across characters.

## 4. Shot coverage mapping

Each coverage item declares:

- unique `shot` and `camera` identifiers;
- `source_range`;
- `primary_character_id`;
- `secondary_character_ids` (optional);
- `assets_in_frame` and normal Footage-Mode camera/scene fields.

Only performance events belonging to characters selected for that shot and intersecting its source range are included. Intersected events are clipped to shot-local time. Dialogue is included only when its speaker's character is selected for the shot. A shot may include an off-screen speaker only when `include_offscreen_dialogue=true` is explicitly set.

## 5. Shot-local representation

`coverage[].performance.tracks[]` preserves the selected character tracks. For compatibility with the current Footage-Mode renderer, the Bridge also emits a derived `ke[]` tiling the shot-local interval. Each atomic KE interval contains `actors[]`, one entry per character active in that interval. This is a rendering projection, not a replacement for the original tracks.

The derived `ke[]` must tile `[0, performance.duration]` exactly with no gaps or overlaps. Concurrent actor events appear together inside the same KE interval.

## 6. Timing and provenance

- Authored seconds remain `timing_source: authored`.
- Timing estimated by a model or deterministic adapter remains `timing_source: estimated` and must produce a QC warning.
- If source timing is absent, the Bridge may generate provisional estimates only when explicitly enabled; it must label every generated time and must not present estimates as measured facts.
- The Bridge never scales or compresses authored event timing to make a shot fit. Over-budget shots are split by coverage planning or blocked by QC.

## 7. Parsing contract

The parser accepts ASCII and full-width Chinese punctuation for parentheses and colons. Character names are normalized separately from optional parenthetical role notes. `Safety:` is metadata, not an action beat, whether standalone or parenthesized. Dialogue text is preserved verbatim, including Chinese quotation marks. The parser must not append safety metadata to the final beat.

Unknown labels are retained as warnings or metadata; they must not be silently folded into actions.

## 8. Footage-Mode compatibility

The Footage-Mode input remains a scene document with `scene`, `assets`, and `coverage`. New optional fields:

- `scene.timeline_mode`: `sequential` (legacy default) or `parallel_coverage`.
- `coverage[].source_range`: scene-time range; required in `parallel_coverage` mode.
- `coverage[].performance.tracks[]`: shot-local character tracks.
- `coverage[].performance.ke[]`: derived atomic intervals with concurrent `actors[]`.

In `parallel_coverage` mode, every output shot has an independent local render range and QC validates source ranges rather than enforcing non-overlap between render ranges.

## 9. QC gate

Errors block prompt delivery. Warnings allow delivery but remain visible. At minimum, QC checks:

1. Required scene, asset, coverage, and performance fields.
2. Unique shot/camera output filenames.
3. FOV exactly matches the selected shot-size anchor.
4. Unsafe camera moves require the exact `[SPECIAL CAMERA OVERRIDE]` text in that shot's raw hint.
5. All referenced assets exist and are in-frame.
6. `source_range` is valid and matches performance duration.
7. Character track events are valid, ordered, and non-overlapping within each character.
8. Derived KE tiles the local shot timeline; simultaneous actors remain grouped.
9. Dialogue speaker and timing are valid; no dialogue from excluded characters unless explicitly allowed.
10. `render_duration` respects the clip budget.
11. Prompt length 150–280 is the target; 281–320 warns; over 320 is an error; under 150 warns (the budget is a target, not permission to delete performance-critical content).
12. Any `[E]` blocks prompt files and the final delivery artifact.

## 10. Non-goals

The Bridge does not design shot size, camera movement, lighting, LUT, sound design, edit points, or final sequence order. Those remain user/Footage-Mode/post-production decisions.
