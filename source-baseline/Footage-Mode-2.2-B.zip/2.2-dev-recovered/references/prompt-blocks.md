# Prompt blocks — templates, budgets, rewrites

Reference for step 5 of the workflow. Read alongside `SKILL.md` §4 R10 and §5.

---

## 1. Order and budget

Fixed order. Do not reorder: `CAMERA` in third position is load-bearing.

| # | Block | Words | Rule |
|---|---|---|---|
| 1 | `SCENE CONTEXT` | 15–35 | where, when, one action line |
| 2 | `ACTIVE REFERENCES` | 15–25 per asset | tag, state, anchor, the 100% line |
| 3 | `CAMERA` | 15–35 | size, FOV°, height, move, oner |
| 4 | `ACTION & TIMING` | 40–70 | timecoded beats incl. padding |
| 5 | `PERFORMANCE` | 40–70 | acting task, eyes and tactics |
| 6 | `PHYSICS` | 20–45 | rigid, soft, air (air only if active) |
| 7 | `LIGHT & GRADE` | 15–35 | LUT, main light, WB |
| 8 | `AUDIO` | 10–25 | ambience, sfx, dialogue |
| 9 | `STYLE` | 10–30 | global style hint, shot override, format tail |
| 10 | `POSITIVE LOCKS` | 20–45 | identity restated once |

Language-aware total budget: Latin-script text targets 150–280 words (hard ceiling 320); CJK text targets approximately 300–560 characters (hard ceiling 700). Mixed prompts are checked against both limits independently. Over-budget prompts fail QC and are not delivered. If you must cut, cut redundant audio/style phrasing — never identity, timing, performance-critical actions or positive locks.

---

## 2. Templates

### SCENE CONTEXT
```
{location}, {interior|exterior}, {time of day}. {one sentence of action}.
```
Vary the action line per shot — this is what stops shots reading as clones. Do not repeat
the beat list here; it belongs in `ACTION & TIMING`.

### ACTIVE REFERENCES
```
@image1 — character, {state}: {anchor}. 100% matches the reference.
@image2 — prop, {state}: {anchor}. 100% matches the reference.
@image3 — set, {state}: {anchor}. 100% matches the reference.
```
- One line per asset **in this shot**. A tag with no card is an error; a card with no line
  in the shot means the asset is absent — say nothing about it.
- Anchor ≤ 25 words. Never restate age + height + full wardrobe + face shape; that
  competes with the image and flattens identity.

### CAMERA
```
{shot size}, {FOV}° diagonal FOV, {height}, {move}. One continuous shot; the camera does
not cut on its own.
```
- Move text comes from the whitelist in `SKILL.md` R7; `static` is written as
  `locked-off static camera`.
- Add a motivation clause only when the move is dynamic:
  `slow push in as she closes the lid`.

### ACTION & TIMING
Measured from the render start, so it begins before the performance:
```
0.0s–{pad_pre}s — holds the ready pose, breathing only, no new action.
{pad_pre}s–{t1}s — {KE01 action}
{t1}s–{t2}s — {KE02 action}
…
{perf_end}s–{render_end}s — holds the final pose, breathing only, no new action.
```
One line per KE. Keep the actions physical and observable; the emotion lives in
`PERFORMANCE`, not here.

### PERFORMANCE
Import from the performance pass (`acting` field). Keep the eye-work and the tactic; strip
scene-analysis prose. If the block exceeds 70 words, keep: scene direction in one clause,
the tactic, and the moment-to-moment beats keyed to dialogue.

```
{Name} is fully invested in the tactic; the work happens in the eyes. {scene direction}.
Tactic: {what they do to the partner, as verbs}. {beat} — {eye behaviour}.
Gaze stays engaged in the task, natural blink cadence.
```

### PHYSICS
```
Rigid — {list}: {weight, contact, shadow; nothing bends or passes through}.
Soft — {list}: {follows the body, folds settle, silhouette stays readable}.
Air — {soft steady breeze, mild, uniform …}          <- only when air ≠ none
```
Name only what the frame shows. Never write "physics", "collision", "simulation",
"viewport".

### LIGHT & GRADE
```
{LUT name} across every shot of this scene. Main light: {source}, {direction}, {tone},
{WB}K.
```
One LUT, one WB. Local texture tweaks go in the same sentence, not a second grade.

### AUDIO
```
{Ambience}. {sfx, sfx}. {SPEAKER} at {t}s: "{line}"
```
- `t` is measured from the render start, consistent with `ACTION & TIMING`.
- Sound only. No score, no music bed — that is post.
- Omit the block entirely when there is nothing audible.

### STYLE
```
{global style hint}. {shot override, if any}. {aspect}, {fps} fps, {grain} grain.
```
- The global hint is inherited and injected once; the override adds only what differs for
  this shot and must stay inside the scene's LUT family.
- Format tail goes here, not in `CAMERA` — mixing aspect ratio into the optics sentence
  makes the model trade one for the other.
- Describe the look with technique (`16mm texture, halation, fine grain`), never with
  equipment brands or director names.
- With no global hint and no override, the block may carry the format tail alone, or be
  dropped when format is unconstrained.

### POSITIVE LOCKS
```
{@tag}, {@tag}, {prop} and {set} stay identical to their references in every frame:
faces, costume, props, light direction hold from the first frame to the last.
```
Exception shot adds, first:
```
Reinforced lock for this shot: {subject} keeps {the two identity-critical features}
through the whole move — same face, same costume, same silhouette on the last frame.
```

### NEGATIVE (separate field)
Two supported modes, declared once per scene as `negative.mode`:

- `separate` (default) — a fixed list, kept short:
  `text, watermark, subtitles, logo, extra fingers, deformed hands, duplicated limbs,
  face morphing, identity change, rubbery cloth, intersecting geometry, clipped fabric,
  duplicate characters, stutter, frozen frame, blown highlights`
- `fold` — for platforms with no negative field. Drop the list and close
  `POSITIVE LOCKS` with one positive sentence:
  `Frame stays clean: faces, hands and garment structure fully resolved, no artifacts.`
  Do not smuggle "no …" clauses into the other blocks.

Never let the negative list contradict a positive instruction (e.g. a negative `fog` in a
shot that asks for haze).

---

## 3. Rewrites — the classic failures

| Failure | Rewrite |
|---|---|
| `character stays static, holds pose` | `holds the ready pose, breathing only, no new action` |
| `freeze at the end` | `holds the final pose, breathing only` |
| `do not cut inside the clip` | `one continuous shot; the camera does not cut on its own` |
| `physics only runs inside the viewport` | name the rigid and soft elements that are in frame |
| `avoid mesh collapse and clipping` | `folds settle, silhouette stays readable` (positive form) |
| `fabric motion from two superimposed sources` | `the sleeve settles with each movement and drifts slightly in the breeze` |
| `asset lock: woman, 47, brown bob, grey cardigan, 168cm, …` | `@image1 — character, home state: late 40s, dark bob, grey cardigan. 100% matches the reference.` |
| `same LUT, do not change color` | `LUT-teal-amber-A across every shot of this scene` |
| `medium shot, 40°` | `medium shot, 47° diagonal FOV` |
| `camera pushes in fast and pans` | `slow push in` — or, with the tag, `push and pan together, one continuous move` |
| `tense atmosphere` | `she stops folding, holds the socks, eyes on the door` |

---

## 4. Two-shot and dialogue notes

- Dialogue shots default to `MCU` 29° and `static`; a moving camera while someone speaks
  costs identity and lip sync.
- Two characters in frame: both get cards and both get tags in `ACTIVE REFERENCES`.
- Over-the-shoulder: the foreground shoulder is a soft/rigid element in frame — list it.
- Keep one screen direction per coverage group (`axis_side` left or right). Crossing the
  line needs an explicit `crossing: true` and a beat that motivates it.
- More than three characters in frame is an identity risk; split into coverage and warn.


## Language-aware prompt budget

The prompt budget is evaluated separately by writing system: Latin-script text targets 150–280 words (hard ceiling 320); CJK text targets approximately 300–560 CJK characters (hard ceiling 700). Mixed-language prompts are checked against both limits independently. This avoids treating each CJK character as if it were an English word. Over-budget output is a QC error and blocks delivery; under-target output is a warning, not a reason to invent filler.
