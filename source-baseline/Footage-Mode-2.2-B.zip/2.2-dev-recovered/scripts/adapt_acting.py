#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
adapt_acting — bridge from prose ACTING TASK blocks to footage-mode `performance`.

The upstream acting skill (tig-acting-task) writes performance as prose: scene
direction, motive, goal, obstacle, tactic, and a moment-to-moment beat list keyed to
dialogue lines. It carries no seconds. footage-mode needs `ke[]` tiling
[0, duration] exactly.

This adapter does one thing: it reads those blocks, allocates the shot duration across
the beats deterministically, and merges `performance` + `dialogue` into a scene document.
Everything it invents is exactly one thing — where the beats land in time — and it
labels that as estimated (`timing_source: "estimated"`), never as measured.

Subcommands:
    adapt   acting.txt scene.json -o out/filled.json
    selftest

No third-party dependencies. Python 3.7+.
"""

import argparse
import json
import os
import re
import sys

MIN_BEAT = 0.4
ACTING_WORD_LIMIT = 70

HEADER_RE = re.compile(r"^\s*ACTING\s+TASK\s*[—–\-:]\s*(.+?)\s*$", re.IGNORECASE)
SHOT_RE = re.compile(r"\[\s*shot\s*(\d+)\s*\]", re.IGNORECASE)
PAREN_RE = re.compile(r"[（(][^（）()]*[）)]")
LABEL_RE = re.compile(
    r"^\s*(SCENE\s+DIRECTION|MOTIVE|GOAL|OBSTACLE|TACTIC)\b[^:：]*[:：]\s*(.*)$",
    re.IGNORECASE)
MOMENT_RE = re.compile(r"^\s*MOMENT[\s\-]*TO[\s\-]*MOMENT\b.*$", re.IGNORECASE)
BEAT_RE = re.compile(r"^\s*(?:[—–\-•·*]+)\s*(.+)$")
SAFETY_RE = re.compile(r"^[\s（(]*Safety\s*[:：]?", re.IGNORECASE)
QUOTED_RE = re.compile(r'["“]([^"”]+)["”]')

LABEL_MAP = {
    "SCENE DIRECTION": "scene_direction",
    "MOTIVE": "motive",
    "GOAL": "goal",
    "OBSTACLE": "obstacle",
    "TACTIC": "tactic",
}

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass


# ---------------------------------------------------------------------------- text

def read_text(path):
    with open(path, "r", encoding="utf-8-sig") as handle:
        return handle.read()


def load_json(path):
    with open(path, "r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path, obj):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(obj, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def word_count(text):
    if not text:
        return 0
    cjk = len(re.findall(u"[\u3400-\u9fff]", text))
    latin = len(re.findall(r"[A-Za-z]+(?:['\-][A-Za-z]+)*", text))
    return cjk + latin


def speech_seconds(text):
    if not text:
        return 0.0
    cjk = len(re.findall(u"[\u3400-\u9fff]", text))
    words = len(re.findall(r"[A-Za-z0-9']+", text))
    return max(cjk / 4.0, words / 2.5)


def trim_words(text, limit):
    """Cut to a word budget on a token boundary; never mid-word."""
    if word_count(text) <= limit:
        return text
    tokens = text.split()
    kept = []
    for token in tokens:
        trial = " ".join(kept + [token])
        if word_count(trial) > limit:
            break
        kept.append(token)
    if not kept:
        kept = tokens[:limit]
    return " ".join(kept).rstrip(".,;:") + "..."


# --------------------------------------------------------------------------- parse

def new_block(header_text):
    shot = None
    match = SHOT_RE.search(header_text)
    if match:
        shot = int(match.group(1))
    name = SHOT_RE.sub(" ", header_text)
    name = PAREN_RE.sub(" ", name)
    name = name.strip(" —–-:")
    name = re.sub(r"\s+", " ", name).strip()
    return {
        "name": name or "CHARACTER",
        "shot": shot,
        "scene_direction": "",
        "motive": "",
        "goal": "",
        "obstacle": "",
        "tactic": "",
        "safety": "",
        "beats": [],
    }


def parse_beat(text):
    text = text.strip()
    if text.startswith("[") and text.endswith("]"):
        text = text[1:-1].strip()
    quoted = QUOTED_RE.findall(text)
    dialogue = quoted[0].strip() if quoted else ""
    action = QUOTED_RE.sub(" ", text)
    action = re.sub(r"\s+", " ", action).strip()
    action = action.strip("—–-:;,.")
    if not action and dialogue:
        action = "holds on the line"
    return {"dialogue": dialogue, "action": action}


def parse_blocks(text):
    blocks = []
    current = None
    label = ""

    for raw in text.splitlines():
        line = raw.rstrip()
        stripped = line.strip()
        if not stripped or stripped.startswith("```"):
            continue

        match = HEADER_RE.match(line)
        if match:
            current = new_block(match.group(1))
            blocks.append(current)
            label = ""
            continue

        if current is None:
            continue

        if SAFETY_RE.match(line):
            current["safety"] = re.sub(r"^[\s（(]*Safety\s*[:：]?\s*", "", stripped, flags=re.IGNORECASE).rstrip("）)")
            label = ""
            continue

        if MOMENT_RE.match(line):
            label = "beats"
            continue

        match = LABEL_RE.match(line)
        if match:
            key = re.sub(r"\s+", " ", match.group(1).upper())
            label = LABEL_MAP.get(key, "")
            if label:
                current[label] = match.group(2).strip()
            continue

        match = BEAT_RE.match(line)
        if match:
            beat_text = match.group(1)
            safety_match = re.search(r"[（(]\s*Safety\s*[:：].*?[）)]", beat_text, re.IGNORECASE)
            if safety_match:
                current["safety"] = safety_match.group(0)
                beat_text = beat_text[:safety_match.start()].strip()
            current["beats"].append(parse_beat(beat_text))
            label = "beats"
            continue

        # Continuation of whatever came before.
        if label == "beats" and current["beats"]:
            last = current["beats"][-1]
            last["action"] = (last["action"] + " " + stripped).strip()
        elif label and label != "beats":
            current[label] = (current[label] + " " + stripped).strip()

    return blocks


# -------------------------------------------------------------------------- timing

def allocate(beats, duration):
    """Water-filling allocation: speech time sets the weight, MIN_BEAT the floor."""
    count = len(beats)
    if count == 0:
        return None
    if duration < MIN_BEAT * count - 1e-9:
        return None

    weights = []
    for beat in beats:
        weights.append(max(0.8, speech_seconds(beat.get("dialogue")) + 0.6))

    alloc = [0.0] * count
    free = list(range(count))
    remaining = duration

    changed = True
    while changed and free:
        changed = False
        total_w = sum(weights[i] for i in free)
        if total_w <= 0:
            break
        for i in list(free):
            share = remaining * weights[i] / total_w
            if share < MIN_BEAT - 1e-9:
                alloc[i] = MIN_BEAT
                remaining -= MIN_BEAT
                free.remove(i)
                changed = True

    if free:
        total_w = sum(weights[i] for i in free)
        for i in free:
            alloc[i] = remaining * weights[i] / total_w if total_w else remaining / len(free)
    return alloc


def boundaries(durations, total):
    """Cumulative boundaries rounded to 0.1, last forced to `total`, strictly increasing."""
    edges = [0.0]
    acc = 0.0
    for value in durations[:-1]:
        acc += value
        edges.append(round(acc, 1))
    edges.append(round(total, 1))

    for index in range(1, len(edges)):
        if edges[index] <= edges[index - 1] + 1e-9:
            edges[index] = round(edges[index - 1] + 0.1, 1)

    index = len(edges) - 2
    while index >= 1 and edges[index] >= edges[-1] - 1e-9:
        edges[index] = round(edges[index] - 0.1, 1)
        index -= 1

    for index in range(1, len(edges)):
        if edges[index] <= edges[index - 1] + 1e-9:
            return None
    return edges


def compose_acting(blocks):
    parts = []
    for block in blocks:
        chunk = []
        if block.get("scene_direction"):
            chunk.append(block["scene_direction"].rstrip("."))
        if block.get("tactic"):
            chunk.append("%s: %s" % (block["name"], block["tactic"].rstrip(".")))
        if chunk:
            parts.append(". ".join(chunk))
    if not parts:
        parts = ["%s plays the beat in the eyes." % blocks[0].get("name", "The character")]
    text = ". ".join(parts).strip()
    if not text.endswith("."):
        text = text + "."
    text = text + " The work happens in the eyes."
    return trim_words(text, ACTING_WORD_LIMIT)


def build_performance(blocks, duration):
    distinct = {b.get("name") for b in blocks}
    if len(distinct) > 1:
        return None, ("multiple character tracks cannot be flattened into one KE timeline; "
                      "use performance_bridge.py to preserve parallel acting")
    duration = round(float(duration), 1)  # the whole track lives on a 0.1s grid
    beats = []
    for block in blocks:
        for beat in block["beats"]:
            beats.append({
                "speaker": block["name"],
                "dialogue": beat.get("dialogue", ""),
                "action": beat.get("action", ""),
            })
    if not beats:
        return None, "no beats in this block"

    allocation = allocate(beats, duration)
    if allocation is None:
        return None, "not enough time: %d beats need at least %.1fs, got %.1fs" % (
            len(beats), MIN_BEAT * len(beats), duration)

    edges = boundaries(allocation, duration)
    if edges is None:
        return None, "beats do not fit %.1fs once rounded to 0.1s" % duration

    key_events = []
    dialogue = []
    for index, beat in enumerate(beats):
        key_events.append({
            "id": "KE%02d" % (index + 1),
            "t_in": edges[index],
            "t_out": edges[index + 1],
            "action": beat["action"] or "holds",
        })
        if beat["dialogue"]:
            dialogue.append({
                "speaker": beat["speaker"],
                "line": beat["dialogue"],
                "at": edges[index],
            })

    return {
        "duration": round(duration, 1),
        "source": "inferred",
        "timing_source": "estimated",
        "acting": compose_acting(blocks),
        "director_context": [{
            "character": b.get("name"), "scene_direction": b.get("scene_direction"),
            "motive": b.get("motive"), "goal": b.get("goal"),
            "obstacle": b.get("obstacle"), "tactic": b.get("tactic"),
            "safety": b.get("safety"),
        } for b in blocks],
        "ke": key_events,
        "dialogue": dialogue,
    }, None


# -------------------------------------------------------------------------- assign

def assign_blocks(blocks, coverage, mode):
    """Map blocks to shot numbers. Returns (groups, errors, warnings).

    Fewer blocks than shots is legal — an insert or a cutaway often has no acting pass.
    More blocks than shots is not: something would be silently dropped.
    """
    errors = []
    warnings = []
    groups = {}

    if mode == "by-header":
        for block in blocks:
            if not block.get("shot"):
                warnings.append("block %r has no [shot N] tag; skipped" % block["name"])
                continue
            groups.setdefault(block["shot"], []).append(block)
        return groups, errors, warnings

    if len(blocks) > len(coverage):
        errors.append("%d blocks but only %d shots; extra blocks would be dropped"
                      % (len(blocks), len(coverage)))
    if len(blocks) < len(coverage):
        warnings.append("%d blocks for %d shots; the remaining shots keep their old data"
                        % (len(blocks), len(coverage)))

    for block, shot in zip(blocks, coverage):
        groups.setdefault(int(shot.get("shot") or 0), []).append(block)
    return groups, errors, warnings


def resolve_duration(shot, cli_durations, index, default_duration):
    if cli_durations and index < len(cli_durations):
        return cli_durations[index], ""
    perf = shot.get("performance") or {}
    if perf.get("duration"):
        return float(perf["duration"]), ""
    if shot.get("duration"):
        return float(shot["duration"]), ""
    if default_duration:
        return float(default_duration), "used --default-duration"
    return 0.0, "no duration"


# ---------------------------------------------------------------------------- cli

def adapt(text, scene, mode="sequential", cli_durations=None, default_duration=None,
          overwrite=False):
    blocks = parse_blocks(text)
    coverage = sorted(scene.get("coverage") or [], key=lambda s: float(s.get("shot") or 0))
    errors = []
    warnings = []

    if not blocks:
        return None, ["no ACTING TASK block found"], []

    groups, assign_errors, assign_warnings = assign_blocks(blocks, coverage, mode)
    errors.extend(assign_errors)
    warnings.extend(assign_warnings)

    by_shot = {}
    for index, shot in enumerate(coverage):
        shot_no = int(shot.get("shot") or 0)
        group = groups.get(shot_no)
        if not group:
            continue
        if shot.get("performance") and not overwrite:
            warnings.append("shot %s already has performance; kept (use --overwrite)"
                            % shot_no)
            continue
        duration, note = resolve_duration(shot, cli_durations, index, default_duration)
        if note:
            warnings.append("shot %s: %s" % (shot_no, note))
        if duration <= 0:
            errors.append("shot %s has no duration" % shot_no)
            continue
        performance, problem = build_performance(group, duration)
        if problem:
            errors.append("shot %s: %s" % (shot_no, problem))
            continue
        by_shot[shot_no] = performance

    if errors:
        return None, errors, warnings

    filled = json.loads(json.dumps(scene))
    for shot in filled.get("coverage") or []:
        shot_no = int(shot.get("shot") or 0)
        performance = by_shot.get(shot_no)
        if not performance:
            continue
        payload = dict(performance)
        shot["dialogue"] = payload.pop("dialogue")
        shot["performance"] = payload

    return filled, [], warnings


def summary(filled):
    lines = []
    lines.append("shot | beats | duration | first beat | last beat | acting words")
    for shot in sorted(filled.get("coverage") or [], key=lambda s: float(s.get("shot") or 0)):
        perf = shot.get("performance") or {}
        events = perf.get("ke") or []
        if not events:
            continue
        lines.append("%4s | %5d | %8s | %10s | %9s | %d"
                     % (shot.get("shot"), len(events), perf.get("duration"),
                        events[0].get("t_in"), events[-1].get("t_out"),
                        word_count(perf.get("acting", ""))))
    return "\n".join(lines)


def cmd_adapt(args):
    text = read_text(args.input)
    scene = load_json(args.scene)
    durations = None
    if args.durations:
        durations = [float(x) for x in re.split(r"[,\s]+", args.durations.strip()) if x]

    filled, errors, warnings = adapt(
        text, scene,
        mode=args.assign,
        cli_durations=durations,
        default_duration=args.default_duration,
        overwrite=args.overwrite,
    )

    for warning in warnings:
        sys.stderr.write("[W] %s\n" % warning)
    if errors:
        for error in errors:
            sys.stderr.write("[E] %s\n" % error)
        print("adaptation failed; nothing written")
        return 1

    if args.dry_run:
        print(summary(filled))
        return 0

    write_json(args.out, filled)
    print(summary(filled))
    print("")
    print("wrote %s" % args.out)
    print("next: python footage_mode.py all %s -o out/" % args.out)
    return 0


def cmd_selftest(args=None):
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.normpath(os.path.join(here, ".."))
    acting_path = os.path.join(root, "assets", "example-acting-task.txt")
    scene_path = os.path.join(root, "assets", "example-scene.json")

    for path in (acting_path, scene_path):
        if not os.path.exists(path):
            print("selftest: missing %s" % path)
            return 2

    blocks = parse_blocks(read_text(acting_path))
    scene = load_json(scene_path)
    print("parsed %d ACTING TASK blocks" % len(blocks))
    for block in blocks:
        print("  %-10s shot %-3s beats %d  tactic %s"
              % (block["name"], block.get("shot"), len(block["beats"]),
                 "yes" if block["tactic"] else "NO"))

    filled, errors, warnings = adapt(read_text(acting_path), scene, mode="sequential",
                                     overwrite=True)
    if filled is None:
        print("")
        for error in errors:
            print("  [E] %s" % error)
        print("selftest FAILED")
        return 1

    print("")
    print(summary(filled))
    print("")

    checks = []
    for shot in filled.get("coverage") or []:
        perf = shot.get("performance") or {}
        events = perf.get("ke") or []
        if not events:
            checks.append(("shot %s has beats" % shot.get("shot"), False))
            continue
        tiles = abs(events[0]["t_in"]) < 1e-6 and \
            abs(events[-1]["t_out"] - perf.get("duration", 0)) < 1e-6
        for first, second in zip(events, events[1:]):
            if abs(first["t_out"] - second["t_in"]) > 1e-6:
                tiles = False
        checks.append(("shot %s beats tile the duration" % shot.get("shot"), tiles))
        checks.append(("shot %s acting within budget" % shot.get("shot"),
                       word_count(perf.get("acting", "")) <= ACTING_WORD_LIMIT))
        checks.append(("shot %s timing marked estimated" % shot.get("shot"),
                       perf.get("timing_source") == "estimated"))

    failed = [name for name, ok in checks if not ok]
    for name, ok in checks:
        print("  [%s] %s" % ("ok" if ok else "FAIL", name))
    print("")
    if failed:
        print("selftest FAILED: " + "; ".join(failed))
        return 1
    print("selftest PASSED - %d blocks, %d shots adapted."
          % (len(blocks), len(filled.get("coverage") or [])))
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="adapt_acting.py",
        description="adapt prose ACTING TASK blocks into footage-mode performance data")
    sub = parser.add_subparsers(dest="cmd")

    p_adapt = sub.add_parser("adapt", help="fill a scene document with performance data")
    p_adapt.add_argument("input", help="text file holding ACTING TASK blocks")
    p_adapt.add_argument("scene", help="scene JSON with a coverage list")
    p_adapt.add_argument("-o", "--out", default="filled.json")
    p_adapt.add_argument("--assign", choices=("sequential", "by-header"),
                         default="sequential")
    p_adapt.add_argument("--durations", default=None,
                         help="comma separated, one per shot, overrides everything")
    p_adapt.add_argument("--default-duration", type=float, default=None)
    p_adapt.add_argument("--overwrite", action="store_true",
                         help="replace performance that is already present")
    p_adapt.add_argument("--dry-run", action="store_true")
    p_adapt.set_defaults(func=cmd_adapt)

    p_self = sub.add_parser("selftest", help="parse the bundled example and check the edges")
    p_self.set_defaults(func=cmd_selftest)

    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
