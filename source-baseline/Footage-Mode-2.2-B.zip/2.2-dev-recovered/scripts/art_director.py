#!/usr/bin/env python3
"""Art-direction draft and Visual Bible validation for Footage-Mode 2.1.

The module creates reviewable proposals from declared scene/assets only. It does
not invent historical facts, casting identities, or locked production decisions.
"""
from __future__ import annotations

import re

ALLOWED_STATES = ("draft", "director_approved", "production_locked")
ASSET_KINDS = {"character", "prop", "set", "location", "wardrobe", "costume"}


def _as_text(value):
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return " ".join(_as_text(x) for x in value)
    if isinstance(value, dict):
        return " ".join(_as_text(v) for v in value.values())
    return str(value).strip()


def _scene_context(doc):
    scene = doc.get("scene") or {}
    return {
        "sequence": scene.get("seq"),
        "title": scene.get("title"),
        "location": scene.get("location"),
        "interior": scene.get("interior"),
        "time_of_day": scene.get("time_of_day"),
        "period": scene.get("period") or scene.get("historical_period"),
        "region": scene.get("region") or scene.get("country"),
        "genre": scene.get("genre"),
        "dramatic_question": scene.get("dramatic_question"),
        "global_style": scene.get("global_style"),
        "lut": scene.get("lut"),
        "light": scene.get("light"),
    }


def _asset_id(asset, index):
    return str(asset.get("id") or asset.get("asset_id") or "asset-%03d" % index)


def draft(doc):
    """Return a first-pass Visual Bible; all creative proposals remain draft-only."""
    if not isinstance(doc, dict):
        raise TypeError("scene document must be a dictionary")
    assets = doc.get("assets") or []
    context = _scene_context(doc)
    characters, costumes, props, sets = [], [], [], []
    warnings = []
    for index, asset in enumerate(assets, 1):
        if not isinstance(asset, dict):
            warnings.append("Asset entry %d is not an object and was skipped." % index)
            continue
        kind = str(asset.get("kind", "")).lower()
        aid = _asset_id(asset, index)
        anchor = _as_text(asset.get("anchor"))
        record = {
            "asset_id": aid,
            "name": asset.get("name") or aid,
            "source_anchor": anchor or None,
            "reference_tag": asset.get("tag"),
            "source_state": asset.get("state"),
            "approval_state": "draft",
            "source_basis": "declared_scene_asset" if anchor or asset.get("state") else "asset_id_only",
        }
        if kind == "character":
            record.update({
                "casting_brief": anchor or "待导演补充角色外形、年龄段与表演气质；不得据此自动选定演员。",
                "visual_identity": {"silhouette": anchor or None, "face_hair": None, "distinctive_features": []},
                "performance_visual_notes": [],
            })
            characters.append(record)
            costumes.append({
                "asset_id": aid, "look_id": aid + "-look-01",
                "occasion": asset.get("state") or "场景默认状态待确认",
                "garments": [anchor] if anchor else [],
                "palette": [], "materials": [], "wear_state": None,
                "continuity_anchors": [anchor] if anchor else [],
                "approval_state": "draft", "source_basis": record["source_basis"],
            })
        elif kind == "prop":
            props.append({
                **record, "owner": asset.get("owner"),
                "design_brief": anchor or "待补充年代、材质、尺寸与使用痕迹",
                "materials": [], "condition": asset.get("state"),
                "continuity_anchors": [anchor] if anchor else [],
            })
        elif kind in ("set", "location"):
            sets.append({
                **record, "design_brief": anchor or "待补充建筑年代、空间结构与陈设依据",
                "architecture": None, "materials": [], "spatial_anchors": [],
            })
        elif kind in ("wardrobe", "costume"):
            costumes.append({
                **record, "look_id": aid + "-look-01", "garments": [anchor] if anchor else [],
                "palette": [], "materials": [], "wear_state": asset.get("state"),
                "continuity_anchors": [anchor] if anchor else [],
            })
        elif kind:
            warnings.append("Asset %s uses unsupported art-direction kind '%s'; retained in source scene only." % (aid, kind))
        else:
            warnings.append("Asset %s has no kind; art-direction category is unresolved." % aid)

    if not context.get("period"):
        warnings.append("Historical period is not declared; period-specific design and authenticity remain unverified.")
    if not assets:
        warnings.append("No scene assets were supplied; character, costume, prop and set drafts are empty.")

    return {
        "schema_version": "2.1",
        "document_type": "visual_bible",
        "project": doc.get("project") or context.get("title") or "Untitled scene",
        "scene_context": context,
        "design_intent": {
            "visual_thesis": None,
            "palette": [], "materials_language": [], "lighting_language": context.get("light"),
            "image_reference_policy": "References guide design; identity and continuity anchors must remain stable.",
        },
        "casting_and_character_visuals": characters,
        "costume_and_wardrobe": costumes,
        "props": props,
        "sets_and_locations": sets,
        "historical_accuracy_checks": [{
            "topic": "period_and_region_authenticity",
            "status": "unverified" if not context.get("period") or not context.get("region") else "review_required",
            "period": context.get("period"), "region": context.get("region"),
            "evidence_required": ["年代依据", "地域依据", "服装/道具/建筑参考来源"],
        }],
        "asset_lifecycle": {"allowed_states": list(ALLOWED_STATES), "default_state": "draft"},
        "warnings": warnings,
        "human_review_required": True,
        "policy": "Draft proposals are not casting, historical, or production approvals. Explicit director approval is required before locking.",
    }


def validate(visual_bible, source_doc=None):
    """Validate Visual Bible structure, asset references and approval lifecycle."""
    errors, warnings = [], []
    if not isinstance(visual_bible, dict):
        return {"module": "Art Director 2.1", "status": "FAIL",
                "errors": ["Visual Bible must be a JSON object."], "warnings": [], "checked_assets": 0}
    if visual_bible.get("schema_version") != "2.1":
        errors.append("schema_version must be '2.1'.")
    if visual_bible.get("document_type") != "visual_bible":
        errors.append("document_type must be 'visual_bible'.")
    sections = ("casting_and_character_visuals", "costume_and_wardrobe", "props", "sets_and_locations")
    ids = set()
    count = 0
    for section in sections:
        entries = visual_bible.get(section)
        if not isinstance(entries, list):
            errors.append("%s must be a list." % section)
            continue
        for index, item in enumerate(entries, 1):
            count += 1
            if not isinstance(item, dict):
                errors.append("%s[%d] must be an object." % (section, index))
                continue
            aid = item.get("asset_id")
            if not aid:
                errors.append("%s[%d] is missing asset_id." % (section, index))
            else:
                key = (section, str(aid), str(item.get("look_id", "")))
                if key in ids:
                    errors.append("Duplicate art-direction record: %s." % (key,))
                ids.add(key)
            state = item.get("approval_state", "draft")
            if state not in ALLOWED_STATES:
                errors.append("%s[%d] has invalid approval_state '%s'." % (section, index, state))
            if state == "production_locked" and not item.get("director_approved_by"):
                errors.append("%s[%d] is production_locked without director_approved_by." % (section, index))
            if not item.get("source_basis"):
                warnings.append("%s[%d] has no source_basis; provenance should be documented." % (section, index))
            if state == "draft":
                warnings.append("%s[%d] remains draft and is not production-authoritative." % (section, index))

    context = visual_bible.get("scene_context") or {}
    if not context.get("period"):
        warnings.append("No historical period is declared; authenticity cannot be confirmed.")
    if not context.get("region"):
        warnings.append("No region is declared; regional authenticity cannot be confirmed.")
    if visual_bible.get("human_review_required") is not True:
        errors.append("human_review_required must be true.")

    if source_doc is not None:
        source_ids = {_asset_id(a, i) for i, a in enumerate(source_doc.get("assets") or [], 1) if isinstance(a, dict)}
        bible_ids = {str(x.get("asset_id")) for section in sections for x in (visual_bible.get(section) or []) if isinstance(x, dict) and x.get("asset_id")}
        missing = sorted(bible_ids - source_ids)
        if missing:
            errors.append("Visual Bible references assets absent from source scene: %s." % ", ".join(missing))
        omitted = sorted(source_ids - bible_ids)
        if omitted:
            warnings.append("Source assets without Visual Bible records: %s." % ", ".join(omitted))

    status = "FAIL" if errors else ("INCOMPLETE" if warnings else "PASS")
    return {"module": "Art Director 2.1", "status": status,
            "errors": sorted(set(errors)), "warnings": sorted(set(warnings)),
            "checked_assets": count,
            "approval_policy": "draft -> director_approved -> production_locked"}


# Explicit aliases for callers that prefer noun-specific names.
draft_visual_bible = draft
validate_visual_bible = validate
