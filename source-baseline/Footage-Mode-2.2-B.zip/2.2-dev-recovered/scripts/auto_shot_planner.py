#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Automatic coverage proposal for Footage-Mode Bridge.

Deterministic first-pass planner. It proposes coverage from parsed Acting Skill
tracks; artistic decisions remain reviewable and are never represented as facts.
"""
import argparse
import json
import os
import re
import sys
import performance_bridge as bridge


def read_text(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        return f.read()


def read_json(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path, obj):
    parent = os.path.dirname(os.path.abspath(path))
    os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write("\n")


def intersects(ev, start, end):
    return ev["t_in"] < end - 1e-6 and ev["t_out"] > start + 1e-6


def active_tracks(tracks, start, end):
    return [t for t in tracks if any(intersects(e, start, end) for e in t["events"])]


def mapped_assets(cfg, character_names, include_props=False):
    mapping = cfg.get("character_assets") or {}
    assets = cfg.get("assets") or []
    ids = [mapping[n] for n in character_names if n in mapping]
    for asset in assets:
        kind = asset.get("kind")
        if kind in ("set", "location") or (include_props and kind == "prop"):
            ids.append(asset["id"])
    return list(dict.fromkeys(ids))


def shot_record(number, start, end, primary, secondary, size, purpose, rationale,
                kind, cfg, move="static", height="eye level", include_props=False,
                offscreen=False):
    names = [primary["character_name"]] + [x["character_name"] for x in secondary]
    return {
        "shot": number,
        "camera": "AUTO",
        "take": 1,
        "source_range": [round(start, 3), round(end, 3)],
        "primary_character": primary["character_name"],
        "secondary_characters": [x["character_name"] for x in secondary],
        "include_offscreen_dialogue": bool(offscreen),
        "beat": purpose,
        "shot_size": size,
        "render_mode": "FullTimeline",
        "assets_in_frame": mapped_assets(cfg, names, include_props),
        "elements_in_frame": {"rigid": [], "soft": []},
        "camera_move": move,
        "camera_height": height,
        "axis_side": "left",
        "coverage_group": "auto-coverage",
        "audio": {"ambience": "scene room tone", "sfx": [], "music": None},
        "planner": {
            "kind": kind,
            "purpose": purpose,
            "reason": rationale,
            "confidence": "medium",
            "review_required": True,
            "primary_character": primary["character_name"],
            "secondary_characters": [x["character_name"] for x in secondary],
            "timing_status": "inherits source track timing; inspect estimated beats"
        }
    }


def plan(acting_text, cfg, max_shots=14, master_character=None):
    duration = float(cfg["scene_duration"])
    if duration <= 0:
        raise ValueError("scene_duration must be positive")
    blocks = bridge.parse_blocks(acting_text)
    if not blocks:
        raise ValueError("No ACTING TASK blocks found")

    track_cfg = cfg.get("tracks") or {}
    asset_map = cfg.get("character_assets") or {}
    tracks = []
    for block in blocks:
        name = block["character_name"]
        if name not in asset_map:
            raise ValueError("character_assets missing mapping for %s" % name)
        events = bridge.normalize_intervals(block, track_cfg.get(name, {}), duration)
        tracks.append({
            "character_name": name,
            "character_id": asset_map[name],
            "events": events,
            "motive": block.get("motive", ""),
            "goal": block.get("goal", ""),
            "obstacle": block.get("obstacle", ""),
            "tactic": block.get("tactic", "")
        })

    master = next((t for t in tracks if t["character_name"] == master_character), None)
    if master_character and master is None:
        raise ValueError("master character not found: %s" % master_character)
    if master is None:
        # Prefer the character with the broadest authored scene presence;
        # screenplay order breaks ties deterministically.
        master = max(tracks, key=lambda t: sum(e["t_out"] - e["t_in"] for e in t["events"]))

    coverage = []
    coverage.append(shot_record(
        1, 0.0, duration, master,
        [t for t in tracks if t is not master],
        "WS",
        "Establish geography, blocking and the relationship between all present characters.",
        "A continuous master gives spatial context and editorial fallback coverage.",
        "master", cfg
    ))

    proposals = []
    for speaker in tracks:
        for event in speaker["events"]:
            if not event.get("dialogue"):
                continue
            start, end = event["t_in"], event["t_out"]
            active = active_tracks(tracks, start, end)
            others = [t for t in active if t is not speaker]
            # A speaker shot is always useful coverage for a dialogue beat.
            emotional_cues = (
                "怒", "哭", "喊", "颤", "哽咽", "失控", "激动", "冷笑",
                "shout", "cry", "trembl", "whisper", "scream"
            )
            blob = (event.get("action", "") + " " + event.get("dialogue", "")).lower()
            size = "CU" if any(x.lower() in blob for x in emotional_cues) else "MCU"
            proposals.append((100, start, "speaker", shot_record(
                0, start, end, speaker, others[:1], size,
                "Prioritize the speaker's line and readable facial performance.",
                "Dialogue is present on this character's authored/estimated performance event; restrained static coverage avoids inventing camera movement.",
                "speaker", cfg
            )))
            if others:
                listener = others[0]
                proposals.append((80, start, "reaction", shot_record(
                    0, start, end, listener, [speaker], "CU",
                    "Capture the listener's reaction while the line is delivered.",
                    "A second character has an overlapping performance interval; reaction coverage is a separate take, not a sequential event.",
                    "reaction", cfg, offscreen=True
                )))
                if end - start >= 1.5:
                    proposals.append((65, start, "two_shot", shot_record(
                        0, start, end, speaker, [listener], "MS",
                        "Preserve both sides of the exchange in a shared relational frame.",
                        "Two character tracks overlap in this interval; a medium two-shot can retain eyelines and spatial relation.",
                        "two_shot", cfg
                    )))

    prop_cues = (
        "拿起", "放下", "倒茶", "端起", "递给", "握住", "摔", "拍",
        "杯", "茶壶", "钥匙", "手机", "pick up", "put down", "pour",
        "hand", "grip", "slam", "drop", "cup", "teapot", "key", "phone"
    )
    for actor in tracks:
        for event in actor["events"]:
            if event.get("dialogue"):
                continue
            blob = (event.get("action") or "").lower()
            if any(cue.lower() in blob for cue in prop_cues):
                start, end = event["t_in"], event["t_out"]
                proposals.append((55, start, "action_detail", shot_record(
                    0, start, end, actor, [], "DETAIL",
                    "Optional detail coverage for the concrete hand/object action.",
                    "The action description contains an object/contact cue; confirm the exact prop and hand blocking before generation.",
                    "action_detail", cfg, height="table height",
                    include_props=True, offscreen=True
                )))

    # Keep a deterministic cap. Prioritize speaker coverage, then reactions,
    # then relational frames and detail inserts.
    seen = set()
    proposals.sort(key=lambda x: (-x[0], x[1], x[2], x[3]["planner"]["primary_character"]))
    for _, _, _, item in proposals:
        meta = item["planner"]
        key = (meta["kind"], tuple(item["source_range"]), meta["primary_character"])
        if key in seen:
            continue
        seen.add(key)
        if len(coverage) >= max(1, int(max_shots)):
            break
        coverage.append(item)

    # Master first; remaining coverage in source-time order.
    kind_order = {"speaker": 0, "two_shot": 1, "reaction": 2, "action_detail": 3}
    coverage = [coverage[0]] + sorted(
        coverage[1:],
        key=lambda s: (s["source_range"][0], s["source_range"][1],
                       kind_order.get(s["planner"]["kind"], 9),
                       s["planner"]["primary_character"])
    )
    for i, item in enumerate(coverage, 1):
        item["shot"] = i
        item["camera"] = chr(64 + i) if i <= 26 else "C%02d" % i

    out_cfg = dict(cfg)
    out_cfg["coverage"] = coverage
    scene = bridge.build(acting_text, out_cfg)
    kinds = {}
    for item in coverage:
        kind = item["planner"]["kind"]
        kinds[kind] = kinds.get(kind, 0) + 1
    scene["planner"] = {
        "name": "Automatic Shot Planner",
        "version": "1.0",
        "mode": "deterministic_first_pass",
        "review_required": True,
        "shot_count": len(coverage),
        "coverage_summary": kinds,
        "limits": [
            "This is a coverage proposal, not a final edit decision.",
            "The planner does not infer definitive blocking, eyelines or screen direction.",
            "Prop inserts require visual confirmation of prop identity and hand blocking.",
            "Estimated event timing remains provisional and must be checked against the edit.",
            "Shot size and camera choices are heuristic defaults, not mandatory artistic rules."
        ]
    }
    return scene


def main():
    parser = argparse.ArgumentParser(description="Generate a reviewable first-pass shot coverage plan.")
    parser.add_argument("acting_text")
    parser.add_argument("config_json")
    parser.add_argument("-o", "--out", required=True)
    parser.add_argument("--max-shots", type=int, default=14)
    parser.add_argument("--master-character", default=None)
    args = parser.parse_args()
    try:
        cfg = read_json(args.config_json)
        result = plan(read_text(args.acting_text), cfg, args.max_shots, args.master_character)
        write_json(args.out, result)
        print("Wrote %s (%d proposed shots)" % (args.out, len(result["coverage"])))
        for shot in result["coverage"]:
            meta = shot.get("planner", {})
            print("SH%03d %-13s %5.1f-%5.1fs %-5s primary=%s secondary=%s" % (
                shot["shot"], meta.get("kind", ""),
                shot["source_range"][0], shot["source_range"][1],
                shot.get("shot_size", ""), meta.get("primary_character", ""),
                ",".join(meta.get("secondary_characters", []))))
        print("Review the shot plan before running footage_mode.py all.")
        return 0
    except Exception as exc:
        print("[E] planner failed: %s" % exc, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
