#!/usr/bin/env python3
"""Cross-shot state consistency checks for Footage-Mode 2.0."""
from __future__ import annotations

STATE_KEYS = ("characters", "props", "wardrobe", "lighting", "environment")

def validate_continuity(doc):
    shots = doc.get("coverage") or []
    errors, warnings, comparisons = [], [], []
    normalized = []
    for shot in shots:
        source = shot.get("source_range")
        if not (isinstance(source, (list, tuple)) and len(source) == 2):
            source = None
        else:
            try:
                source = (float(source[0]), float(source[1]))
                if source[1] <= source[0]: source = None
            except (TypeError, ValueError): source = None
        normalized.append((shot, source))

    for i, (left, lr) in enumerate(normalized):
        if lr is None:
            warnings.append("Shot %s has no valid source_range; temporal continuity comparison skipped." % left.get("shot","?"))
            continue
        ls = left.get("state_snapshot") or {}
        for right, rr in normalized[i+1:]:
            if rr is None: continue
            overlap = min(lr[1], rr[1]) - max(lr[0], rr[0])
            if overlap <= 1e-6: continue
            rs = right.get("state_snapshot") or {}
            if not ls or not rs:
                warnings.append("Overlapping shots %s and %s lack one or both state_snapshot records." %
                                (left.get("shot","?"), right.get("shot","?")))
            for key in STATE_KEYS:
                lval, rval = ls.get(key), rs.get(key)
                if lval is None or rval is None: continue
                if lval != rval:
                    errors.append(
                        "Shots %s and %s overlap in source time but disagree on state_snapshot.%s." %
                        (left.get("shot","?"), right.get("shot","?"), key)
                    )
            comparisons.append({
                "shots":[left.get("shot"),right.get("shot")],
                "overlap_seconds":round(overlap,3),
                "checked_fields":[k for k in STATE_KEYS if k in ls and k in rs]
            })

    # Explicit hand continuity: if the same prop is present in overlapping source
    # coverage, its owner/hand must agree unless a documented transition is supplied.
    for i, (left, lr) in enumerate(normalized):
        if lr is None: continue
        lp = (left.get("state_snapshot") or {}).get("props") or {}
        for right, rr in normalized[i+1:]:
            if rr is None or min(lr[1],rr[1])-max(lr[0],rr[0]) <= 1e-6: continue
            rp = (right.get("state_snapshot") or {}).get("props") or {}
            for prop in set(lp) & set(rp):
                if lp[prop] != rp[prop]:
                    errors.append("Prop %s state differs between overlapping shots %s and %s." %
                                  (prop,left.get("shot","?"),right.get("shot","?")))
    return {
        "module":"Continuity Engine 2.0",
        "status":"FAIL" if errors else ("INCOMPLETE" if warnings else "PASS"),
        "errors":sorted(set(errors)),
        "warnings":sorted(set(warnings)),
        "comparisons":comparisons,
        "policy":"Only explicit state_snapshot fields are compared; missing data is never guessed."
    }
