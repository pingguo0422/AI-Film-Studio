#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Footage-Mode 2.2-B recovered Director Decision / Coverage Optimizer.

This module is a clean-room reconstruction from the preserved 2.2-A contract
and development plan. It is not claimed to be the missing historical 2.2-B
implementation. All coverage claims are explicit, source-linked proposals.
"""
from __future__ import annotations

import argparse
import json
import math
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
from typing import Any

VERSION = "2.2.0-recovered-b.1"
EPSILON = 1e-9

# Observable coverage requirements. These are review dimensions, not assertions
# that a shot has actually been photographed. A director may override them on
# an event with `required_coverage_dimensions` after reviewing the source.
EVENT_DIMENSIONS = {
    "performance_action": ["performance_action"],
    "dialogue_turn": ["speaker_delivery"],
    "question_or_challenge": ["challenge_delivery"],
    "physical_action": ["action", "consequence"],
    "prop_state_change": ["action", "object_state", "consequence"],
    "group_shift": ["group_overview", "staggered_response", "group_result"],
    "authority_claim": ["authority_delivery"],
    "threat_or_coercion": ["pressure_source", "target_response"],
    "information_reveal": ["information_delivery"],
    "reveal_or_recognition": ["reveal_target", "recognizer_response"],
    "reaction": ["reaction"],
}

PRIORITY_WEIGHT = {"high": 5.0, "medium": 3.0, "review": 1.0}
DRAMATIC_WEIGHT = {
    "prop_state_change": 1.35,
    "group_shift": 1.45,
    "threat_or_coercion": 1.30,
    "reveal_or_recognition": 1.25,
    "information_reveal": 1.15,
    "physical_action": 1.15,
    "authority_claim": 1.10,
}


def _event_id(event: dict[str, Any]) -> str:
    return str(event.get("event_id", "")).strip()


def required_dimensions(event: dict[str, Any]) -> list[str]:
    """Return explicit director override or conservative type-derived needs."""
    explicit = event.get("required_coverage_dimensions")
    if explicit is not None:
        if not isinstance(explicit, list) or not all(isinstance(x, str) and x for x in explicit):
            raise ValueError(f"{_event_id(event)}: required_coverage_dimensions must be a string list")
        return list(dict.fromkeys(explicit))
    result: list[str] = []
    for event_type in event.get("event_types", []):
        result.extend(EVENT_DIMENSIONS.get(event_type, []))
    return list(dict.fromkeys(result))


def validate_events(payload: dict[str, Any]) -> list[dict[str, Any]]:
    if not isinstance(payload, dict) or not isinstance(payload.get("events"), list):
        raise ValueError("input must contain an events array")
    events = payload["events"]
    seen: set[str] = set()
    ids = {_event_id(e) for e in events if isinstance(e, dict)}
    for event in events:
        if not isinstance(event, dict):
            raise ValueError("every event must be an object")
        eid = _event_id(event)
        if not eid:
            raise ValueError("event_id is required")
        if eid in seen:
            raise ValueError(f"duplicate event_id: {eid}")
        seen.add(eid)
        source = event.get("source") or {}
        start, end = source.get("line_start"), source.get("line_end")
        if not isinstance(start, int) or not isinstance(end, int) or start < 1 or end < start:
            raise ValueError(f"{eid}: invalid 1-based source line range")
        if not isinstance(source.get("exact_text"), str) or not source["exact_text"].strip():
            raise ValueError(f"{eid}: exact source text is required")
        line_count = (payload.get("scene") or {}).get("source_line_count")
        if isinstance(line_count, int) and line_count > 0 and end > line_count:
            raise ValueError(f"{eid}: source line range exceeds scene.source_line_count")
        if event.get("human_review_required") is False:
            raise ValueError(f"{eid}: 2.2-A events must remain human-reviewable")
        priority = event.get("coverage_priority", "review")
        if priority not in PRIORITY_WEIGHT:
            raise ValueError(f"{eid}: unsupported coverage_priority {priority}")
        for linked in event.get("linked_event_ids", []):
            if linked not in ids:
                raise ValueError(f"{eid}: dangling linked_event_id {linked}")
        required_dimensions(event)
    return events


def segment_master_range(start: float, end: float, max_segment_duration: float) -> list[list[float]]:
    """Split an explicitly timed master into contiguous technical segments.

    This is a technical clip-budget operation only; it does not create or alter
    dramatic event timing. Exact endpoints are preserved and segments neither
    overlap nor leave gaps.
    """
    values = (start, end, max_segment_duration)
    if not all(isinstance(v, (int, float)) and math.isfinite(v) for v in values):
        raise ValueError("master range values must be finite numbers")
    if start < 0 or end <= start or max_segment_duration <= 0:
        raise ValueError("require 0 <= start < end and max_segment_duration > 0")
    result = []
    cursor = float(start)
    while cursor < end - EPSILON:
        nxt = min(cursor + float(max_segment_duration), float(end))
        result.append([cursor, nxt])
        cursor = nxt
    return result


def build_candidate_shots(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Build restrained, source-ordered proposals from 2.2-A event atoms.

    A shared physical cluster can be covered by one cluster-level action shot;
    character-specific reaction/performance dimensions remain attached to their
    own event IDs. No timecodes, camera moves, lenses, or blocking are invented.
    """
    clusters: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for event in events:
        cluster = str(event.get("event_cluster_id") or _event_id(event))
        clusters[cluster].append(event)

    proposals: list[dict[str, Any]] = []
    for cluster_id, members in sorted(
        clusters.items(),
        key=lambda kv: min((e["source"]["line_start"], _event_id(e)) for e in kv[1]),
    ):
        shared_map: dict[str, list[str]] = {}
        individual_map: dict[str, list[str]] = {}
        for event in members:
            eid = _event_id(event)
            dims = required_dimensions(event)
            shared = [d for d in dims if d in {
                "action", "consequence", "group_overview", "group_result",
                "reveal_target", "information_delivery", "authority_delivery", "pressure_source",
                "challenge_delivery", "speaker_delivery", "performance_action"
            }]
            individual = [d for d in dims if d not in shared]
            if shared:
                shared_map[eid] = shared
            if individual:
                individual_map[eid] = individual
        if shared_map:
            line_start = min(e["source"]["line_start"] for e in members)
            line_end = max(e["source"]["line_end"] for e in members)
            cluster_types = {t for e in members for t in e.get("event_types", [])}
            if "group_shift" in cluster_types:
                shot_type = "group_master"
            elif "prop_state_change" in cluster_types:
                shot_type = "prop_action"
            elif "reveal_or_recognition" in cluster_types or "information_reveal" in cluster_types:
                shot_type = "reveal_coverage"
            elif "threat_or_coercion" in cluster_types or "authority_claim" in cluster_types:
                shot_type = "power_exchange"
            else:
                shot_type = "continuous_take"
            proposals.append({
                "shot_id": f"CLUSTER-{cluster_id}",
                "shot_type": shot_type,
                "coverage_mode": "continuous_take_candidate",
                "cluster_id": cluster_id,
                "source_line_range": [line_start, line_end],
                "coverage": shared_map,
                "rationale": "One shared occurrence may serve linked event records; distinct performer reactions remain separate.",
            })
        for event in members:
            eid = _event_id(event)
            dims = individual_map.get(eid, [])
            line_range = [event["source"]["line_start"], event["source"]["line_end"]]
            if "object_state" in dims:
                proposals.append({
                    "shot_id": f"INSERT-{eid}",
                    "shot_type": "prop_insert",
                    "cluster_id": cluster_id,
                    "source_line_range": line_range,
                    "coverage": {eid: ["object_state"]},
                    "rationale": "Dedicated object-state evidence is separated from the broader action take.",
                })
            response_dims = [d for d in dims if d != "object_state"]
            if response_dims:
                proposals.append({
                    "shot_id": f"REACTION-{eid}",
                    "shot_type": "group_reaction" if "staggered_response" in response_dims else "reaction_or_response",
                    "cluster_id": cluster_id,
                    "source_line_range": line_range,
                    "coverage": {eid: response_dims},
                    "rationale": "Character-specific or staggered response is not collapsed into the shared physical occurrence.",
                })
            # Events with no derived dimensions remain reviewable but are not
            # assigned a fictitious coverage claim.
    return proposals


def _event_weight(event: dict[str, Any]) -> float:
    base = PRIORITY_WEIGHT.get(event.get("coverage_priority", "review"), 1.0)
    multiplier = max([DRAMATIC_WEIGHT.get(t, 1.0) for t in event.get("event_types", [])] or [1.0])
    return base * multiplier


def optimize_coverage(
    payload: dict[str, Any],
    candidate_shots: list[dict[str, Any]] | None = None,
    max_shots: int = 16,
) -> dict[str, Any]:
    """Select high-value non-redundant shots and calculate event coverage.

    Status semantics:
      covered: every required dimension has at least one selected explicit claim;
      partially_covered: at least one, but not all, required dimensions claimed;
      not_selected: no required dimension claimed by selected shots.

    Mere inclusion of an event ID, a master shot, or an unselected candidate
    never counts as coverage.
    """
    if not isinstance(max_shots, int) or max_shots < 0:
        raise ValueError("max_shots must be a non-negative integer")
    events = validate_events(payload)
    by_id = {_event_id(e): e for e in events}
    candidates = deepcopy(candidate_shots if candidate_shots is not None else build_candidate_shots(events))
    candidate_ids: set[str] = set()
    for shot in candidates:
        sid = str(shot.get("shot_id", "")).strip()
        if not sid or sid in candidate_ids:
            raise ValueError(f"candidate shot_id missing or duplicated: {sid}")
        candidate_ids.add(sid)
        coverage = shot.get("coverage")
        if not isinstance(coverage, dict):
            raise ValueError(f"{sid}: coverage must map event IDs to dimensions")
        line_range = shot.get("source_line_range")
        if line_range is not None:
            if (not isinstance(line_range, list) or len(line_range) != 2
                    or not all(isinstance(x, int) for x in line_range)
                    or line_range[0] < 1 or line_range[1] < line_range[0]):
                raise ValueError(f"{sid}: invalid 1-based source_line_range")
        for eid, dims in coverage.items():
            if eid not in by_id:
                raise ValueError(f"{sid}: unknown event_id {eid}")
            if line_range is not None:
                ev_start = by_id[eid]["source"]["line_start"]
                ev_end = by_id[eid]["source"]["line_end"]
                if line_range[1] < ev_start or line_range[0] > ev_end:
                    raise ValueError(f"{sid}/{eid}: candidate source range does not intersect event source lines")
            if not isinstance(dims, list) or not all(isinstance(d, str) for d in dims):
                raise ValueError(f"{sid}/{eid}: dimensions must be a string list")
            allowed = set(required_dimensions(by_id[eid]))
            unknown = set(dims) - allowed
            if unknown:
                raise ValueError(f"{sid}/{eid}: dimensions not required by event: {sorted(unknown)}")

    weights = {eid: _event_weight(ev) for eid, ev in by_id.items()}
    requirements = {eid: set(required_dimensions(ev)) for eid, ev in by_id.items()}
    selected: list[dict[str, Any]] = []
    covered_dims: dict[str, set[str]] = {eid: set() for eid in by_id}
    remaining = list(candidates)

    while remaining and len(selected) < max_shots:
        scored = []
        for shot in remaining:
            marginal = 0.0
            new_pairs = 0
            for eid, dims in shot["coverage"].items():
                new = set(dims) & (requirements[eid] - covered_dims[eid])
                if new:
                    marginal += weights[eid] * len(new)
                    new_pairs += len(new)
            # Deterministic tie-breaking: score, earliest source line, shot ID.
            line = (shot.get("source_line_range") or [10**9])[0]
            scored.append((marginal, new_pairs, -int(line), str(shot["shot_id"]), shot))
        best = max(scored, key=lambda x: (x[0], x[1], x[2], tuple(-ord(c) for c in x[3])))
        if best[0] <= EPSILON:
            break
        shot = best[4]
        selected.append(shot)
        for eid, dims in shot["coverage"].items():
            covered_dims[eid].update(dims)
        remaining.remove(shot)

    decisions = []
    total_weight = 0.0
    covered_weight = 0.0
    for event in events:
        eid = _event_id(event)
        required = sorted(requirements[eid])
        covered = sorted(covered_dims[eid])
        missing = sorted(requirements[eid] - covered_dims[eid])
        if not required or not covered:
            status = "not_selected"
        elif not missing:
            status = "covered"
        else:
            status = "partially_covered"
        weight = weights[eid]
        total_weight += weight * len(required)
        covered_weight += weight * len(covered)
        selected_shots = [s["shot_id"] for s in selected if eid in s["coverage"] and s["coverage"][eid]]
        decisions.append({
            "event_id": eid,
            "actor": event.get("actor"),
            "event_cluster_id": event.get("event_cluster_id") or eid,
            "source_line_range": [event["source"]["line_start"], event["source"]["line_end"]],
            "priority": event.get("coverage_priority", "review"),
            "required_dimensions": required,
            "covered_dimensions": covered,
            "missing_dimensions": missing,
            "status": status,
            "selected_shot_ids": selected_shots,
            "human_review_required": True,
            "unmapped_event_types": [t for t in event.get("event_types", []) if t not in EVENT_DIMENSIONS],
        })
    return {
        "schema_version": "2.2-B-recovered",
        "engine_version": VERSION,
        "scene": payload.get("scene", {}),
        "optimization": {
            "max_shots": max_shots,
            "selected_shot_count": len(selected),
            "candidate_shot_count": len(candidates),
            "selection_method": "deterministic_weighted_greedy_set_cover",
            "coverage_ratio": round(covered_weight / total_weight, 6) if total_weight else 0.0,
            "timing_generated": False,
            "camera_design_generated": False,
            "human_review_required": True,
        },
        "selected_shots": selected,
        "master_coverage_policy": {
            "recommended": True,
            "purpose": "establish scene geography and editorial fallback",
            "event_coverage_credit": "none unless event dimensions are explicitly mapped",
            "technical_segmentation": "segment_master_range(start, end, max_segment_duration) requires an explicit authored/measured range",
        },
        "event_decisions": decisions,
        "summary": {
            "covered": sum(d["status"] == "covered" for d in decisions),
            "partially_covered": sum(d["status"] == "partially_covered" for d in decisions),
            "not_selected": sum(d["status"] == "not_selected" for d in decisions),
        },
        "limits": [
            "Coverage statuses describe explicit planned evidence, not footage already captured.",
            "No timecodes, shot sizes, lens values, blocking, or camera moves are inferred.",
            "A master/context shot does not cover event dimensions unless explicitly mapped.",
            "All event decisions require director review before production.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("events_json")
    parser.add_argument("-o", "--output", required=True)
    parser.add_argument("--max-shots", type=int, default=16)
    args = parser.parse_args()
    payload = json.loads(Path(args.events_json).read_text(encoding="utf-8-sig"))
    result = optimize_coverage(payload, max_shots=args.max_shots)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result["summary"], ensure_ascii=False))


if __name__ == "__main__":
    main()
