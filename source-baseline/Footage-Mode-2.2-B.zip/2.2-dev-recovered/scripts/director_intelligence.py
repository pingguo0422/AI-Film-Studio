#!/usr/bin/env python3
"""Director-intelligence preflight for Footage-Mode 2.0.

This module does not pretend to infer a director's intent with certainty. It
structures supplied dramatic facts and emits transparent, reviewable suggestions.
"""
from __future__ import annotations
import re

CUE_RULES = [
    (("试探", "testing", "probe", "底线"), "power_test", "Consider holding the listener's reaction before revealing the speaker."),
    (("隐瞒", "撒谎", "conceal", "lie", "不说"), "concealment", "Consider framing that preserves ambiguity; do not reveal the concealed fact prematurely."),
    (("发现", "意识到", "realizes", "notices", "察觉"), "realization", "Consider a visible cue followed by a reaction hold; identify the cue before choosing a close-up."),
    (("威胁", "威逼", "threat", "压迫"), "threat", "Consider spatial dominance, negative space, or a controlled low/high-angle contrast."),
    (("犹豫", "停顿", "hesitat", "沉默", "不回答"), "hesitation", "Protect the pause; avoid cutting away before the decision becomes visible."),
    (("反击", "逆转", "反转", "turns the table"), "power_shift", "Consider changing shot scale or spatial balance at the power shift."),
    (("秘密", "真相", "揭晓", "secret", "reveal"), "reveal", "Control what the audience can see and when; consider a staged reveal."),
    (("观察", "盯着", "看着", "watch", "measures"), "observation", "A reaction or point-of-view option may be useful if the observed target is explicit."),
]

def _text(value):
    if value is None: return ""
    if isinstance(value, (list, tuple)): return " ".join(_text(x) for x in value)
    if isinstance(value, dict): return " ".join(_text(v) for v in value.values())
    return str(value)

def analyze_scene(doc):
    scene = doc.get("scene") or {}
    coverage = doc.get("coverage") or []
    annotations = scene.get("dramatic_beats") or []
    findings = []
    for i, shot in enumerate(coverage, 1):
        text = " ".join([
            _text(shot.get("beat")), _text(shot.get("performance")),
            _text(shot.get("dialogue")), _text(shot.get("planner")),
            _text(shot.get("hint")),
        ]).lower()
        matched = []
        for terms, code, suggestion in CUE_RULES:
            if any(term.lower() in text for term in terms):
                matched.append({"code": code, "suggestion": suggestion})
        findings.append({
            "shot": shot.get("shot", i),
            "dramatic_purpose": (shot.get("director") or {}).get("dramatic_purpose"),
            "audience_knowledge": (shot.get("director") or {}).get("audience_knowledge"),
            "subtext": (shot.get("director") or {}).get("subtext"),
            "visible_cues": (shot.get("director") or {}).get("visible_cues", []),
            "suggestions": matched,
            "review_required": not bool((shot.get("director") or {}).get("dramatic_purpose"))
        })
    return {
        "module": "Director Intelligence 2.0",
        "scene_question": scene.get("dramatic_question"),
        "audience_premise": scene.get("audience_premise"),
        "dramatic_beats": annotations,
        "shot_reviews": findings,
        "limitations": [
            "Keyword cues are prompts for human review, not proof of subtext or intent.",
            "Internal states must be grounded in observable performance cues before rendering.",
            "The module does not automatically choose final cuts or claim a shot is artistically correct."
        ]
    }
