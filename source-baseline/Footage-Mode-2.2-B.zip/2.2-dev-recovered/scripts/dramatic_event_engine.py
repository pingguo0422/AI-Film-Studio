#!/usr/bin/env python3
"""Footage-Mode 2.2-A: screenplay/acting-task atoms -> traceable dramatic events.

This is a conservative, deterministic first-pass extractor. It never invents
missing dialogue, plot facts, motivations, or state transitions. Every event is
anchored to an exact source line and marked for human review.
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from typing import Any

VERSION = "2.2.0-alpha.1"
BLOCK_RE = re.compile(r"^ACTING TASK\s*[—–-]\s*(.+?)(?:\s*\((.*?)\))?\s*:\s*$")
DIALOGUE_RE = re.compile(r"[“\"]([^”\"]+)[”\"]")
SCENE_RE = re.compile(r"^(?:Scene\s*\d*\s*[—:-]\s*)?(.{1,80}(?:内景|外景|日|夜).*)$", re.I)

# Deliberately transparent cue rules. They identify candidate event classes,
# not authorial intent or historical truth.
CUES = [
    ("prop_state_change", ("踢翻", "打翻", "摔碎", "滚落", "掉落", "扯下", "撕开", "打开", "关上", "交给", "拿走")),
    ("physical_action", ("拖着", "拖拽", "按倒", "推开", "拉住", "冲上", "爬出", "钻进", "跪下", "站起", "转身", "走向", "迎上")),
    ("group_shift", ("陆续", "纷纷", "此起彼伏", "开始附和", "交头接耳", "面面相觑", "有人跪下", "群体", "猪仔们")),
    ("reveal_or_recognition", ("认出", "发现", "察觉", "看见", "看到", "意识到", "注意到")),
    ("authority_claim", ("官职", "朝廷命官", "正六品", "御前", "命令", "下跪", "大清国")),
    ("threat_or_coercion", ("威胁", "喝令", "逼", "恐吓", "按倒", "家人", "抓捕", "钦犯")),
    ("question_or_challenge", ("追问", "质问", "反问", "询问", "问道", "挑战")),
    ("reaction", ("迟疑", "犹豫", "摇头", "沉默", "闭嘴", "退缩", "受惊", "抬头", "看向")),
    ("information_reveal", ("藏在", "枪声", "不会上船", "立功", "升官发财", "孙逸仙")),
]

VISUAL_CUES = {
    "prop_state_change": "物件状态变化或动作接触的可见证据",
    "physical_action": "人物身体动作、位置变化及动作结果",
    "group_shift": "群体反应的先后次序与个体差异",
    "reveal_or_recognition": "角色看到/识别对象时的视线与反应",
    "authority_claim": "权力宣示及他人对宣示的可见反应",
    "threat_or_coercion": "威胁者、受压者及身体控制关系",
    "question_or_challenge": "发问者、被问者与倾听反应",
    "reaction": "反应发生的主体及其可见行为",
    "information_reveal": "信息发出者与接收者的反应",
    "dialogue_turn": "说话者与被影响者的反应",
    "performance_action": "人物动作及其直接对象",
}


def _classify(text: str, dialogue: str) -> list[str]:
    found = []
    for kind, words in CUES:
        if any(w in text for w in words):
            found.append(kind)
    if dialogue and not any(k in found for k in ("authority_claim", "threat_or_coercion", "question_or_challenge", "information_reveal")):
        found.append("dialogue_turn")
    if not found:
        found.append("performance_action")
    # stable de-duplication
    return list(dict.fromkeys(found))


def _extract_dialogue(text: str) -> str:
    parts = DIALOGUE_RE.findall(text)
    return " / ".join(parts)


def _participants(text: str, roster: list[str], actor: str) -> list[str]:
    found = [name for name in roster if name != actor and name in text]
    return [actor] + found


def _cluster_key(text: str) -> str | None:
    """Link multiple character-track descriptions of the same explicit action."""
    rules = [
        ("PROP_BUCKET_OVERTURN", ("木桶",), ("踢翻", "打翻", "翻倒")),
        ("PROP_BEANS_SCATTER", ("白扁豆", "扁豆"), ("滚落", "散落", "撒落")),
        ("PROP_MASK_REMOVAL", ("口罩", "面罩"), ("扯下", "摘下", "揭下")),
        ("GROUP_KNEELING_WAVE_2", ("陆续跪下", "尚未跪下"), ("跪", "下跪")),
        ("GROUP_KNEELING_ESCALATION_CUE", ("见猪仔有人跪下", "呵斥", "还不下跪"), ("跪", "下跪")),
        ("GROUP_KNEELING_WAVE_1", ("部分人", "有人跪下", "开始下跪", "因官职而跪下"), ("跪", "下跪")),
        ("GROUP_KNEELING_AMBIVALENCE", ("抬头看她", "不确定该听谁"), ("跪", "下跪")),
        ("INDIVIDUAL_KNEELING_COMMAND", ("喝令", "命令", "朝武寒青"), ("跪下", "下跪")),
        ("KNEELING_RESISTANCE", ("不要跪", "挺住"), ("跪", "下跪")),
        ("PHYSICAL_RESTRAINT_DRAG", ("武寒青",), ("拖着", "拖拽")),
        ("PHYSICAL_RESTRAINT_PIN", ("武寒青",), ("按倒", "压制")),
    ]
    for key, nouns, verbs in rules:
        if any(n in text for n in nouns) and any(v in text for v in verbs):
            return key
    return None


def _dramatic_function(kinds: list[str]) -> str:
    mapping = {
        "prop_state_change": "改变现场物件或行动条件",
        "physical_action": "改变人物位置、行动能力或身体关系",
        "group_shift": "改变群体态度、秩序或行动方向",
        "reveal_or_recognition": "改变角色对现场身份/状况的认知",
        "authority_claim": "建立或挑战权力合法性",
        "threat_or_coercion": "以威胁或身体控制改变服从关系",
        "question_or_challenge": "索取信息或公开挑战对方立场",
        "reaction": "呈现事件对人物造成的即时影响",
        "information_reveal": "向角色或观众释放新信息",
        "dialogue_turn": "推进人物交流与立场表达",
        "performance_action": "提供人物行动与状态信息",
    }
    return "；".join(mapping[k] for k in kinds)


def parse_acting_task(text: str, scene_id: str = "SCENE-01", scene_title: str = "") -> dict[str, Any]:
    """Parse ACTING TASK blocks. Source line numbers are 1-based and exact."""
    lines = text.splitlines()
    blocks: list[dict[str, Any]] = []
    current = None
    mode = ""
    for line_no, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line:
            continue
        m = BLOCK_RE.match(line)
        if m:
            if current:
                blocks.append(current)
            current = {"character": m.group(1).strip(), "role_note": (m.group(2) or "").strip(), "items": []}
            mode = "header"
            continue
        if current is None:
            if line.lower().startswith("scene") and not scene_title:
                scene_title = line
            continue
        if line.startswith("Moment to moment") or line.startswith("逐拍"):
            mode = "beats"
            continue
        if line.startswith("—") or line.startswith("- ") or line.startswith("•"):
            item = line.lstrip("—-• ").strip()
            if item:
                current["items"].append({"source_line": line_no, "source_text": item, "mode": mode or "beats"})
            continue
        # Keep structured actor metadata as block-level context, not as events.
        if ":" in line and mode != "beats":
            key, value = line.split(":", 1)
            current.setdefault("context", {})[key.strip()] = value.strip()
    if current:
        blocks.append(current)

    roster = [b["character"] for b in blocks]
    events = []
    actor_tracks = []
    for block in blocks:
        actor = block["character"]
        track_ids = []
        for index, item in enumerate(block["items"], 1):
            raw = item["source_text"]
            dialogue = _extract_dialogue(raw)
            kinds = _classify(raw, dialogue)
            eid = f"{scene_id}-{len(events)+1:03d}"
            participants = _participants(raw, roster, actor)
            event = {
                "event_id": eid,
                "scene_id": scene_id,
                "source": {"line_start": item["source_line"], "line_end": item["source_line"], "exact_text": raw},
                "actor": actor,
                "participants": participants,
                "event_types": kinds,
                "dramatic_function": _dramatic_function(kinds),
                "observable_action": raw,
                "dialogue_verbatim": dialogue,
                "dramatic_state": {
                    "before": None,
                    "after": None,
                    "change_claim": "",
                    "evidence_status": "not_explicit_in_source",
                },
                "information_delta": {
                    "new_information": "",
                    "known_by_characters": [],
                    "known_by_audience": None,
                    "evidence_status": "not_explicit_in_source",
                },
                "power_relation": {"before": None, "after": None, "shift": None, "evidence_status": "not_explicit_in_source"},
                "visual_evidence": [VISUAL_CUES[k] for k in kinds],
                "coverage_priority": "review",
                "coverage_candidates": [],
                "confidence": "medium" if len(kinds) > 1 else "low",
                "human_review_required": True,
                "inference_policy": "source_anchored; no dialogue, plot, motive, or state transition invented",
            }
            # Candidate coverage is a question for the director, not a shot order.
            if "prop_state_change" in kinds:
                event["coverage_priority"] = "high"
                event["coverage_candidates"] = ["动作全貌", "关键接触/物件状态", "动作结果与受影响者反应"]
            elif "group_shift" in kinds:
                event["coverage_priority"] = "high"
                event["coverage_candidates"] = ["群体全貌", "先行动者/迟疑者差异", "群体变化结果"]
            elif "threat_or_coercion" in kinds or "authority_claim" in kinds:
                event["coverage_priority"] = "high"
                event["coverage_candidates"] = ["权力发出者", "受压者反应", "权力关系变化的可见证据"]
            elif "reveal_or_recognition" in kinds:
                event["coverage_priority"] = "medium"
                event["coverage_candidates"] = ["信息/对象被看见", "识别者反应"]
            events.append(event)
            track_ids.append(eid)
        actor_tracks.append({"character": actor, "role_note": block.get("role_note", ""), "context": block.get("context", {}), "event_ids": track_ids})

    # A cluster is a shared physical/dramatic occurrence described from more
    # than one character's performance track. It prevents duplicate coverage
    # without erasing each character's distinct reaction record.
    clusters: dict[str, list[str]] = {}
    for ev in events:
        key = _cluster_key(ev["observable_action"])
        ev["event_cluster_id"] = key or ev["event_id"]
        ev["event_link_basis"] = "shared explicit action/object cue" if key else "single source atom; no safe cross-track match"
        clusters.setdefault(ev["event_cluster_id"], []).append(ev["event_id"])
    for ev in events:
        ev["linked_event_ids"] = [x for x in clusters[ev["event_cluster_id"]] if x != ev["event_id"]]

    return {
        "schema_version": "2.2-A",
        "engine_version": VERSION,
        "scene": {"scene_id": scene_id, "title": scene_title, "source_type": "acting_task", "source_line_count": len(lines)},
        "characters": actor_tracks,
        "events": events,
        "extraction_policy": {
            "mode": "conservative_rule_based_first_pass",
            "source_traceability": "every event maps to an exact source line",
            "unprovided_fields": "null_or_empty; never guessed",
            "timing": "not generated by this engine",
            "shot_design": "not generated by this engine",
        },
    }



def parse_screenplay(text: str, roster: list[str], scene_id: str = "SCENE-01", scene_title: str = "") -> dict[str, Any]:
    """Conservative line-oriented screenplay parser; ambiguous agency stays UNASSIGNED."""
    lines = text.splitlines()
    parsed_atoms = []
    current_speaker = None
    for line_no, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line:
            continue
        if not scene_title and ("内景" in line or "外景" in line or "日" in line or "夜" in line) and len(line) < 120:
            scene_title = line
            continue
        # Inline screenplay dialogue: 武寒青：台词
        inline = None
        for name in sorted(roster, key=len, reverse=True):
            m = re.match(rf"^{re.escape(name)}\s*[：:]\s*(.*)$", line)
            if m:
                inline = (name, m.group(1).strip())
                break
        if inline:
            parsed_atoms.append((line_no, inline[0], inline[1], True))
            current_speaker = None
            continue
        # Character cue on its own line; the next non-empty line is dialogue.
        cue = next((name for name in sorted(roster, key=len, reverse=True)
                    if re.fullmatch(rf"{re.escape(name)}(?:\s*[（(].*?[）)])?", line)), None)
        if cue:
            current_speaker = cue
            continue
        if current_speaker:
            parsed_atoms.append((line_no, current_speaker, line, True))
            current_speaker = None
            continue
        # Parenthetical action or stage direction. Assign only when agency is clear.
        mentions = [name for name in roster if name in line]
        if any(term in line for term in ("猪仔们", "众人", "人群", "大家")):
            actor = next((name for name in roster if "猪仔" in name), "猪仔群体")
        elif line.startswith(tuple(roster)):
            actor = next((name for name in sorted(roster, key=len, reverse=True) if line.startswith(name)), "UNASSIGNED")
        else:
            # A character being mentioned is not proof they perform the action.
            actor = "UNASSIGNED"
        parsed_atoms.append((line_no, actor, line, False))

    # Reuse the same event contract and conservative classifiers. Synthetic
    # block boundaries preserve chronological atom order; source pointers are
    # immediately restored to original screenplay line numbers.
    synthetic = []
    source_map = []
    for _, actor, content, is_dialogue in parsed_atoms:
        synthetic.extend([f"ACTING TASK — {actor} (screenplay atom):", "Moment to moment:", f"— {content}"])
        source_map.append((_, content, is_dialogue))
    doc = parse_acting_task("\n".join(synthetic), scene_id, scene_title)
    for ev, (line_no, content, is_dialogue) in zip(doc["events"], source_map):
        ev["source"] = {"line_start": line_no, "line_end": line_no, "exact_text": content}
        if is_dialogue:
            ev["dialogue_verbatim"] = content
            if "dialogue_turn" not in ev["event_types"]:
                ev["event_types"].append("dialogue_turn")
        ev["confidence"] = "low" if ev["actor"] == "UNASSIGNED" else ev["confidence"]
        ev["inference_policy"] = "screenplay_line_anchored; ambiguous agency remains UNASSIGNED; no plot or state transitions invented"
    # Collapse synthetic one-event tracks into a unique character roster.
    tracks = {}
    for ev in doc["events"]:
        tracks.setdefault(ev["actor"], []).append(ev["event_id"])
    doc["characters"] = [{"character": name, "role_note": "", "context": {}, "event_ids": ids} for name, ids in tracks.items()]
    doc["scene"]["source_type"] = "screenplay"
    doc["scene"]["source_line_count"] = len(lines)
    return doc

def validate_event_doc(doc: dict[str, Any]) -> list[dict[str, str]]:
    issues = []
    ids = set()
    for ev in doc.get("events", []):
        eid = ev.get("event_id", "")
        if not eid or eid in ids:
            issues.append({"severity": "BLOCKER", "event_id": eid, "message": "missing or duplicate event_id"})
        ids.add(eid)
        src = ev.get("source", {})
        if not src.get("line_start") or not src.get("exact_text"):
            issues.append({"severity": "BLOCKER", "event_id": eid, "message": "event lacks exact source-line traceability"})
        if ev.get("human_review_required") is not True:
            issues.append({"severity": "MAJOR", "event_id": eid, "message": "first-pass event must require human review"})
        if not ev.get("observable_action"):
            issues.append({"severity": "MAJOR", "event_id": eid, "message": "missing observable action"})
    return issues


def build_report(doc: dict[str, Any], issues: list[dict[str, str]]) -> str:
    events = doc.get("events", [])
    counts: dict[str, int] = {}
    for ev in events:
        for kind in ev.get("event_types", []):
            counts[kind] = counts.get(kind, 0) + 1
    high = sum(e.get("coverage_priority") == "high" for e in events)
    cluster_sizes: dict[str, int] = {}
    for ev in events:
        key = ev.get("event_cluster_id", ev.get("event_id"))
        cluster_sizes[key] = cluster_sizes.get(key, 0) + 1
    shared_clusters = sum(size > 1 for size in cluster_sizes.values())
    lines = [
        f"# Footage-Mode 2.2-A Event Extraction Report — {doc.get('scene', {}).get('title') or doc.get('scene', {}).get('scene_id')}",
        "", f"- Engine: `{doc.get('engine_version')}`", f"- Source type: `{doc.get('scene', {}).get('source_type')}`",
        f"- Event atoms extracted: **{len(events)}**", f"- Character tracks: **{len(doc.get('characters', []))}**",
        f"- High-priority candidate events: **{high}**", f"- Shared event clusters: **{shared_clusters}**", f"- Validation issues: **{len(issues)}**", "",
        "## Event-type counts", "",
    ]
    for k, v in sorted(counts.items()):
        lines.append(f"- `{k}`: {v}")
    lines += ["", "## High-priority events", ""]
    for ev in events:
        if ev.get("coverage_priority") == "high":
            lines.append(f"- **{ev['event_id']} · {ev['actor']}** — {ev['observable_action']} [{', '.join(ev['event_types'])}]")
    lines += ["", "## Validation", ""]
    if issues:
        for issue in issues:
            lines.append(f"- [{issue['severity']}] {issue['event_id']}: {issue['message']}")
    else:
        lines.append("- PASS: all extracted events retain source-line traceability and review flags.")
    lines += ["", "## Interpretation boundary", "", "This report measures extraction structure only. It does not certify dramatic importance, directorial quality, historical accuracy, or shot sufficiency. All event records remain review-required; timings and camera choices are intentionally absent."]
    return "\n".join(lines) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser(description="Extract traceable dramatic event atoms from an ACTING TASK document")
    ap.add_argument("input", help="ACTING TASK text file")
    ap.add_argument("-o", "--output", default="dramatic-events.json")
    ap.add_argument("--report", default=None, help="optional Markdown report path")
    ap.add_argument("--scene-id", default="SCENE-01")
    ap.add_argument("--scene-title", default="")
    ap.add_argument("--input-format", choices=["acting_task", "screenplay"], default="acting_task")
    ap.add_argument("--roster", default="", help="comma-separated exact character names for screenplay mode")
    args = ap.parse_args(argv)
    text = Path(args.input).read_text(encoding="utf-8")
    if args.input_format == "screenplay":
        doc = parse_screenplay(text, [x.strip() for x in args.roster.split(",") if x.strip()], args.scene_id, args.scene_title)
    else:
        doc = parse_acting_task(text, args.scene_id, args.scene_title)
    issues = validate_event_doc(doc)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        Path(args.report).write_text(build_report(doc, issues), encoding="utf-8")
    print(f"events={len(doc['events'])} characters={len(doc['characters'])} issues={len(issues)}")
    print(f"wrote {args.output}")
    if args.report:
        print(f"wrote {args.report}")
    return 1 if any(i["severity"] == "BLOCKER" for i in issues) else 0

if __name__ == "__main__":
    raise SystemExit(main())
