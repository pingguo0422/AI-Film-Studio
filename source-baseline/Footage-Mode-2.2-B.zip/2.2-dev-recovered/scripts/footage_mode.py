#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
footage-mode — shot planner, prompt renderer and QC validator.

Deterministic layer for SKILL.md: computes padding, time ranges, FOV, filenames and
camera-move gating from a scene JSON, renders the ten prompt blocks, and validates
the result against the QC gate.

Subcommands:
    plan     scene.json -o out/   -> out/shots.json
    render   out/shots.json       -> prompts on stdout
    check    out/shots.json       -> QC report, exit 1 on error
    all      scene.json -o out/   -> plan + check + prompt txt files + qc-report.txt
    selftest                      -> runs the bundled example end to end

No third-party dependencies. Python 3.7+.
"""

import argparse
import json
import os
import re
import sys

SCHEMA_VERSION = "1.1"

FOV_BY_SIZE = {
    "DETAIL": 8,
    "ECU": 12,
    "CU": 18,
    "MCU": 29,
    "MS": 47,
    "WS": 63,
    "EWS": 84,
    "ARCH": 107,
}

SIZE_TEXT = {
    "DETAIL": "detail insert",
    "ECU": "extreme close-up",
    "CU": "close-up",
    "MCU": "medium close-up",
    "MS": "medium shot",
    "WS": "wide shot",
    "EWS": "extreme wide shot",
    "ARCH": "architectural ultra-wide",
}

SAFE_MOVES = ("static", "slow_push_in", "slow_pull_out", "slow_pan", "slow_tilt", "slow_tracking")
UNSAFE_MOVES = ("whip_pan", "fast_zoom", "handheld_shake", "compound")

DOWNGRADE_TO = {
    "whip_pan": "slow_pan",
    "fast_zoom": "slow_push_in",
    "handheld_shake": "static",
    "compound": "slow_push_in",
}

MOVE_TEXT = {
    "static": "locked-off static camera",
    "slow_push_in": "slow constant-speed push in toward the subject",
    "slow_pull_out": "slow constant-speed pull out, widening the frame",
    "slow_pan": "slow horizontal pan, low angular velocity",
    "slow_tilt": "slow vertical tilt, low angular velocity",
    "slow_tracking": "slow tracking follow, the subject stays framed",
    "whip_pan": "fast whip pan",
    "fast_zoom": "rapid zoom",
    "handheld_shake": "handheld camera with body tremor",
    "compound": "compound move, push and pan together",
}

AIRFLOW_TEXT = {
    "soft_breeze": "a soft steady breeze, mild, acting uniformly across the frame; "
                   "fabric and hair undulate gently",
    "short_gust": "one short gust, mild, a brief fabric flutter that settles again",
}

DEFAULT_NEGATIVES = [
    "text", "watermark", "subtitles", "logo",
    "extra fingers", "deformed hands", "duplicated limbs",
    "face morphing", "identity change",
    "rubbery cloth", "intersecting geometry", "clipped fabric",
    "duplicate characters", "stutter", "frozen frame", "blown highlights",
]

BANNED_TERMS = [
    "viewport", "collider", "collision", "simulation", "physics engine",
    "render engine", "auto cut", "split screen", "montage", "subtitle",
    "watermark", "freeze-frame",
]

MIN_PAD = 0.4

# Focal length is banned; film gauge is not. `16mm grain` is a look, `35mm lens` is a
# lens. Match only lens context, so stock/gauge language survives.
MM_PATTERNS = (
    r"\b\d{1,3}\s*mm\s*(?:lens|prime|zoom|focal|anamorphic)\b",
    r"\b(?:lens|focal(?:\s+length)?)\s*(?:is|of|at|:)?\s*\d{1,3}\s*mm\b",
    r"\b\d{1,3}\s*mm\s*(?:equivalent|equiv)\b",
)

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass


# --------------------------------------------------------------------------- utils

def r1(value):
    """Round to one decimal; tolerant of junk input."""
    try:
        return round(float(value) + 0.0, 1)
    except (TypeError, ValueError):
        return 0.0


def num(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def fmt(value):
    return "%.1f" % r1(value)


def word_count(text):
    """Prompt-budget word count: letters only.

    Timecodes, FOV degrees and frame rates are not prose, so they must not inflate
    the budget check; CJK is counted per character.
    """
    if not text:
        return 0
    cjk = len(re.findall(u"[\u3400-\u9fff]", text))
    latin = len(re.findall(r"[A-Za-z]+(?:['\-][A-Za-z]+)*", text))
    return cjk + latin


def prompt_metrics(text):
    """Return Latin word count and CJK character count separately.

    A CJK character is not equivalent to an English whitespace-delimited word.
    Keeping separate budgets avoids penalizing Chinese/Japanese/Korean prompts
    simply because their writing system does not use spaces between words.
    """
    cjk = len(re.findall(u"[\u3400-\u9fff]", text or ""))
    latin = len(re.findall(r"[A-Za-z]+(?:['\-][A-Za-z]+)*", text or ""))
    return latin, cjk


def load_json(path):
    with open(path, "r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_text(path, text):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text if text.endswith("\n") else text + "\n")


def write_json(path, obj):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(obj, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def shot_prefix(shot):
    return ("shot %s: " % shot) if shot is not None else ""


def has_focal_length(text):
    """True when the text specifies a lens in millimetres (film gauge is allowed)."""
    for pattern in MM_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            return True
    return False


# ---------------------------------------------------------------------- rendering

def normalize_negative(scene):
    cfg = scene.get("negative") or {}
    mode = str(cfg.get("mode") or "separate").lower()
    if mode not in ("separate", "fold"):
        mode = "separate"
    items = cfg.get("items") or DEFAULT_NEGATIVES
    return {"mode": mode, "items": [str(x) for x in items]}


def render_prompt(scene, shot):
    """Render the nine blocks. `scene` may be the raw scene dict or a scene block."""
    out = []

    place = "interior" if shot.get("interior") else "exterior"
    ctx = "%s, %s, %s." % (shot.get("location", ""), place, shot.get("time_of_day", ""))
    beat = str(shot.get("beat") or "").strip().rstrip(".")
    if beat:
        beat = beat[:1].upper() + beat[1:]
        ctx = ctx + " " + beat + "."
    out.append("SCENE CONTEXT")
    out.append(ctx)
    out.append("")

    out.append("ACTIVE REFERENCES")
    for asset in shot.get("assets") or []:
        desc = str(asset.get("kind") or "object")
        state = str(asset.get("state") or "").strip()
        if state:
            desc = desc + ", " + state
        out.append("%s - %s: %s. 100%% matches the reference."
                   % (asset.get("tag", ""), desc, asset.get("anchor", "")))
    if not shot.get("assets"):
        out.append("No reference tags on this shot.")
    out.append("")

    out.append("CAMERA")
    move = shot.get("camera_move", "static")
    out.append("%s, %d degrees diagonal FOV, %s, %s. One continuous shot; "
               "the camera does not cut on its own."
               % (SIZE_TEXT.get(shot.get("shot_size"), "medium shot"),
                  int(num(shot.get("fov_deg"), 47)),
                  shot.get("camera_height") or "eye level",
                  MOVE_TEXT.get(move, move)))
    out.append("")

    out.append("ACTION & TIMING")
    pad_pre = num(shot.get("pad_pre"))
    out.append("0.0s-%ss - ready pose, breathing only." % fmt(pad_pre))
    tracks = shot.get("performance_tracks") or []
    if tracks:
        # Render each authored event once on its own character track. The derived
        # atomic KE tiling remains in shot_record for machine validation only.
        for track in tracks:
            out.append("%s (%s)" % (track.get("character_name", track.get("character_id", "Character")),
                                    track.get("role", "supporting")))
            for event in track.get("events") or []:
                t0 = pad_pre + num(event.get("t_in"))
                t1 = pad_pre + num(event.get("t_out"))
                action = str(event.get("action") or "continues").strip().rstrip("。")
                out.append("%ss-%ss - %s" % (fmt(t0), fmt(t1), action))
    else:
        for ke in sorted(shot.get("ke") or [], key=lambda k: num(k.get("t_in"))):
            t0 = pad_pre + num(ke.get("t_in"))
            t1 = pad_pre + num(ke.get("t_out"))
            action = str(ke.get("action", "")).strip().rstrip(".")
            out.append("%ss-%ss - %s" % (fmt(t0), fmt(t1), action))
    end = pad_pre + num(shot.get("duration"))
    total = num(shot.get("render_duration"))
    out.append("%ss-%ss - final pose, breathing only." % (fmt(end), fmt(total)))
    out.append("")

    acting = str(shot.get("acting") or "").strip()
    if acting or tracks:
        out.append("PERFORMANCE")
        for track in tracks:
            details = []
            if track.get("tactic"):
                details.append("Tactic: " + str(track["tactic"]))
            if track.get("safety"):
                details.append("Safety: " + str(track["safety"]))
            if details:
                out.append("%s: %s" % (track.get("character_name", track.get("character_id", "Character")),
                                         "; ".join(details)))
        if not tracks and acting:
            out.append(acting)
        out.append("")

    rigid = shot.get("rigid") or []
    soft = shot.get("soft") or []
    airflow = str(shot.get("airflow") or "none")
    if rigid or soft or airflow != "none":
        out.append("PHYSICS")
        if rigid:
            out.append("Rigid - %s: solid mass and contact, weight settles into the support, "
                       "nothing bends or passes through another object." % ", ".join(rigid))
        if soft:
            out.append("Soft - %s: follows the body, folds settle naturally, "
                       "the silhouette stays readable." % ", ".join(soft))
        if airflow in AIRFLOW_TEXT:
            out.append("Air - %s." % AIRFLOW_TEXT[airflow])
        out.append("")

    out.append("LIGHT & GRADE")
    light = shot.get("light") or {}
    grade = "%s across every shot of this scene." % (shot.get("lut") or "the scene LUT")
    main = str(light.get("main") or "").strip()
    tone = str(light.get("tone") or "").strip()
    if main:
        grade = grade + " Main light: " + main
        if tone:
            grade = grade + ", " + tone
        grade = grade + "."
    wb = shot.get("white_balance_k")
    if wb:
        grade = grade + " White balance %sK." % wb
    out.append(grade)
    out.append("")

    lines = []
    audio = shot.get("audio") or {}
    ambience = str(audio.get("ambience") or "").strip()
    if ambience:
        if not ambience.endswith("."):
            ambience = ambience + "."
        ambience = ambience[:1].upper() + ambience[1:]
        lines.append(ambience)
    sfx = [str(x) for x in (audio.get("sfx") or [])]
    if sfx:
        sfx_line = ", ".join(sfx)
        lines.append(sfx_line[:1].upper() + sfx_line[1:] + ".")
    for line in shot.get("dialogue") or []:
        at = num(line.get("at")) + pad_pre
        lines.append('%s at %ss: "%s"'
                     % (line.get("speaker", ""), fmt(at), line.get("line", "")))
    if lines:
        out.append("AUDIO")
        out.append(" ".join(lines))
        out.append("")

    style_bits = []
    global_style = scene.get("global_style")
    if global_style:
        style_bits.append(str(global_style).strip())
    override = (shot.get("hint") or {}).get("style_override")
    if override:
        style_bits.append(str(override).strip())
    fmt_cfg = scene.get("format") or {}
    tail = []
    if fmt_cfg.get("aspect"):
        tail.append(str(fmt_cfg.get("aspect")))
    if fmt_cfg.get("fps"):
        tail.append("%s fps" % fmt_cfg.get("fps"))
    if fmt_cfg.get("grain"):
        tail.append("%s grain" % fmt_cfg.get("grain"))
    if style_bits or tail:
        text = ". ".join(bit.rstrip(".") for bit in style_bits)
        if tail:
            text = (text + ". " if text else "") + ", ".join(tail) + "."
        out.append("STYLE")
        out.append(text.strip())
        out.append("")

    locks = []
    tags = [str(a.get("tag")) for a in (shot.get("assets") or []) if a.get("tag")]
    if shot.get("exception_mode"):
        subject = tags[0] if tags else "the subject"
        locks.append("Reinforced lock for this shot: %s keeps the same face, costume and "
                     "silhouette on the last frame as on the first, through the whole move."
                     % subject)
    if tags:
        locks.append("%s stay identical to their references in every frame: faces, "
                     "costume, props and light direction hold from the first frame to the last."
                     % ", ".join(tags))
    else:
        locks.append("Props and room geometry stay identical to their references in "
                     "every frame.")
    negative = normalize_negative(scene)
    if negative.get("mode") == "fold":
        locks.append("Frame stays clean: faces, hands and garment structure fully resolved, "
                     "no artifacts.")
    out.append("POSITIVE LOCKS")
    out.append(" ".join(locks))

    return "\n".join(out).strip()


# -------------------------------------------------------------------------- build

def build(doc):
    """Turn a scene document into an artifact. Returns (artifact, errors, warnings)."""
    scene = doc.get("scene") or {}
    coverage = doc.get("coverage") or []
    assets = doc.get("assets") or []

    errors = []
    warnings = []

    for field in ("seq", "location", "interior", "time_of_day", "lut", "light", "white_balance_k"):
        if field not in scene or scene.get(field) is None or scene.get(field) == "":
            errors.append((None, "scene missing required field %s" % field))
    if not isinstance(assets, list) or not assets:
        errors.append((None, "assets must be a non-empty list"))
    if not coverage:
        errors.append((None, "coverage list is empty"))

    asset_by_id = {}
    for asset in assets:
        aid = str(asset.get("id") or "").strip()
        if not aid:
            errors.append((None, "asset without id"))
            continue
        if not asset.get("tag"):
            errors.append((None, "asset %s has no tag" % aid))
        if not asset.get("anchor"):
            errors.append((None, "asset %s has no anchor" % aid))
        elif word_count(asset.get("anchor")) > 25:
            warnings.append((None, "asset %s anchor is over 25 words" % aid))
        asset_by_id[aid] = asset

    seq = int(num(scene.get("seq"), 0))
    max_clip = num(scene.get("max_clip_seconds"), 10.0)
    pad_cfg = scene.get("padding") or {}
    pad_mode = str(pad_cfg.get("mode") or "auto").lower()

    records = []
    cursor = 0.0
    timeline_mode = str(scene.get("timeline_mode") or "sequential")
    if timeline_mode not in ("sequential", "parallel_coverage"):
        errors.append((None, "unknown timeline_mode %r" % timeline_mode))
        timeline_mode = "sequential"
    seen_names = set()

    ordered = sorted(coverage, key=lambda s: num(s.get("shot"), 0))

    for shot_in in ordered:
        shot_no = int(num(shot_in.get("shot"), 0))
        for field in ("shot", "beat", "shot_size", "assets_in_frame"):
            if field not in shot_in or shot_in.get(field) is None or shot_in.get(field) == "":
                errors.append((shot_no, "coverage missing required field %s" % field))
        hint = shot_in.get("hint") or {}
        perf = shot_in.get("performance") or {}

        duration = num(perf.get("duration"), 0.0)
        if duration <= 0:
            errors.append((shot_no, "performance.duration must be greater than 0"))
            duration = 0.1

        if pad_mode == "fixed":
            pad_pre = r1(num(pad_cfg.get("pre"), 2.0))
            pad_post = r1(num(pad_cfg.get("post"), 2.0))
        else:
            pad_pre = r1(min(max(0.15 * duration, 0.5), 2.0))
            pad_post = pad_pre

        total = r1(pad_pre + duration + pad_post)
        if total > max_clip + 1e-6:
            pad_pre, pad_post = MIN_PAD, MIN_PAD
            total = r1(pad_pre + duration + pad_post)
            warnings.append((shot_no, "padding reduced to %.1fs per side to fit the "
                                      "%.1fs clip budget" % (MIN_PAD, max_clip)))
            if total > max_clip + 1e-6:
                errors.append((shot_no, "performance %.1fs alone exceeds the %.1fs budget; "
                                        "split the shot" % (duration, max_clip)))

        size = str(shot_in.get("shot_size") or hint.get("shot_size") or "MS").upper()
        if size not in FOV_BY_SIZE:
            errors.append((shot_no, "unknown shot_size %r" % size))
            size = "MS"
        fov = FOV_BY_SIZE[size]

        move = str(shot_in.get("camera_move") or hint.get("camera_move") or "static").lower()
        if move not in MOVE_TEXT:
            errors.append((shot_no, "unknown camera_move %r" % move))
            move = "static"

        raw_hint = str(hint.get("raw") or "")
        exact_override = "[SPECIAL CAMERA OVERRIDE]" in raw_hint
        # The exact literal tag is the authority; the boolean is only a parsed hint.
        special = exact_override
        if (hint.get("special_camera_override") or shot_in.get("special_camera_override")) and not exact_override:
            errors.append((shot_no, "special camera override flag requires exact tag in hint.raw"))
        downgrade = None
        if move in UNSAFE_MOVES and not special:
            downgrade = {
                "from": move,
                "to": DOWNGRADE_TO[move],
                "reason": "unsafe or compound move without the exact "
                          "[SPECIAL CAMERA OVERRIDE] tag",
            }
            move = DOWNGRADE_TO[move]
            warnings.append((shot_no, "camera move downgraded %s -> %s"
                             % (downgrade["from"], downgrade["to"])))
        exception_mode = bool(special and move in UNSAFE_MOVES)

        if timeline_mode == "parallel_coverage":
            source_range = shot_in.get("source_range") or []
            if len(source_range) != 2 or num(source_range[1]) <= num(source_range[0]):
                errors.append((shot_no, "parallel_coverage requires a valid source_range"))
            elif abs((num(source_range[1]) - num(source_range[0])) - duration) > 1e-3:
                errors.append((shot_no, "source_range duration does not match performance.duration"))
            render_start = 0.0
        else:
            source_range = shot_in.get("source_range")
            render_start = r1(cursor)
        perf_start = r1(render_start + pad_pre)
        perf_end = r1(perf_start + duration)
        render_end = r1(perf_end + pad_post)
        if timeline_mode == "sequential":
            cursor = render_end

        camera = str(shot_in.get("camera") or "A").upper()
        take = int(num(shot_in.get("take"), 1))
        filename = "S%02d_SH%03d_%s_v%02d.mp4" % (seq, shot_no, camera, take)
        if filename in seen_names:
            errors.append((shot_no, "duplicate filename %s" % filename))
        seen_names.add(filename)

        shot_assets = []
        for aid in shot_in.get("assets_in_frame") or []:
            card = asset_by_id.get(str(aid))
            if not card:
                errors.append((shot_no, "asset %r has no card" % str(aid)))
                continue
            shot_assets.append({
                "id": card.get("id"),
                "kind": card.get("kind", "object"),
                "tag": card.get("tag", ""),
                "state": card.get("state", ""),
                "anchor": card.get("anchor", ""),
            })

        elems = shot_in.get("elements_in_frame") or {}
        rigid = [str(x) for x in (elems.get("rigid") or [])]
        soft = [str(x) for x in (elems.get("soft") or [])]

        airflow = shot_in.get("airflow")
        if airflow is None:
            airflow = hint.get("airflow")
        if airflow is None:
            airflow = scene.get("airflow")
        if airflow is None:
            airflow = "none"
        airflow = str(airflow).lower()
        if airflow not in ("none", "soft_breeze", "short_gust"):
            errors.append((shot_no, "unknown airflow %r" % airflow))
            airflow = "none"

        record = {
            "seq": seq,
            "shot": shot_no,
            "camera": camera,
            "take": take,
            "filename": filename,
            "render_mode": str(shot_in.get("render_mode") or "AutoTrim"),
            "location": scene.get("location", ""),
            "interior": bool(scene.get("interior", True)),
            "time_of_day": scene.get("time_of_day", ""),
            "beat": shot_in.get("beat", ""),
            "shot_size": size,
            "fov_deg": fov,
            "camera_height": shot_in.get("camera_height") or "eye level",
            "camera_move": move,
            "exception_mode": exception_mode,
            "axis_side": shot_in.get("axis_side"),
            "coverage_group": shot_in.get("coverage_group"),
            "crossing": bool(shot_in.get("crossing")),
            "duration": r1(duration),
            "pad_pre": pad_pre,
            "pad_post": pad_post,
            "render_duration": total,
            "performance_range": [perf_start, perf_end],
            "render_range": [render_start, render_end],
            "source_range": source_range,
            "timeline_mode": timeline_mode,
            "airflow": airflow,
            "lut": scene.get("lut", ""),
            "light": scene.get("light") or {},
            "white_balance_k": int(num(scene.get("white_balance_k"), 5600)),
            "assets": shot_assets,
            "rigid": rigid,
            "soft": soft,
            "ke": perf.get("ke") or [],
            "acting": perf.get("acting", ""),
            "performance_tracks": perf.get("tracks") or [],
            "performance_source": perf.get("source", "provided"),
            "timing_source": perf.get("timing_source"),
            "dialogue": shot_in.get("dialogue") or [],
            "audio": shot_in.get("audio") or {},
            "hint": hint,
            "deviation": shot_in.get("deviation"),
            "downgrade": downgrade,
        }
        record["prompt"] = render_prompt(scene, record)
        records.append(record)

    scene_block = {
        "seq": seq,
        "title": scene.get("title", ""),
        "lut": scene.get("lut", ""),
        "global_style": scene.get("global_style"),
        "format": scene.get("format") or {},
        "max_clip_seconds": max_clip,
        "timeline_mode": timeline_mode,
        "scene_duration": scene.get("scene_duration"),
        "negative": normalize_negative(scene),
    }

    artifact = {
        "schema_version": SCHEMA_VERSION,
        "scene": scene_block,
        "shots": records,
    }
    artifact["prompt"] = "\n\n".join(rec["prompt"] for rec in records)
    return artifact, errors, warnings


# -------------------------------------------------------------------------- check

def check_artifact(artifact):
    """Validate an artifact against the QC gate. Returns {'errors': [], 'warnings': []}."""
    errors = []
    warnings = []
    scene = artifact.get("scene") or {}
    shots = artifact.get("shots") or []

    if not shots:
        errors.append((None, "artifact contains no shots"))

    max_clip = num(scene.get("max_clip_seconds"), 10.0)
    scene_lut = scene.get("lut")
    prev_end = None
    seen_names = set()
    axis_by_group = {}

    for sh in shots:
        n = sh.get("shot")
        prompt = str(sh.get("prompt") or "")
        low = prompt.lower()

        if sh.get("shot_size") not in FOV_BY_SIZE:
            errors.append((n, "shot_size %r is not an anchor" % sh.get("shot_size")))
        expected_fov = FOV_BY_SIZE.get(sh.get("shot_size"))
        if int(num(sh.get("fov_deg"), 0)) not in FOV_BY_SIZE.values():
            errors.append((n, "FOV %s is not an anchor value" % sh.get("fov_deg")))
        elif expected_fov is not None and int(num(sh.get("fov_deg"), 0)) != expected_fov:
            errors.append((n, "FOV %s does not match %s anchor (%s degrees)" %
                           (sh.get("fov_deg"), sh.get("shot_size"), expected_fov)))
        if sh.get("camera_move") not in MOVE_TEXT:
            errors.append((n, "unknown camera move %r" % sh.get("camera_move")))

        if has_focal_length(prompt):
            errors.append((n, "focal length in millimetres found in prompt"))

        total = num(sh.get("render_duration"))
        if total > max_clip + 1e-6:
            errors.append((n, "render_duration %.1fs over budget %.1fs" % (total, max_clip)))
        expected = r1(min(max(0.15 * num(sh.get("duration")), 0.5), 2.0))
        pad_pre = num(sh.get("pad_pre"))
        if abs(pad_pre - expected) > 0.11 and abs(pad_pre - MIN_PAD) > 1e-6:
            warnings.append((n, "pad_pre %.1fs differs from the computed %.1fs"
                             % (pad_pre, expected)))

        render_range = sh.get("render_range") or [0.0, 0.0]
        perf_range = sh.get("performance_range") or [0.0, 0.0]
        rr_start, rr_end = num(render_range[0]), num(render_range[1])
        pr_start, pr_end = num(perf_range[0]), num(perf_range[1])
        if abs((pr_start - rr_start) - pad_pre) > 1e-6:
            errors.append((n, "performance start is not render start + pad_pre"))
        if abs((rr_end - pr_end) - num(sh.get("pad_post"))) > 1e-6:
            errors.append((n, "render end is not performance end + pad_post"))
        if pr_end - pr_start <= 0:
            errors.append((n, "performance range is empty"))
        if str(scene.get("timeline_mode") or "sequential") == "sequential":
            if prev_end is not None:
                if rr_start < prev_end - 1e-6:
                    errors.append((n, "render range overlaps the previous shot"))
                elif rr_start > prev_end + 1e-6:
                    warnings.append((n, "timeline has a gap before this shot"))
            prev_end = rr_end
        else:
            source = sh.get("source_range") or []
            if len(source) != 2 or num(source[1]) <= num(source[0]):
                errors.append((n, "parallel coverage shot has invalid source_range"))
            elif abs((num(source[1]) - num(source[0])) - num(sh.get("duration"))) > 1e-3:
                errors.append((n, "source_range length differs from shot duration"))
            elif scene.get("scene_duration") is not None and (num(source[0]) < 0 or num(source[1]) > num(scene.get("scene_duration")) + 1e-6):
                errors.append((n, "source_range exceeds scene_duration"))
            if abs(rr_start) > 1e-6:
                errors.append((n, "parallel coverage render_range must use local zero start"))

        ke = sorted(sh.get("ke") or [], key=lambda k: num(k.get("t_in")))
        if not ke:
            errors.append((n, "no key events"))
        else:
            if abs(num(ke[0].get("t_in"))) > 1e-6:
                errors.append((n, "first key event must start at 0"))
            cursor = 0.0
            for event in ke:
                if abs(num(event.get("t_in")) - cursor) > 1e-6:
                    errors.append((n, "key event %s does not tile the performance"
                                   % event.get("id")))
                cursor = num(event.get("t_out"))
            if abs(cursor - num(sh.get("duration"))) > 1e-6:
                errors.append((n, "last key event must end at duration"))

        tracks = sh.get("performance_tracks") or []
        if tracks:
            track_ids = set()
            in_frame_ids = {str(a.get("id")) for a in (sh.get("assets") or [])}
            primary_count = 0
            event_ranges = {}
            for track in tracks:
                cid = str(track.get("character_id") or "")
                if not cid or cid in track_ids:
                    errors.append((n, "performance track has missing/duplicate character_id"))
                track_ids.add(cid)
                if cid not in in_frame_ids:
                    errors.append((n, "performance character %s is not in assets_in_frame" % cid))
                if track.get("role") == "primary":
                    primary_count += 1
                last_end = -1.0
                for event in sorted(track.get("events") or [], key=lambda e: num(e.get("t_in"))):
                    a, b = num(event.get("t_in"), -1), num(event.get("t_out"), -1)
                    if a < 0 or b <= a or b > num(sh.get("duration")) + 1e-6:
                        errors.append((n, "invalid event range in track %s" % cid))
                    if a < last_end - 1e-6:
                        errors.append((n, "overlapping events on character track %s" % cid))
                    if event.get("timing_source") not in ("authored", "estimated"):
                        errors.append((n, "invalid timing_source in track %s" % cid))
                    event_ranges[str(event.get("id"))] = (a, b)
                    last_end = b
            if tracks and primary_count != 1:
                errors.append((n, "shot must have exactly one primary performance track"))
            represented = set()
            represented_ranges = {}
            for event in ke:
                for actor in event.get("actors") or []:
                    if actor.get("character_id") not in track_ids:
                        errors.append((n, "KE references character outside shot tracks"))
                    for event_id in actor.get("event_ids") or []:
                        represented.add(event_id)
                        represented_ranges.setdefault(event_id, []).append((num(event.get("t_in")), num(event.get("t_out"))))
            expected_events = set(event_ranges)
            if represented != expected_events:
                errors.append((n, "derived KE actor references do not cover the selected track events"))
            for event_id, expected_range in event_ranges.items():
                ranges = sorted(represented_ranges.get(event_id) or [])
                if not ranges or abs(ranges[0][0] - expected_range[0]) > 1e-3 or abs(ranges[-1][1] - expected_range[1]) > 1e-3:
                    errors.append((n, "derived KE does not preserve event range %s" % event_id))
                elif any(abs(ranges[i][1] - ranges[i + 1][0]) > 1e-3 for i in range(len(ranges) - 1)):
                    errors.append((n, "derived KE has a gap/overlap inside event %s" % event_id))
        tags = []
        for asset in sh.get("assets") or []:
            tag = str(asset.get("tag") or "")
            if not tag:
                errors.append((n, "asset without tag"))
                continue
            tags.append(tag)
            if tag not in prompt:
                errors.append((n, "tag %s missing from prompt" % tag))
        if not tags:
            warnings.append((n, "no assets in frame"))

        if scene_lut and sh.get("lut") != scene_lut:
            errors.append((n, "LUT differs from the scene LUT"))

        air = str(sh.get("airflow") or "none")
        if air == "none":
            if re.search(r"\b(breeze|gust|wind|airflow)\b", prompt, re.IGNORECASE):
                errors.append((n, "airflow language present although air is none"))
        else:
            if air not in AIRFLOW_TEXT:
                errors.append((n, "unknown airflow %r" % air))
            elif "Air -" not in prompt:
                errors.append((n, "air is active but no air sentence in prompt"))

        if sh.get("camera_move") in UNSAFE_MOVES and not sh.get("exception_mode"):
            errors.append((n, "unsafe move without exception mode"))
        if sh.get("exception_mode") and "[SPECIAL CAMERA OVERRIDE]" not in str((sh.get("hint") or {}).get("raw") or ""):
            errors.append((n, "exception mode lacks exact [SPECIAL CAMERA OVERRIDE] tag in raw hint"))
        if sh.get("exception_mode") and "Reinforced lock" not in prompt:
            errors.append((n, "exception shot without a reinforced lock"))

        name = str(sh.get("filename") or "")
        if not re.match(r"^S\d{2}_SH\d{3}_[A-Z][A-Z0-9]?_v\d{2}\.mp4$", name):
            errors.append((n, "filename %r does not match the pattern" % name))
        if name in seen_names:
            errors.append((n, "duplicate filename %s" % name))
        seen_names.add(name)

        speech = 0.0
        track_ids = {str(t.get("character_id")) for t in (sh.get("performance_tracks") or [])}
        for line in sh.get("dialogue") or []:
            at = num(line.get("at"), -1)
            if at < 0 or at > num(sh.get("duration")) + 1e-6:
                errors.append((n, "dialogue timestamp outside shot performance range"))
            cid = str(line.get("character_id") or "")
            if cid and cid not in track_ids and not line.get("offscreen"):
                errors.append((n, "dialogue speaker is not in shot tracks and is not marked offscreen"))
            text = str(line.get("line") or "")
            cjk = len(re.findall(u"[\u3400-\u9fff]", text))
            words = len(re.findall(r"[A-Za-z0-9']+", text))
            speech += max(cjk / 4.0, words / 2.5)
        if speech > num(sh.get("duration")) * 0.9:
            warnings.append((n, "speech %.1fs does not fit %.1fs of performance"
                             % (speech, num(sh.get("duration")))))

        if str(sh.get("timing_source") or "") == "estimated":
            warnings.append((n, "beat timing estimated from prose; check it against "
                                "the edit before cutting"))

        group = sh.get("coverage_group")
        side = sh.get("axis_side")
        if group and side:
            known = axis_by_group.get(group)
            if known is not None and known != side and not sh.get("crossing"):
                warnings.append((n, "screen direction changes inside coverage group %r"
                                 % group))
            axis_by_group[group] = side

        if re.search(r"\b(hard cut|smash cut|dissolve|wipe|split screen|montage)\b",
                     prompt, re.IGNORECASE):
            errors.append((n, "edit instruction found in prompt"))

        latin_words, cjk_chars = prompt_metrics(prompt)
        if latin_words > 320:
            errors.append((n, "prompt is %d Latin words, exceeds hard 320-word ceiling" % latin_words))
        elif latin_words > 280:
            warnings.append((n, "prompt is %d Latin words, above 280-word target" % latin_words))
        elif 0 < latin_words < 150 and cjk_chars < 300:
            warnings.append((n, "prompt is %d Latin words, below 150-word target" % latin_words))
        if cjk_chars > 700:
            errors.append((n, "prompt is %d CJK characters, exceeds hard 700-character ceiling" % cjk_chars))
        elif cjk_chars > 560:
            warnings.append((n, "prompt is %d CJK characters, above 560-character target" % cjk_chars))
        elif 0 < cjk_chars < 100 and latin_words < 150:
            warnings.append((n, "prompt is %d CJK characters, below 100-character target" % cjk_chars))

        for term in BANNED_TERMS:
            if term in low:
                warnings.append((n, "engine or post language %r in prompt" % term))

    return {"errors": errors, "warnings": warnings}


# ------------------------------------------------------------------------- report

def report(artifact, result):
    scene = artifact.get("scene") or {}
    shots = artifact.get("shots") or []
    lines = []
    title = scene.get("title") or ""
    header = "QC REPORT - scene %s" % scene.get("seq", "?")
    if title:
        header += " (%s)" % title
    header += " - %d shots - %s" % (len(shots), "FAIL" if result["errors"] else "PASS")
    lines.append(header)
    lines.append("")
    lines.append("shot | render range      | performance range | size/FOV  | move")
    for sh in shots:
        rr = sh.get("render_range") or [0.0, 0.0]
        pr = sh.get("performance_range") or [0.0, 0.0]
        lines.append("%4s | %5ss - %5ss | %5ss - %5ss | %-6s %3s | %s"
                     % (sh.get("shot"), fmt(rr[0]), fmt(rr[1]),
                        fmt(pr[0]), fmt(pr[1]),
                        sh.get("shot_size"), sh.get("fov_deg"), sh.get("camera_move")))

    if result["warnings"]:
        lines.append("")
        lines.append("WARNINGS")
        for shot, message in result["warnings"]:
            lines.append("  [W] %s%s" % (shot_prefix(shot), message))

    if result["errors"]:
        lines.append("")
        lines.append("ERRORS")
        for shot, message in result["errors"]:
            lines.append("  [E] %s%s" % (shot_prefix(shot), message))

    exceptions = [sh for sh in shots if sh.get("exception_mode")]
    if exceptions:
        lines.append("")
        lines.append("EXCEPTION MODE - risk warning, report only, never in the prompt")
        for sh in exceptions:
            lines.append("  shot %s: high risk of asset drift, facial distortion and "
                         "geometry clipping; reinforced identity lock injected."
                         % sh.get("shot"))

    downgrades = [sh for sh in shots if sh.get("downgrade")]
    if downgrades:
        lines.append("")
        lines.append("CAMERA DOWNGRADES")
        for sh in downgrades:
            item = sh.get("downgrade") or {}
            lines.append("  shot %s: %s -> %s (%s)"
                         % (sh.get("shot"), item.get("from"), item.get("to"),
                            item.get("reason")))

    deviations = [sh for sh in shots if (sh.get("deviation") or {}).get("from_hint")]
    if deviations:
        lines.append("")
        lines.append("HINT DEVIATIONS")
        for sh in deviations:
            item = sh.get("deviation") or {}
            lines.append("  shot %s: %s" % (sh.get("shot"), item.get("reason")))

    return "\n".join(lines)


# ---------------------------------------------------------------------------- cli

def cmd_plan(args):
    doc = load_json(args.input)
    artifact, errors, warnings = build(doc)
    result = check_artifact(artifact)
    errors.extend(result["errors"])
    warnings.extend(result["warnings"])
    for shot, message in errors:
        sys.stderr.write("[E] %s%s\n" % (shot_prefix(shot), message))
    for shot, message in warnings:
        sys.stderr.write("[W] %s%s\n" % (shot_prefix(shot), message))
    if errors:
        print("planning blocked; no shots.json written")
        return 1
    outdir = args.out
    path = os.path.join(outdir, "shots.json")
    write_json(path, artifact)
    print("planned %d shots -> %s" % (len(artifact["shots"]), path))
    return 0


def cmd_render(args):
    artifact = load_json(args.artifact)
    scene = artifact.get("scene") or {}
    negative = normalize_negative(scene)
    for sh in artifact.get("shots") or []:
        print("=" * 72)
        print("%s | %s | %s" % (sh.get("filename"), sh.get("shot_size"),
                                sh.get("camera_move")))
        print("=" * 72)
        print(sh.get("prompt") or render_prompt(scene, sh))
        if negative.get("mode") == "separate":
            print("")
            print("NEGATIVE: " + ", ".join(negative.get("items") or []))
        print("")
    return 0


def cmd_check(args):
    artifact = load_json(args.artifact)
    result = check_artifact(artifact)
    print(report(artifact, result))
    return 1 if result["errors"] else 0


def cmd_all(args):
    doc = load_json(args.input)
    artifact, build_errors, build_warnings = build(doc)
    result = check_artifact(artifact)
    result["errors"] = build_errors + result["errors"]
    result["warnings"] = build_warnings + result["warnings"]

    outdir = args.out
    text_report = report(artifact, result)
    write_text(os.path.join(outdir, "qc-report.txt"), text_report)
    print(text_report)
    if result["errors"]:
        print("\nDELIVERY BLOCKED: QC contains errors; no shots.json or prompt files written.")
        return 1

    prompt_dir = os.path.join(outdir, "prompts")
    negative = normalize_negative(artifact.get("scene") or {})
    for sh in artifact.get("shots") or []:
        text = sh.get("prompt") or ""
        if negative.get("mode") == "separate":
            text = text + "\n\nNEGATIVE PROMPT\n" + ", ".join(negative.get("items") or [])
        name = str(sh.get("filename") or "shot").replace(".mp4", ".txt")
        write_text(os.path.join(prompt_dir, name), text)

    write_json(os.path.join(outdir, "shots.json"), artifact)
    print("\nwrote %s/shots.json, %s/qc-report.txt, %d prompt files"
          % (outdir, outdir, len(artifact.get("shots") or [])))
    return 0


def cmd_selftest(args=None):
    here = os.path.dirname(os.path.abspath(__file__))
    example = os.path.normpath(os.path.join(here, "..", "assets", "example-scene.json"))
    if not os.path.exists(example):
        print("selftest: example scene not found at %s" % example)
        return 2

    doc = load_json(example)
    artifact, build_errors, build_warnings = build(doc)
    result = check_artifact(artifact)
    result["errors"] = build_errors + result["errors"]
    result["warnings"] = build_warnings + result["warnings"]
    print(report(artifact, result))
    print("")

    shots = artifact["shots"]
    contiguous = True
    for index in range(len(shots) - 1):
        if abs(shots[index]["render_range"][1] - shots[index + 1]["render_range"][0]) > 1e-6:
            contiguous = False

    checks = [
        ("shot count matches the coverage list",
         len(shots) == len(doc.get("coverage") or [])),
        ("QC gate has no errors", not result["errors"]),
        ("all FOV values are anchors",
         all(sh["fov_deg"] in FOV_BY_SIZE.values() for sh in shots)),
        ("timeline is contiguous", contiguous),
        ("every prompt rendered", all(len(sh.get("prompt", "")) > 200 for sh in shots)),
        ("no focal length in any prompt",
         not any(has_focal_length(sh.get("prompt", "")) for sh in shots)),
        ("filenames are unique",
         len({sh["filename"] for sh in shots}) == len(shots)),
    ]

    failed = [name for name, ok in checks if not ok]
    for name, ok in checks:
        print("  [%s] %s" % ("ok" if ok else "FAIL", name))
    print("")
    if failed:
        print("selftest FAILED: " + "; ".join(failed))
        return 1
    print("selftest PASSED - %d shots, toolchain works." % len(shots))
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="footage_mode.py",
        description="footage-mode shot planner, prompt renderer and QC validator")
    sub = parser.add_subparsers(dest="cmd")

    p_plan = sub.add_parser("plan", help="build out/shots.json from a scene document")
    p_plan.add_argument("input")
    p_plan.add_argument("-o", "--out", default="out")
    p_plan.set_defaults(func=cmd_plan)

    p_render = sub.add_parser("render", help="print prompts from an artifact")
    p_render.add_argument("artifact")
    p_render.set_defaults(func=cmd_render)

    p_check = sub.add_parser("check", help="validate an artifact, exit 1 on error")
    p_check.add_argument("artifact")
    p_check.set_defaults(func=cmd_check)

    p_all = sub.add_parser("all", help="plan, check and write prompt files")
    p_all.add_argument("input")
    p_all.add_argument("-o", "--out", default="out")
    p_all.set_defaults(func=cmd_all)

    p_self = sub.add_parser("selftest", help="run the bundled example end to end")
    p_self.set_defaults(func=cmd_selftest)

    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
