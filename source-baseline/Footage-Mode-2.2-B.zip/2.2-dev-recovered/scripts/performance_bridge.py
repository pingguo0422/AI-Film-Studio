#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Performance-to-Coverage Bridge 1.0.

Input: ACTING TASK prose + bridge config JSON.
Output: Footage-Mode scene JSON with per-character tracks and shot-local concurrent KE.
No third-party dependencies; Python 3.7+.
"""
import argparse
import json
import os
import re
import sys

HEADER = re.compile(r'^\s*ACTING\s+TASK\s*[—–\-:]\s*(.+?)\s*$', re.I)
SHOT = re.compile(r'\[\s*shot\s*(\d+)\s*\]', re.I)
LABELS = {
    'SCENE DIRECTION': 'scene_direction', 'MOTIVE': 'motive', 'GOAL': 'goal',
    'OBSTACLE': 'obstacle', 'TACTIC': 'tactic'
}
LABEL_RE = re.compile(r'^\s*(SCENE\s+DIRECTION|MOTIVE|GOAL|OBSTACLE|TACTIC)\b[^:：]*[:：]\s*(.*)$', re.I)
MOMENT_RE = re.compile(r'^\s*MOMENT[\s\-]*TO[\s\-]*MOMENT\b.*$', re.I)
BULLET_RE = re.compile(r'^\s*(?:[—–\-•·*]+)\s*(.+)$')
SAFETY_RE = re.compile(r'\(?\s*Safety\s*[:：]\s*(.*?)\s*[)）]?\s*$', re.I)
PAREN_NOTE = re.compile(r'[（(]([^（）()]*)[）)]')
QUOTE_RE = re.compile(r'[“"]([^”"]+)[”"]')


def read_text(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        return f.read()


def read_json(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        return json.load(f)


def write_json(path, data):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')


def clean_name(header):
    shot_match = SHOT.search(header)
    shot_no = int(shot_match.group(1)) if shot_match else None
    no_shot = SHOT.sub('', header)
    notes = PAREN_NOTE.findall(no_shot)
    name = PAREN_NOTE.sub('', no_shot)
    name = re.sub(r'\s+', ' ', name).strip(' —–-:：')
    return name or 'CHARACTER', shot_no, notes


def parse_blocks(text):
    blocks, cur, label = [], None, ''
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith('```'):
            continue
        hm = HEADER.match(raw)
        if hm:
            name, shot_no, notes = clean_name(hm.group(1))
            cur = {'character_name': name, 'header_shot': shot_no,
                   'role_notes': notes, 'scene_direction': '', 'motive': '',
                   'goal': '', 'obstacle': '', 'tactic': '', 'safety': '', 'beats': []}
            blocks.append(cur)
            label = ''
            continue
        if cur is None:
            continue
        safety = SAFETY_RE.match(line)
        if safety:
            cur['safety'] = safety.group(1).strip()
            label = ''
            continue
        # Also support Safety metadata embedded in full-width/ASCII parentheses.
        if re.match(r'^[（(]\s*Safety\s*[:：]', line, re.I):
            val = re.sub(r'^[（(]\s*Safety\s*[:：]\s*', '', line, flags=re.I)
            val = re.sub(r'[）)]\s*$', '', val).strip()
            cur['safety'] = val
            label = ''
            continue
        if MOMENT_RE.match(line):
            label = 'beats'
            continue
        lm = LABEL_RE.match(line)
        if lm:
            key = re.sub(r'\s+', ' ', lm.group(1).upper())
            label = LABELS[key]
            cur[label] = lm.group(2).strip()
            continue
        bm = BULLET_RE.match(line)
        if bm:
            raw_beat = bm.group(1).strip()
            # Strip Safety annotations before beat parsing, even if appended inline.
            sm = re.search(r'[（(]\s*Safety\s*[:：].*?[）)]', raw_beat, re.I)
            if sm:
                cur['safety'] = sm.group(0)
                raw_beat = raw_beat[:sm.start()].strip()
            quotes = QUOTE_RE.findall(raw_beat)
            dialogue = quotes[0].strip() if quotes else ''
            action = QUOTE_RE.sub('', raw_beat)
            action = re.sub(r'\s+', ' ', action).strip(' ：:—–-，,。')
            if not action and dialogue:
                action = 'holds the line'
            cur['beats'].append({'index': len(cur['beats']), 'action': action,
                                 'dialogue': dialogue})
            label = 'beats'
            continue
        if label == 'beats' and cur['beats']:
            # A continuation belongs to the prior action, never to Safety metadata.
            cur['beats'][-1]['action'] = (cur['beats'][-1]['action'] + ' ' + line).strip()
        elif label and label != 'beats':
            cur[label] = (cur[label] + ' ' + line).strip()
    return blocks


def normalize_intervals(block, track_cfg, scene_duration):
    """Use explicit event timing where supplied; otherwise equal per-track estimates."""
    beats = block['beats']
    timing = track_cfg.get('events') or []
    by_index = {int(e['beat_index']): e for e in timing if 'beat_index' in e}
    events = []
    if timing:
        missing = [i for i in range(len(beats)) if i not in by_index]
        if missing:
            raise ValueError('%s: timing config missing beat_index %s' % (block['character_name'], missing))
        for i, beat in enumerate(beats):
            cfg = by_index[i]
            t0, t1 = float(cfg['t_in']), float(cfg['t_out'])
            source = cfg.get('timing_source', 'authored')
            events.append(make_event(block, beat, i, t0, t1, source))
    else:
        # Conservative fallback: equal slots across the full scene; explicitly estimated.
        if not beats:
            return []
        slot = scene_duration / float(len(beats))
        for i, beat in enumerate(beats):
            t0 = round(i * slot, 3)
            t1 = round((i + 1) * slot, 3) if i < len(beats) - 1 else scene_duration
            events.append(make_event(block, beat, i, t0, t1, 'estimated'))
    previous_end = -1.0
    for ev in events:
        if ev['t_in'] < 0 or ev['t_out'] <= ev['t_in'] or ev['t_out'] > scene_duration + 1e-6:
            raise ValueError('%s: invalid event range %s-%s' % (block['character_name'], ev['t_in'], ev['t_out']))
        if ev['t_in'] < previous_end - 1e-6:
            raise ValueError('%s: overlapping events on one character track' % block['character_name'])
        previous_end = ev['t_out']
    return events


def make_event(block, beat, i, t0, t1, timing_source):
    return {'id': '%s_E%02d' % (slug(block['character_name']), i + 1),
            'beat_index': i, 't_in': round(t0, 3), 't_out': round(t1, 3),
            'action': beat['action'], 'dialogue': beat['dialogue'],
            'timing_source': timing_source}


def slug(s):
    s = re.sub(r'[^\w]+', '_', s, flags=re.UNICODE).strip('_').lower()
    return s or 'character'


def intersect_event(event, start, end):
    lo, hi = max(event['t_in'], start), min(event['t_out'], end)
    if hi <= lo + 1e-6:
        return None
    return {'id': event['id'], 'source_event_id': event['id'],
            'beat_index': event['beat_index'], 't_in': round(lo - start, 3),
            't_out': round(hi - start, 3), 'action': event['action'],
            'dialogue': event['dialogue'], 'timing_source': event['timing_source']}


def atomic_ke(tracks, duration):
    points = {0.0, round(duration, 3)}
    for tr in tracks:
        for ev in tr['events']:
            points.add(round(ev['t_in'], 3)); points.add(round(ev['t_out'], 3))
    edges = sorted(points)
    ke = []
    for idx, (a, b) in enumerate(zip(edges, edges[1:])):
        if b <= a + 1e-6:
            continue
        actors = []
        for tr in tracks:
            active = [e for e in tr['events'] if e['t_in'] < b - 1e-6 and e['t_out'] > a + 1e-6]
            if active:
                actors.append({'character_id': tr['character_id'],
                               'character_name': tr['character_name'],
                               'role': tr['role'],
                               'actions': [e['action'] for e in active if e['action']],
                               'event_ids': [e['id'] for e in active]})
        ke.append({'id': 'KE%02d' % (idx + 1), 't_in': a, 't_out': b,
                   'action': ' | '.join('%s: %s' % (x['character_name'], '; '.join(x['actions'])) for x in actors) or 'continuous scene interval; no new action',
                   'actors': actors})
    return ke


def build(text, cfg):
    blocks = parse_blocks(text)
    if not blocks:
        raise ValueError('no ACTING TASK blocks found')
    scene_duration = float(cfg['scene_duration'])
    if scene_duration <= 0:
        raise ValueError('scene_duration must be > 0')
    by_name = {b['character_name']: b for b in blocks}
    track_cfg = cfg.get('tracks') or {}
    asset_map = cfg.get('character_assets') or {}
    tracks = []
    for name, block in by_name.items():
        if name not in asset_map:
            raise ValueError('character_assets missing mapping for %s' % name)
        tc = track_cfg.get(name, {})
        events = normalize_intervals(block, tc, scene_duration)
        tracks.append({'character_id': asset_map[name], 'character_name': name,
                       'scene_direction': block['scene_direction'], 'motive': block['motive'],
                       'goal': block['goal'], 'obstacle': block['obstacle'],
                       'tactic': block['tactic'], 'safety': block['safety'],
                       'role_notes': block['role_notes'], 'events': events})
    track_by_name = {t['character_name']: t for t in tracks}
    coverage_out = []
    for shot_cfg in cfg.get('coverage') or []:
        source = shot_cfg.get('source_range')
        if not source or len(source) != 2:
            raise ValueError('shot %s missing source_range' % shot_cfg.get('shot'))
        start, end = float(source[0]), float(source[1])
        if start < 0 or end <= start or end > scene_duration + 1e-6:
            raise ValueError('shot %s has invalid source_range' % shot_cfg.get('shot'))
        selected_names = [shot_cfg.get('primary_character')] + (shot_cfg.get('secondary_characters') or [])
        selected_names = [n for n in selected_names if n]
        selected_tracks = []
        for name in selected_names:
            if name not in track_by_name:
                raise ValueError('shot %s references unknown character %s' % (shot_cfg.get('shot'), name))
            original = track_by_name[name]
            local_events = []
            for ev in original['events']:
                clipped = intersect_event(ev, start, end)
                if clipped:
                    local_events.append(clipped)
            if local_events:
                selected_tracks.append({'character_id': original['character_id'],
                                        'character_name': name,
                                        'role': 'primary' if name == shot_cfg.get('primary_character') else 'secondary',
                                        'motive': original['motive'], 'goal': original['goal'],
                                        'obstacle': original['obstacle'], 'tactic': original['tactic'],
                                        'safety': original['safety'], 'events': local_events})
        duration = round(end - start, 3)
        ke = atomic_ke(selected_tracks, duration)
        dialogue = []
        for tr in selected_tracks:
            for ev in tr['events']:
                if ev['dialogue']:
                    dialogue.append({'speaker': tr['character_name'], 'line': ev['dialogue'],
                                     'at': ev['t_in'], 'character_id': tr['character_id']})
        if shot_cfg.get('include_offscreen_dialogue'):
            selected_ids = {t['character_id'] for t in selected_tracks}
            for original in tracks:
                if original['character_id'] in selected_ids:
                    continue
                for ev in original['events']:
                    clipped = intersect_event(ev, start, end)
                    if clipped and clipped['dialogue']:
                        dialogue.append({'speaker': original['character_name'], 'line': clipped['dialogue'],
                                         'at': clipped['t_in'], 'character_id': original['character_id'],
                                         'offscreen': True})
        dialogue.sort(key=lambda d: d['at'])
        perf = {'duration': duration, 'source': 'provided',
                'timing_source': 'estimated' if any(e['timing_source'] == 'estimated' for t in selected_tracks for e in t['events']) else 'authored',
                'acting': ' '.join('%s — %s' % (t['character_name'], t['tactic']) for t in selected_tracks if t.get('tactic')),
                'tracks': selected_tracks, 'ke': ke}
        shot = dict(shot_cfg)
        for key in ('primary_character', 'secondary_characters', 'include_offscreen_dialogue'):
            shot.pop(key, None)
        shot['source_range'] = [start, end]
        shot['performance'] = perf
        shot['dialogue'] = dialogue
        coverage_out.append(shot)
    if not coverage_out:
        raise ValueError('coverage must contain at least one shot')
    scene = dict(cfg.get('scene') or {})
    scene['timeline_mode'] = 'parallel_coverage'
    scene['scene_duration'] = scene_duration
    return {'schema_version': '1.1', 'scene': scene,
            'assets': cfg.get('assets') or [], 'coverage': coverage_out,
            'bridge': {'version': '1.0', 'source': 'ACTING TASK prose',
                       'timing_note': 'Any event marked estimated is provisional, not measured.'}}


def main():
    p = argparse.ArgumentParser(description='Convert per-character Acting Skill tracks to Footage-Mode parallel coverage.')
    p.add_argument('acting_text'); p.add_argument('config_json'); p.add_argument('-o', '--out', required=True)
    args = p.parse_args()
    try:
        result = build(read_text(args.acting_text), read_json(args.config_json))
        write_json(args.out, result)
        print('wrote %s (%d parallel coverage shots)' % (args.out, len(result['coverage'])))
        for shot in result['coverage']:
            print('shot %s camera %s source=%s duration=%.3fs tracks=%d KE=%d' % (
                shot['shot'], shot.get('camera', 'A'), shot['source_range'],
                shot['performance']['duration'], len(shot['performance']['tracks']), len(shot['performance']['ke'])))
        return 0
    except Exception as exc:
        print('[E] bridge failed: %s' % exc, file=sys.stderr)
        return 1

if __name__ == '__main__':
    sys.exit(main())
