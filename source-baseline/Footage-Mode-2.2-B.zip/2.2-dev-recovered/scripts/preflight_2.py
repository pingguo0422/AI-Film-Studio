#!/usr/bin/env python3
"""Run the 2.0 director, spatial and continuity review modules on a scene JSON."""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path: sys.path.insert(0, HERE)
from director_intelligence import analyze_scene
from spatial_intelligence import validate_spatial
from continuity_engine import validate_continuity

def run(doc):
    director = analyze_scene(doc)
    spatial = validate_spatial(doc)
    continuity = validate_continuity(doc)
    statuses = [spatial["status"], continuity["status"]]
    overall = "FAIL" if "FAIL" in statuses else ("INCOMPLETE" if "INCOMPLETE" in statuses else "PASS")
    return {"schema_version":"2.0","overall_status":overall,
            "director_intelligence":director,
            "spatial_intelligence":spatial,
            "continuity_engine":continuity,
            "human_review_required":True}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input", help="scene JSON")
    ap.add_argument("-o","--output", help="report JSON path")
    args = ap.parse_args()
    with open(args.input,encoding="utf-8") as f: doc=json.load(f)
    result=run(doc)
    data=json.dumps(result,ensure_ascii=False,indent=2)
    if args.output:
        with open(args.output,"w",encoding="utf-8") as f: f.write(data+"\n")
    print(data)
    return 1 if result["overall_status"] == "FAIL" else 0

if __name__ == "__main__":
    raise SystemExit(main())
