#!/usr/bin/env python3
"""Integrated Footage-Mode 2.1 preflight (2.0 checks plus art direction)."""
from __future__ import annotations

import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from director_intelligence import analyze_scene
from spatial_intelligence import validate_spatial
from continuity_engine import validate_continuity
from art_director import draft as draft_visual_bible
from art_director import validate as validate_visual_bible


def run(doc, visual_bible=None):
    """Run all 2.0 checks and 2.1 art-direction validation."""
    director = analyze_scene(doc)
    spatial = validate_spatial(doc)
    continuity = validate_continuity(doc)
    bible = visual_bible if visual_bible is not None else draft_visual_bible(doc)
    art = validate_visual_bible(bible, source_doc=doc)
    statuses = [spatial["status"], continuity["status"], art["status"]]
    overall = "FAIL" if "FAIL" in statuses else (
        "INCOMPLETE" if "INCOMPLETE" in statuses else "PASS")
    return {
        "schema_version": "2.1",
        "overall_status": overall,
        "director_intelligence": director,
        "spatial_intelligence": spatial,
        "continuity_engine": continuity,
        "art_director": art,
        "visual_bible": bible,
        "human_review_required": True,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help="scene JSON")
    parser.add_argument("-o", "--output", help="report JSON path")
    parser.add_argument("--visual-bible", help="optional existing Visual Bible JSON to validate")
    parser.add_argument("--draft-visual-bible", help="write generated Visual Bible JSON to this path")
    args = parser.parse_args(argv)

    with open(args.input, encoding="utf-8") as handle:
        doc = json.load(handle)
    bible = None
    if args.visual_bible:
        with open(args.visual_bible, encoding="utf-8") as handle:
            bible = json.load(handle)
    result = run(doc, bible)
    if args.draft_visual_bible:
        with open(args.draft_visual_bible, "w", encoding="utf-8") as handle:
            json.dump(result["visual_bible"], handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            handle.write(rendered + "\n")
    print(rendered)
    return 1 if result["overall_status"] == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(main())
