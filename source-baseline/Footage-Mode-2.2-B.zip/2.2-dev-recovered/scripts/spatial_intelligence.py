#!/usr/bin/env python3
"""Spatial geography and screen-axis validation for Footage-Mode 2.0."""
from __future__ import annotations
import math

EPS = 1e-6

def _xy(value):
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        return None
    try: return (float(value[0]), float(value[1]))
    except (TypeError, ValueError): return None

def _cross(a, b, p):
    return (b[0]-a[0])*(p[1]-a[1]) - (b[1]-a[1])*(p[0]-a[0])

def validate_spatial(doc):
    scene = doc.get("scene") or {}
    geo = scene.get("geography") or {}
    axis = geo.get("axis") or {}
    chars = axis.get("characters") or []
    char_pos = geo.get("character_anchors") or {}
    issues = []
    warnings = []
    if not geo:
        warnings.append("scene.geography is absent; spatial continuity cannot be verified.")
        return {"module":"Spatial Intelligence 2.0","status":"INCOMPLETE",
                "errors":issues,"warnings":warnings,"camera_sides":{}}
    if len(chars) == 2:
        a, b = chars
        pa, pb = _xy(char_pos.get(a)), _xy(char_pos.get(b))
        if pa is None or pb is None:
            warnings.append("Axis characters are declared but both character_anchors coordinates are not available.")
        elif math.dist(pa, pb) < EPS:
            issues.append("Axis anchor characters occupy the same coordinate; axis is undefined.")
    elif chars:
        warnings.append("geography.axis.characters should contain exactly two axis-anchor character IDs.")
        pa = pb = None
    else:
        pa = pb = None

    sides = {}
    for shot in doc.get("coverage") or []:
        sid = str(shot.get("shot", "?"))
        cam = _xy(shot.get("camera_position"))
        if cam is None:
            warnings.append("Shot %s has no camera_position; physical axis side is unverified." % sid)
            continue
        if pa is not None and pb is not None:
            val = _cross(pa, pb, cam)
            if abs(val) < EPS:
                issues.append("Shot %s camera lies on the declared axis; side is ambiguous." % sid)
                side = "on_axis"
            else:
                side = "positive" if val > 0 else "negative"
            sides[sid] = side
            if shot.get("axis_side") in ("left", "right"):
                shot["_computed_axis_side"] = side
    groups = {}
    for shot in doc.get("coverage") or []:
        group = shot.get("coverage_group")
        sid = str(shot.get("shot", "?"))
        side = sides.get(sid)
        if group and side and side != "on_axis":
            groups.setdefault(str(group), []).append((sid, side, shot))
    for group, entries in groups.items():
        previous_side = None
        for sid, side, shot in entries:
            if previous_side is not None and side != previous_side:
                if shot.get("crossing") is not True:
                    issues.append("Shot %s in coverage_group %s crosses the measured axis without crossing=true." % (sid, group))
                elif not shot.get("crossing_reason"):
                    warnings.append("Shot %s declares an axis crossing but has no crossing_reason." % sid)
            previous_side = side

    blocking = geo.get("blocking") or []
    for item in blocking:
        cid = item.get("character_id")
        start, end = item.get("t_in"), item.get("t_out")
        pos = _xy(item.get("position"))
        if not cid or pos is None:
            issues.append("Blocking record requires character_id and numeric position [x,y].")
        try:
            if start is None or end is None or float(end) <= float(start):
                issues.append("Blocking record for %s requires t_out > t_in." % (cid or "unknown"))
        except (TypeError, ValueError):
            issues.append("Blocking record for %s has invalid time values." % (cid or "unknown"))
    return {"module":"Spatial Intelligence 2.0",
            "status":"FAIL" if issues else ("INCOMPLETE" if warnings else "PASS"),
            "errors":issues,"warnings":warnings,"camera_sides":sides}
