import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from art_director import draft, validate
from preflight_2_1 import run


class ArtDirector21Tests(unittest.TestCase):
    def setUp(self):
        self.scene = {
            "project": "Test Project",
            "scene": {"seq": "S01", "title": "A room", "period": "1930s", "region": "Shanghai"},
            "assets": [
                {"id": "hero", "kind": "character", "tag": "@image1", "state": "wet coat", "anchor": "man, dark wool coat"},
                {"id": "watch", "kind": "prop", "state": "cracked glass", "anchor": "silver pocket watch"},
                {"id": "room", "kind": "set", "anchor": "wood-paneled office"},
            ],
            "coverage": [],
        }

    def test_draft_creates_visual_bible_schema(self):
        bible = draft(self.scene)
        self.assertEqual(bible["schema_version"], "2.1")
        self.assertEqual(bible["document_type"], "visual_bible")

    def test_character_visual_design_uses_source_anchor(self):
        bible = draft(self.scene)
        char = bible["casting_and_character_visuals"][0]
        self.assertEqual(char["asset_id"], "hero")
        self.assertIn("dark wool coat", char["casting_brief"])

    def test_character_gets_costume_first_look(self):
        bible = draft(self.scene)
        look = bible["costume_and_wardrobe"][0]
        self.assertEqual(look["asset_id"], "hero")
        self.assertEqual(look["approval_state"], "draft")

    def test_prop_design_is_preserved(self):
        bible = draft(self.scene)
        self.assertEqual(bible["props"][0]["asset_id"], "watch")
        self.assertIn("silver pocket watch", bible["props"][0]["design_brief"])

    def test_set_design_is_preserved(self):
        bible = draft(self.scene)
        self.assertEqual(bible["sets_and_locations"][0]["asset_id"], "room")
        self.assertIn("wood-paneled", bible["sets_and_locations"][0]["design_brief"])

    def test_draft_never_auto_approves_assets(self):
        bible = draft(self.scene)
        states = [x["approval_state"] for key in (
            "casting_and_character_visuals", "costume_and_wardrobe", "props", "sets_and_locations"
        ) for x in bible[key]]
        self.assertTrue(states)
        self.assertEqual(set(states), {"draft"})

    def test_missing_period_is_explicitly_incomplete(self):
        scene = {"scene": {}, "assets": []}
        bible = draft(scene)
        report = validate(bible, source_doc=scene)
        self.assertEqual(report["status"], "INCOMPLETE")
        self.assertTrue(any("period" in w.lower() or "年代" in w for w in report["warnings"]))

    def test_invalid_approval_state_fails(self):
        bible = draft(self.scene)
        bible["props"][0]["approval_state"] = "approved_by_ai"
        self.assertEqual(validate(bible, self.scene)["status"], "FAIL")

    def test_production_locked_requires_director_approval(self):
        bible = draft(self.scene)
        bible["props"][0]["approval_state"] = "production_locked"
        report = validate(bible, self.scene)
        self.assertEqual(report["status"], "FAIL")
        self.assertTrue(any("director_approved_by" in e for e in report["errors"]))

    def test_visual_bible_cannot_reference_unknown_source_asset(self):
        bible = draft(self.scene)
        bible["props"][0]["asset_id"] = "not-in-scene"
        report = validate(bible, self.scene)
        self.assertEqual(report["status"], "FAIL")
        self.assertTrue(any("absent from source scene" in e for e in report["errors"]))

    def test_integrated_preflight_includes_art_director(self):
        report = run(self.scene)
        self.assertIn("art_director", report)
        self.assertIn("visual_bible", report)
        self.assertEqual(report["schema_version"], "2.1")
        self.assertTrue(report["human_review_required"])


if __name__ == "__main__":
    unittest.main()
