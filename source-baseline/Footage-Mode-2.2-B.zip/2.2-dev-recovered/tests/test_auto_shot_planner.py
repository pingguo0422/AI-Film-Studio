#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SCRIPTS = os.path.join(ROOT, "scripts")
ASSETS = os.path.join(ROOT, "assets")
sys.path.insert(0, SCRIPTS)
import auto_shot_planner


class AutoShotPlannerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(os.path.join(ASSETS, "dewei-acting-task.txt"), encoding="utf-8") as f:
            cls.acting = f.read()
        with open(os.path.join(ASSETS, "dewei-bridge-config.json"), encoding="utf-8") as f:
            cls.cfg = json.load(f)

    def test_master_and_coverage_types(self):
        result = auto_shot_planner.plan(self.acting, self.cfg, max_shots=12)
        self.assertEqual(result["coverage"][0]["planner"]["kind"], "master")
        self.assertEqual(result["coverage"][0]["planner"]["primary_character"], "黄德威")
        kinds = {x["planner"]["kind"] for x in result["coverage"]}
        self.assertTrue({"speaker", "reaction", "two_shot", "action_detail"}.issubset(kinds))

    def test_parallel_source_time_is_preserved(self):
        result = auto_shot_planner.plan(self.acting, self.cfg, max_shots=12)
        # Distinct cameras may overlap in scene source time; this is intentional.
        ranges = [x["source_range"] for x in result["coverage"][1:]]
        self.assertTrue(any(a[0] == b[0] and a[1] == b[1]
                            for i, a in enumerate(ranges)
                            for b in ranges[i + 1:]))

    def test_cap_includes_master(self):
        result = auto_shot_planner.plan(self.acting, self.cfg, max_shots=5)
        self.assertEqual(len(result["coverage"]), 5)

    def test_director_can_select_master(self):
        result = auto_shot_planner.plan(self.acting, self.cfg, max_shots=4,
                                        master_character="达叔")
        self.assertEqual(result["coverage"][0]["planner"]["primary_character"], "达叔")

    def test_unknown_master_rejected(self):
        with self.assertRaises(ValueError):
            auto_shot_planner.plan(self.acting, self.cfg, master_character="不存在")


if __name__ == "__main__":
    unittest.main()
