import importlib.util
import json
import os
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, 'scripts')

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

bridge = load('performance_bridge', os.path.join(SCRIPTS, 'performance_bridge.py'))
footage = load('footage_mode', os.path.join(SCRIPTS, 'footage_mode.py'))
adapter = load('adapt_acting', os.path.join(SCRIPTS, 'adapt_acting.py'))

class BridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(os.path.join(ROOT, 'assets', 'dewei-acting-task.txt'), encoding='utf-8') as f:
            cls.acting = f.read()
        with open(os.path.join(ROOT, 'assets', 'dewei-bridge-config.json'), encoding='utf-8') as f:
            cls.config = json.load(f)
        cls.doc = bridge.build(cls.acting, cls.config)

    def test_chinese_names_and_safety_are_parsed(self):
        blocks = bridge.parse_blocks(self.acting)
        self.assertEqual([b['character_name'] for b in blocks], ['张飘洋', '达叔', '黄德威'])
        for b in blocks:
            self.assertTrue(b['safety'])
            self.assertNotIn('Safety', ' '.join(x['action'] for x in b['beats']))

    def test_parallel_events_are_preserved(self):
        shot = self.doc['coverage'][0]
        tracks = shot['performance']['tracks']
        self.assertEqual(len(tracks), 3)
        # First beat of all three characters overlaps at scene time zero.
        starts = [t['events'][0]['t_in'] for t in tracks]
        ends = [t['events'][0]['t_out'] for t in tracks]
        self.assertTrue(all(x == 0 for x in starts))
        self.assertTrue(min(ends) > 0)
        first_ke = shot['performance']['ke'][0]
        self.assertEqual(len(first_ke['actors']), 3)

    def test_camera_selection_filters_tracks_but_keeps_offscreen_dialogue(self):
        b = self.doc['coverage'][1]
        self.assertEqual([t['character_name'] for t in b['performance']['tracks']], ['黄德威'])
        self.assertTrue(any(x.get('offscreen') for x in b['dialogue']))
        c = self.doc['coverage'][2]
        self.assertEqual({t['character_name'] for t in c['performance']['tracks']}, {'达叔', '张飘洋'})

    def test_parallel_cameras_share_source_range_and_local_render_zero(self):
        artifact, errors, warnings = footage.build(self.doc)
        self.assertFalse(errors)
        result = footage.check_artifact(artifact)
        self.assertFalse(result['errors'], result['errors'])
        for shot in artifact['shots']:
            self.assertEqual(shot['render_range'][0], 0.0)
            self.assertEqual(shot['source_range'], [0.0, 24.0])

    def test_fov_pairing_is_enforced(self):
        artifact, errors, warnings = footage.build(self.doc)
        artifact['shots'][0]['fov_deg'] = 47
        result = footage.check_artifact(artifact)
        self.assertTrue(any('does not match WS anchor' in e[1] for e in result['errors']))

    def test_legacy_adapter_refuses_multi_character_flattening(self):
        blocks = adapter.parse_blocks(self.acting)
        _, problem = adapter.build_performance(blocks, 24.0)
        self.assertIn('multiple character tracks cannot be flattened', problem)

    def test_qc_blocks_overlong_prompt(self):
        doc = json.loads(json.dumps(self.doc))
        doc['scene']['global_style'] = 'cinematic ' * 400
        artifact, build_errors, build_warnings = footage.build(doc)
        result = footage.check_artifact(artifact)
        self.assertTrue(any('exceeds hard 320-word ceiling' in e[1] for e in result['errors']))

    def test_override_flag_requires_exact_tag(self):
        doc = json.loads(json.dumps(self.doc))
        doc['coverage'][0]['camera_move'] = 'compound'
        doc['coverage'][0]['hint'] = {'special_camera_override': True, 'raw': 'arc around the table'}
        artifact, errors, warnings = footage.build(doc)
        self.assertTrue(any('requires exact tag' in e[1] for e in errors))

    def test_exact_override_tag_authorizes_unsafe_move(self):
        doc = json.loads(json.dumps(self.doc))
        doc['coverage'][0]['camera_move'] = 'compound'
        doc['coverage'][0]['hint'] = {'special_camera_override': False,
                                      'raw': '[SPECIAL CAMERA OVERRIDE] compound move'}
        artifact, errors, warnings = footage.build(doc)
        self.assertFalse(any('requires exact tag' in e[1] for e in errors))
        self.assertEqual(artifact['shots'][0]['camera_move'], 'compound')

if __name__ == '__main__':
    unittest.main(verbosity=2)
