import copy
import json
import unittest
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import director_decision_engine as dde


def event(eid="E1", types=None, priority="high", line=1, cluster=None, actor="A"):
    return {
        "event_id": eid,
        "scene_id": "S1",
        "source": {"line_start": line, "line_end": line, "exact_text": f"source {eid}"},
        "actor": actor,
        "participants": [actor, "B"],
        "event_types": types or ["prop_state_change"],
        "coverage_priority": priority,
        "event_cluster_id": cluster or eid,
        "linked_event_ids": [],
    }


def payload(events):
    return {"schema_version": "2.2-A", "scene": {"scene_id": "S1"}, "events": events}


class DirectorDecisionEngineTests(unittest.TestCase):
    def test_01_duplicate_event_ids_rejected(self):
        with self.assertRaisesRegex(ValueError, "duplicate event_id"):
            dde.validate_events(payload([event(), event()]))

    def test_02_invalid_source_line_range_rejected(self):
        e = event()
        e["source"]["line_start"] = 0
        with self.assertRaisesRegex(ValueError, "invalid 1-based"):
            dde.validate_events(payload([e]))

    def test_03_covered_requires_all_required_dimensions(self):
        e = event(types=["prop_state_change"])
        dims = dde.required_dimensions(e)
        shot = {"shot_id": "S1", "coverage": {"E1": dims}}
        result = dde.optimize_coverage(payload([e]), [shot], max_shots=1)
        self.assertEqual(result["event_decisions"][0]["status"], "covered")

    def test_04_partially_covered_when_some_dimensions_missing(self):
        e = event(types=["prop_state_change"])
        shot = {"shot_id": "S1", "coverage": {"E1": ["action"]}}
        result = dde.optimize_coverage(payload([e]), [shot], max_shots=1)
        decision = result["event_decisions"][0]
        self.assertEqual(decision["status"], "partially_covered")
        self.assertIn("object_state", decision["missing_dimensions"])

    def test_05_not_selected_when_no_selected_shot_claims_event(self):
        e = event(types=["physical_action"])
        master = {"shot_id": "MASTER", "shot_type": "master_context", "coverage": {}}
        result = dde.optimize_coverage(payload([e]), [master], max_shots=4)
        self.assertEqual(result["event_decisions"][0]["status"], "not_selected")
        self.assertEqual(result["optimization"]["selected_shot_count"], 0)

    def test_06_shot_budget_is_hard_cap(self):
        events = [event(f"E{i}", ["physical_action"], line=i) for i in range(1, 6)]
        candidates = [
            {"shot_id": f"S{i}", "coverage": {f"E{i}": ["action", "consequence"]}}
            for i in range(1, 6)
        ]
        result = dde.optimize_coverage(payload(events), candidates, max_shots=2)
        self.assertEqual(result["optimization"]["selected_shot_count"], 2)
        narrow = dde.optimize_coverage(payload(events), candidates, max_shots=1)
        self.assertLessEqual(narrow["optimization"]["coverage_ratio"], result["optimization"]["coverage_ratio"])

    def test_07_high_priority_beats_low_priority_under_tight_budget(self):
        low = event("LOW", ["physical_action"], "review", 1)
        high = event("HIGH", ["physical_action"], "high", 2)
        candidates = [
            {"shot_id": "LOW-SHOT", "coverage": {"LOW": ["action", "consequence"]}},
            {"shot_id": "HIGH-SHOT", "coverage": {"HIGH": ["action", "consequence"]}},
        ]
        result = dde.optimize_coverage(payload([low, high]), candidates, max_shots=1)
        self.assertEqual(result["selected_shots"][0]["shot_id"], "HIGH-SHOT")

    def test_08_shared_cluster_action_does_not_merge_distinct_reactions(self):
        a = event("E1", ["physical_action", "reaction"], "high", 4, "SHARED", "A")
        b = event("E2", ["physical_action", "reaction"], "high", 5, "SHARED", "B")
        shots = dde.build_candidate_shots([a, b])
        shared = next(s for s in shots if s["coverage_mode"] == "continuous_take_candidate")
        self.assertEqual(set(shared["coverage"]), {"E1", "E2"})
        self.assertEqual(shared["coverage"]["E1"], ["action", "consequence"])
        self.assertTrue(any(s["coverage"] == {"E1": ["reaction"]} for s in shots))
        self.assertTrue(any(s["coverage"] == {"E2": ["reaction"]} for s in shots))
        prop_event = event("PROP", ["prop_state_change"], "high", 8, "PROP-CLUSTER")
        prop_shots = dde.build_candidate_shots([prop_event])
        self.assertTrue(any(s["shot_type"] == "prop_insert" and s["coverage"] == {"PROP": ["object_state"]} for s in prop_shots))

    def test_09_unknown_event_or_dimension_rejected(self):
        e = event()
        with self.assertRaisesRegex(ValueError, "unknown event_id"):
            dde.optimize_coverage(payload([e]), [{"shot_id": "S", "coverage": {"NOPE": ["action"]}}])
        with self.assertRaisesRegex(ValueError, "not required"):
            dde.optimize_coverage(payload([e]), [{"shot_id": "S", "coverage": {"E1": ["made_up"]}}])
        with self.assertRaisesRegex(ValueError, "does not intersect"):
            dde.optimize_coverage(payload([e]), [{"shot_id": "S", "source_line_range": [20, 21], "coverage": {"E1": ["action"]}}])

    def test_10_selection_is_deterministic(self):
        events = [event("E1", ["physical_action"], line=1), event("E2", ["physical_action"], line=2)]
        shots = [
            {"shot_id": "B", "source_line_range": [2, 2], "coverage": {"E2": ["action", "consequence"]}},
            {"shot_id": "A", "source_line_range": [1, 1], "coverage": {"E1": ["action", "consequence"]}},
        ]
        first = dde.optimize_coverage(payload(events), shots, max_shots=1)
        second = dde.optimize_coverage(payload(events), shots, max_shots=1)
        self.assertEqual(first["selected_shots"], second["selected_shots"])
        segments = dde.segment_master_range(0, 75, 30)
        self.assertEqual(segments, [[0.0, 30.0], [30.0, 60.0], [60.0, 75.0]])
        self.assertEqual(segments[0][0], 0)
        self.assertEqual(segments[-1][1], 75)
        self.assertTrue(all(segments[i][1] == segments[i + 1][0] for i in range(len(segments) - 1)))


if __name__ == "__main__":
    unittest.main()
