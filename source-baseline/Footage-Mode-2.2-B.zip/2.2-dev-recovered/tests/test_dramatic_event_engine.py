from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from dramatic_event_engine import parse_acting_task, validate_event_doc


class DramaticEventEngineTests(unittest.TestCase):
    def test_parse_tracks_and_exact_source_lines(self):
        source = """Scene 8.1 — 天堂号底舱
ACTING TASK — 武天豪 (夺取现场控制权的人):
SCENE DIRECTION: 以行动制造恐惧。
Moment to moment:
— 一脚踢翻厨师面前的木桶，让白扁豆滚落一地
— 面对武寒青报出官职：“大清国御前蓝翎侍卫，正六品朝廷命官。”
ACTING TASK — 武寒青 (秩序维护者):
Moment to moment:
— 看到猪仔们开始下跪，急切制止：“喂！不要跪！”
"""
        doc = parse_acting_task(source, "S08", "天堂号底舱")
        self.assertEqual(len(doc["characters"]), 2)
        self.assertEqual(len(doc["events"]), 3)
        self.assertEqual(doc["events"][0]["source"]["line_start"], 5)
        self.assertIn("踢翻", doc["events"][0]["source"]["exact_text"])

    def test_detects_high_value_action_prop_and_group_events(self):
        source = """ACTING TASK — 武天豪 (夺权者):
Moment to moment:
— 一脚踢翻厨师面前的木桶，让白扁豆滚落一地
ACTING TASK — 猪仔群体 (被争夺的群体):
Moment to moment:
— 猪仔们受到惊吓，纷纷向后退
"""
        doc = parse_acting_task(source)
        self.assertIn("prop_state_change", doc["events"][0]["event_types"])
        self.assertEqual(doc["events"][0]["coverage_priority"], "high")
        self.assertIn("group_shift", doc["events"][1]["event_types"])
        self.assertEqual(doc["events"][1]["coverage_priority"], "high")

    def test_does_not_invent_state_or_information(self):
        source = """ACTING TASK — 武寒青 (医生):
Moment to moment:
— 看向武天豪
"""
        ev = parse_acting_task(source)["events"][0]
        self.assertIsNone(ev["dramatic_state"]["before"])
        self.assertIsNone(ev["dramatic_state"]["after"])
        self.assertEqual(ev["information_delta"]["new_information"], "")
        self.assertIsNone(ev["power_relation"]["shift"])
        self.assertTrue(ev["human_review_required"])

    def test_validation_requires_source_traceability(self):
        doc = parse_acting_task("ACTING TASK — A (x):\nMoment to moment:\n— 看向B\n")
        self.assertEqual(validate_event_doc(doc), [])
        doc["events"][0]["source"]["exact_text"] = ""
        self.assertEqual(validate_event_doc(doc)[0]["severity"], "BLOCKER")

    def test_dialogue_is_verbatim_and_review_required(self):
        source = """ACTING TASK — 武寒青 (秩序维护者):
Moment to moment:
— 质问：“你们是谁，干什么的？”
"""
        ev = parse_acting_task(source)["events"][0]
        self.assertEqual(ev["dialogue_verbatim"], "你们是谁，干什么的？")
        self.assertTrue(ev["human_review_required"])

    def test_links_same_shared_action_without_erasing_character_perspectives(self):
        source = """ACTING TASK — 武天豪 (夺权者):
Moment to moment:
— 一脚踢翻厨师面前的木桶，让白扁豆滚落一地
ACTING TASK — 武寒青 (医生):
Moment to moment:
— 眼看木桶被踢翻，向武天豪大喊
ACTING TASK — 猪仔群体 (群体):
Moment to moment:
— 木桶被踢翻，受到惊吓，纷纷向后退
"""
        events = parse_acting_task(source)["events"]
        bucket_events = [e for e in events if e["event_cluster_id"] == "PROP_BUCKET_OVERTURN"]
        self.assertEqual(len(bucket_events), 3)
        self.assertEqual(len(bucket_events[0]["linked_event_ids"]), 2)
        self.assertEqual(len({e["actor"] for e in bucket_events}), 3)

    def test_separates_staggered_kneeling_stages_instead_of_flattening_them(self):
        source = """ACTING TASK — 猪仔群体 (被争夺的群体):
Moment to moment:
— 听到武天豪自称朝廷命官，部分人不自觉地跪下
— 见猪仔有人跪下，立刻狐假虎威地呵斥：“见了大人，还不下跪！”
— 受到蛇头呵斥后，尚未跪下的人陆续跪下
— 武寒青阻止他们下跪时，几个人抬头看她，仍不确定该听谁的
"""
        events = parse_acting_task(source)["events"]
        clusters = [e["event_cluster_id"] for e in events]
        self.assertEqual(clusters, ["GROUP_KNEELING_WAVE_1", "GROUP_KNEELING_ESCALATION_CUE", "GROUP_KNEELING_WAVE_2", "GROUP_KNEELING_AMBIVALENCE"])

    def test_screenplay_mode_preserves_original_line_numbers_and_dialogue(self):
        from dramatic_event_engine import parse_screenplay
        source = """8.1 天堂号底舱内/外，夜，内
猪仔们排着队，走到厨师面前伸出手。
武寒青
后面的先看看自己的手干不干净！
武天豪
大清国御前蓝翎侍卫，正六品朝廷命官。
一脚踢翻厨师面前的木桶，让白扁豆滚落一地
"""
        doc = parse_screenplay(source, ["武寒青", "武天豪", "猪仔群体", "厨师"], "S08")
        self.assertEqual(doc["scene"]["source_type"], "screenplay")
        self.assertEqual(len(doc["events"]), 4)
        self.assertEqual(doc["events"][1]["actor"], "武寒青")
        self.assertEqual(doc["events"][1]["dialogue_verbatim"], "后面的先看看自己的手干不干净！")
        self.assertEqual(doc["events"][1]["source"]["line_start"], 4)
        self.assertEqual(doc["events"][3]["actor"], "UNASSIGNED")
        self.assertEqual(doc["events"][3]["source"]["line_start"], 7)

    def test_distinct_sequential_restraint_actions_are_not_merged(self):
        source = """ACTING TASK — 大头 (执行者):
Moment to moment:
— 拖着武寒青重新进入底舱
— 一用力将武寒青按倒在地，持续压制她的挣扎
"""
        events = parse_acting_task(source)["events"]
        self.assertEqual(events[0]["event_cluster_id"], "PHYSICAL_RESTRAINT_DRAG")
        self.assertEqual(events[1]["event_cluster_id"], "PHYSICAL_RESTRAINT_PIN")
        self.assertNotEqual(events[0]["event_cluster_id"], events[1]["event_cluster_id"])


if __name__ == "__main__":
    unittest.main()
