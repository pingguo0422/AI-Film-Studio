import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from director_intelligence import analyze_scene
from spatial_intelligence import validate_spatial
from continuity_engine import validate_continuity
from preflight_2 import run

class V2Tests(unittest.TestCase):
    def test_director_cues_are_suggestions_not_facts(self):
        doc={"coverage":[{"shot":1,"beat":"他试探对方，随后沉默"}]}
        result=analyze_scene(doc)
        codes={x["code"] for x in result["shot_reviews"][0]["suggestions"]}
        self.assertIn("power_test",codes)
        self.assertIn("hesitation",codes)
        self.assertTrue(result["shot_reviews"][0]["review_required"])
        self.assertTrue(result["limitations"])

    def test_spatial_same_side_passes(self):
        doc={"scene":{"geography":{"axis":{"characters":["A","B"]},
             "character_anchors":{"A":[0,0],"B":[10,0]}}},
             "coverage":[{"shot":1,"coverage_group":"g","camera_position":[5,4]},
                         {"shot":2,"coverage_group":"g","camera_position":[5,6]}]}
        self.assertEqual(validate_spatial(doc)["status"],"PASS")

    def test_spatial_crossing_requires_declaration(self):
        doc={"scene":{"geography":{"axis":{"characters":["A","B"]},
             "character_anchors":{"A":[0,0],"B":[10,0]}}},
             "coverage":[{"shot":1,"coverage_group":"g","camera_position":[5,4]},
                         {"shot":2,"coverage_group":"g","camera_position":[5,-4]}]}
        result=validate_spatial(doc)
        self.assertEqual(result["status"],"FAIL")
        self.assertTrue(any("crosses" in x for x in result["errors"]))

    def test_documented_crossing_is_allowed_but_reason_warned(self):
        doc={"scene":{"geography":{"axis":{"characters":["A","B"]},
             "character_anchors":{"A":[0,0],"B":[10,0]}}},
             "coverage":[{"shot":1,"coverage_group":"g","camera_position":[5,4]},
                         {"shot":2,"coverage_group":"g","camera_position":[5,-4],
                          "crossing":True,"crossing_reason":"motivated reveal"}]}
        self.assertEqual(validate_spatial(doc)["status"],"PASS")

    def test_overlapping_state_mismatch_fails(self):
        doc={"coverage":[
            {"shot":1,"source_range":[0,5],"state_snapshot":{"props":{"cup":{"hand":"right"}}}},
            {"shot":2,"source_range":[2,6],"state_snapshot":{"props":{"cup":{"hand":"left"}}}}
        ]}
        self.assertEqual(validate_continuity(doc)["status"],"FAIL")

    def test_missing_snapshot_is_incomplete_not_guessed(self):
        doc={"coverage":[{"shot":1,"source_range":[0,2]},{"shot":2,"source_range":[1,3]}]}
        self.assertEqual(validate_continuity(doc)["status"],"INCOMPLETE")

    def test_integrated_preflight(self):
        doc={"scene":{},"coverage":[{"shot":1,"beat":"人物犹豫"}]}
        report=run(doc)
        self.assertIn("director_intelligence",report)
        self.assertIn("spatial_intelligence",report)
        self.assertTrue(report["human_review_required"])

if __name__ == "__main__": unittest.main()
